import os
import io
import logging
from typing import Optional, Dict, Any, List
from minio import Minio
from minio.error import S3Error
from datetime import datetime
import json

logger = logging.getLogger(__name__)


class MinIOStorage:
    """MinIO storage backend for training datasets and model artifacts"""
    
    def __init__(self, config: Optional[Dict[str, Any]] = None):
        """Initialize MinIO client with configuration"""
        if config is None:
            config = {
                "endpoint": os.getenv("MINIO_ENDPOINT", "localhost:9000"),
                "access_key": os.getenv("MINIO_ACCESS_KEY", "minioadmin"),
                "secret_key": os.getenv("MINIO_SECRET_KEY", "minioadmin"),
                "secure": os.getenv("MINIO_SECURE", "false").lower() == "true"
            }
        
        self.endpoint = config["endpoint"]
        self.access_key = config["access_key"]
        self.secret_key = config["secret_key"]
        self.secure = config.get("secure", False)
        
        self.client = Minio(
            self.endpoint,
            access_key=self.access_key,
            secret_key=self.secret_key,
            secure=self.secure
        )
        
        logger.info(f"MinIO client initialized for endpoint: {self.endpoint}")
    
    def ensure_bucket(self, bucket_name: str) -> bool:
        """Ensure a bucket exists, create if not"""
        try:
            if not self.client.bucket_exists(bucket_name):
                self.client.make_bucket(bucket_name)
                logger.info(f"Created bucket: {bucket_name}")
            return True
        except S3Error as e:
            logger.error(f"Error ensuring bucket {bucket_name}: {e}")
            return False
    
    def put_object(self, bucket_name: str, object_name: str, data: io.BytesIO, length: int) -> bool:
        """Upload an object to MinIO"""
        try:
            self.ensure_bucket(bucket_name)
            self.client.put_object(
                bucket_name,
                object_name,
                data,
                length
            )
            logger.info(f"Uploaded object {object_name} to bucket {bucket_name}")
            return True
        except S3Error as e:
            logger.error(f"Error uploading object: {e}")
            return False
    
    def get_object(self, bucket_name: str, object_name: str) -> Optional[bytes]:
        """Download an object from MinIO"""
        try:
            response = self.client.get_object(bucket_name, object_name)
            data = response.read()
            response.close()
            response.release_conn()
            return data
        except S3Error as e:
            logger.error(f"Error downloading object: {e}")
            return None
    
    def list_objects(self, bucket_name: str, prefix: Optional[str] = None) -> List[str]:
        """List objects in a bucket with optional prefix"""
        try:
            objects = self.client.list_objects(bucket_name, prefix=prefix)
            return [obj.object_name for obj in objects]
        except S3Error as e:
            logger.error(f"Error listing objects: {e}")
            return []
    
    def delete_object(self, bucket_name: str, object_name: str) -> bool:
        """Delete an object from MinIO"""
        try:
            self.client.remove_object(bucket_name, object_name)
            logger.info(f"Deleted object {object_name} from bucket {bucket_name}")
            return True
        except S3Error as e:
            logger.error(f"Error deleting object: {e}")
            return False
    
    def upload_json(self, bucket_name: str, object_name: str, data: Dict[str, Any]) -> bool:
        """Upload JSON data to MinIO"""
        try:
            json_bytes = json.dumps(data, indent=2).encode('utf-8')
            data_stream = io.BytesIO(json_bytes)
            return self.put_object(bucket_name, object_name, data_stream, len(json_bytes))
        except Exception as e:
            logger.error(f"Error uploading JSON: {e}")
            return False
    
    def download_json(self, bucket_name: str, object_name: str) -> Optional[Dict[str, Any]]:
        """Download and parse JSON data from MinIO"""
        try:
            data = self.get_object(bucket_name, object_name)
            if data:
                return json.loads(data.decode('utf-8'))
            return None
        except Exception as e:
            logger.error(f"Error downloading JSON: {e}")
            return None
    
    def get_presigned_url(self, bucket_name: str, object_name: str, expires: int = 3600) -> Optional[str]:
        """Generate a presigned URL for object access"""
        try:
            from datetime import timedelta
            url = self.client.presigned_get_object(
                bucket_name,
                object_name,
                expires=timedelta(seconds=expires)
            )
            return url
        except S3Error as e:
            logger.error(f"Error generating presigned URL: {e}")
            return None