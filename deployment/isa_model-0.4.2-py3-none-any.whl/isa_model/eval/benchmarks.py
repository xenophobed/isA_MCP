"""
Standard AI Benchmarks for ISA Model Framework

This module provides implementations of standard AI benchmarks:
- MMLU (Massive Multitask Language Understanding)
- HellaSwag (Commonsense Reasoning)
- ARC (AI2 Reasoning Challenge)
- GSM8K (Grade School Math)
"""

import os
import json
import logging
import requests
import zipfile
import tarfile
from pathlib import Path
from typing import Dict, List, Any, Optional
from abc import ABC, abstractmethod
from dataclasses import dataclass
import pandas as pd

logger = logging.getLogger(__name__)


class DatasetDownloader:
    """Enhanced utility class for downloading and caching benchmark datasets with performance optimizations."""
    
    def __init__(self, cache_dir: str = "~/.isa_model/datasets", enable_parallel_download: bool = True):
        self.cache_dir = Path(cache_dir).expanduser()
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        self.enable_parallel_download = enable_parallel_download
        
        # Enhanced dataset URLs and info with multiple mirrors for reliability
        self.dataset_info = {
            "mmlu": {
                "urls": [
                    "https://people.eecs.berkeley.edu/~hendrycks/data.tar",
                    "https://huggingface.co/datasets/cais/mmlu/resolve/main/data.tar"
                ],
                "filename": "mmlu_data.tar",
                "extracted_dir": "data",
                "checksum": "sha256:...",  # Add checksums for integrity
                "size_mb": 166
            },
            "hellaswag": {
                "urls": [
                    "https://raw.githubusercontent.com/rowanz/hellaswag/master/data/hellaswag_val.jsonl",
                    "https://huggingface.co/datasets/Rowan/hellaswag/resolve/main/hellaswag_val.jsonl"
                ],
                "filename": "hellaswag_val.jsonl",
                "checksum": "sha256:...",
                "size_mb": 45
            },
            "arc": {
                "urls": [
                    "https://s3-us-west-2.amazonaws.com/ai2-website/data/ARC-V1-Feb2018.zip",
                    "https://github.com/fchollet/ARC-AGI/archive/master.zip"
                ],
                "filename": "arc_data.zip",
                "extracted_dir": "ARC-V1-Feb2018-2",
                "checksum": "sha256:...",
                "size_mb": 2
            },
            "gsm8k": {
                "urls": [
                    "https://github.com/openai/grade-school-math/raw/master/grade_school_math/data/test.jsonl",
                    "https://huggingface.co/datasets/gsm8k/resolve/main/test.jsonl"
                ],
                "filename": "gsm8k_test.jsonl",
                "checksum": "sha256:...",
                "size_mb": 3
            }
        }
        
        # Download statistics and caching
        self._download_stats = {}
        self._data_cache = {}  # In-memory cache for frequently accessed data
    
    def download_dataset(self, dataset_name: str, force_download: bool = False) -> Path:
        """Download and cache a dataset with enhanced error handling and progress tracking."""
        if dataset_name not in self.dataset_info:
            raise ValueError(f"Unknown dataset: {dataset_name}")
        
        info = self.dataset_info[dataset_name]
        dataset_dir = self.cache_dir / dataset_name
        dataset_dir.mkdir(exist_ok=True)
        
        file_path = dataset_dir / info["filename"]
        
        # Check if already downloaded and validate integrity
        if file_path.exists() and not force_download:
            if self._validate_file_integrity(file_path, info):
                logger.info(f"Using cached {dataset_name} dataset at {file_path}")
                return self._get_data_path(dataset_name, file_path)
            else:
                logger.warning(f"Cached file {file_path} failed integrity check, re-downloading")
                force_download = True
        
        # Try multiple URLs for robustness
        urls = info["urls"] if isinstance(info.get("urls"), list) else [info.get("url")]
        
        for i, url in enumerate(urls):
            if not url:
                continue
                
            logger.info(f"Downloading {dataset_name} dataset from {url} (attempt {i+1}/{len(urls)})")
            
            try:
                # Download with progress tracking
                success = self._download_with_progress(url, file_path, info)
                
                if success:
                    logger.info(f"Downloaded {dataset_name} dataset to {file_path}")
                    
                    # Validate downloaded file
                    if self._validate_file_integrity(file_path, info):
                        return self._get_data_path(dataset_name, file_path)
                    else:
                        logger.error(f"Downloaded file failed integrity check")
                        file_path.unlink(missing_ok=True)
                        continue
                
            except Exception as e:
                logger.warning(f"Failed to download from {url}: {e}")
                if i == len(urls) - 1:  # Last URL failed
                    logger.error(f"All download attempts failed for {dataset_name}")
                    return None
                continue
        
        return None
    
    def _download_with_progress(self, url: str, file_path: Path, info: Dict) -> bool:
        """Download file with progress tracking and resume capability."""
        try:
            # Check if partial file exists
            resume_pos = 0
            if file_path.exists():
                resume_pos = file_path.stat().st_size
            
            headers = {}
            if resume_pos > 0:
                headers['Range'] = f'bytes={resume_pos}-'
                logger.info(f"Resuming download from byte {resume_pos}")
            
            response = requests.get(url, headers=headers, stream=True, timeout=30)
            response.raise_for_status()
            
            total_size = int(response.headers.get('content-length', 0))
            if resume_pos > 0:
                total_size += resume_pos
            
            # Open file in append mode if resuming
            mode = 'ab' if resume_pos > 0 else 'wb'
            
            with open(file_path, mode) as f:
                downloaded = resume_pos
                chunk_size = 8192 * 8  # Larger chunks for better performance
                
                for chunk in response.iter_content(chunk_size=chunk_size):
                    if chunk:
                        f.write(chunk)
                        downloaded += len(chunk)
                        
                        # Progress logging every 10MB
                        if downloaded % (10 * 1024 * 1024) == 0:
                            if total_size > 0:
                                percent = (downloaded / total_size) * 100
                                logger.debug(f"Downloaded {downloaded / (1024*1024):.1f}MB / {total_size / (1024*1024):.1f}MB ({percent:.1f}%)")
                            else:
                                logger.debug(f"Downloaded {downloaded / (1024*1024):.1f}MB")
            
            return True
            
        except requests.exceptions.RequestException as e:
            logger.error(f"Network error during download: {e}")
            return False
        except Exception as e:
            logger.error(f"Unexpected error during download: {e}")
            return False
    
    def _validate_file_integrity(self, file_path: Path, info: Dict) -> bool:
        """Validate file integrity using size and checksum."""
        if not file_path.exists():
            return False
        
        # Check file size if available
        if "size_mb" in info:
            expected_size = info["size_mb"] * 1024 * 1024
            actual_size = file_path.stat().st_size
            
            # Allow 5% variance in size
            if abs(actual_size - expected_size) > expected_size * 0.05:
                logger.warning(f"File size mismatch: expected ~{expected_size}, got {actual_size}")
                return False
        
        # TODO: Add checksum validation when checksums are available
        # if "checksum" in info:
        #     return self._validate_checksum(file_path, info["checksum"])
        
        return True
    
    def _get_data_path(self, dataset_name: str, file_path: Path) -> Path:
        """Get the actual data path, extracting archives if needed."""
        info = self.dataset_info[dataset_name]
        
        if "extracted_dir" in info:
            # Need to extract
            extract_dir = file_path.parent / info["extracted_dir"]
            
            if not extract_dir.exists():
                logger.info(f"Extracting {file_path}")
                
                if file_path.suffix == ".zip":
                    with zipfile.ZipFile(file_path, 'r') as zip_ref:
                        zip_ref.extractall(file_path.parent)
                elif file_path.suffix == ".tar" or ".tar." in file_path.name:
                    with tarfile.open(file_path, 'r') as tar_ref:
                        tar_ref.extractall(file_path.parent)
            
            return extract_dir
        else:
            return file_path


@dataclass
class BenchmarkConfig:
    """Configuration for benchmark evaluation."""
    name: str
    description: str
    num_choices: int = 4
    few_shot_examples: int = 5
    max_samples: Optional[int] = None
    subjects: Optional[List[str]] = None


class BaseBenchmark(ABC):
    """Base class for all benchmarks."""
    
    def __init__(self, config: BenchmarkConfig):
        self.config = config
        self.name = config.name
        self.data = None
        self.downloader = DatasetDownloader()
        self.use_real_data = True  # Flag to control real vs placeholder data
    
    @abstractmethod
    def load_data(self, max_samples: Optional[int] = None) -> List[Dict[str, Any]]:
        """Load benchmark data."""
        pass
    
    @abstractmethod
    def evaluate_sample(self, sample: Dict[str, Any], prediction: str) -> bool:
        """Evaluate a single sample."""
        pass
    
    def format_prompt(self, sample: Dict[str, Any], few_shot_examples: Optional[List[Dict[str, Any]]] = None) -> str:
        """Format prompt for the sample."""
        prompt = ""
        
        # Add few-shot examples if provided
        if few_shot_examples:
            for example in few_shot_examples:
                prompt += self._format_single_example(example, include_answer=True) + "\n\n"
        
        # Add the actual question
        prompt += self._format_single_example(sample, include_answer=False)
        
        return prompt
    
    @abstractmethod
    def _format_single_example(self, sample: Dict[str, Any], include_answer: bool = False) -> str:
        """Format a single example."""
        pass


class MMLU(BaseBenchmark):
    """
    MMLU (Massive Multitask Language Understanding) Benchmark
    
    Tests knowledge across 57 subjects including mathematics, history, 
    computer science, law, and more.
    """
    
    def __init__(self, subjects: Optional[List[str]] = None):
        config = BenchmarkConfig(
            name="MMLU",
            description="Massive Multitask Language Understanding",
            num_choices=4,
            few_shot_examples=5,
            subjects=subjects
        )
        super().__init__(config)
        
        # MMLU subjects
        self.all_subjects = [
            "abstract_algebra", "anatomy", "astronomy", "business_ethics",
            "clinical_knowledge", "college_biology", "college_chemistry",
            "college_computer_science", "college_mathematics", "college_medicine",
            "college_physics", "computer_security", "conceptual_physics",
            "econometrics", "electrical_engineering", "elementary_mathematics",
            "formal_logic", "global_facts", "high_school_biology",
            "high_school_chemistry", "high_school_computer_science",
            "high_school_european_history", "high_school_geography",
            "high_school_government_and_politics", "high_school_macroeconomics",
            "high_school_mathematics", "high_school_microeconomics",
            "high_school_physics", "high_school_psychology", "high_school_statistics",
            "high_school_us_history", "high_school_world_history", "human_aging",
            "human_sexuality", "international_law", "jurisprudence",
            "logical_fallacies", "machine_learning", "management", "marketing",
            "medical_genetics", "miscellaneous", "moral_disputes", "moral_scenarios",
            "nutrition", "philosophy", "prehistory", "professional_accounting",
            "professional_law", "professional_medicine", "professional_psychology",
            "public_relations", "security_studies", "sociology", "us_foreign_policy",
            "virology", "world_religions"
        ]
        
        self.subjects = subjects or self.all_subjects[:10]  # Use first 10 subjects by default
    
    def load_data(self, max_samples: Optional[int] = None) -> List[Dict[str, Any]]:
        """Load MMLU data with real dataset support."""
        if self.use_real_data:
            try:
                return self._load_real_mmlu_data(max_samples)
            except Exception as e:
                logger.warning(f"Failed to load real MMLU data: {e}. Falling back to placeholder data.")
                return self._load_placeholder_mmlu_data(max_samples)
        else:
            return self._load_placeholder_mmlu_data(max_samples)
    
    def _load_real_mmlu_data(self, max_samples: Optional[int] = None) -> List[Dict[str, Any]]:
        """Load real MMLU dataset with enhanced error handling and fallbacks."""
        try:
            # Try Hugging Face datasets first (recommended approach)
            data = self._load_mmlu_from_huggingface(max_samples)
            if data:
                return data
        except Exception as e:
            logger.warning(f"Failed to load MMLU from HuggingFace: {e}")
        
        try:
            # Fallback to direct download
            data_path = self.downloader.download_dataset("mmlu")
            if not data_path or not data_path.exists():
                raise FileNotFoundError("MMLU dataset not found")
            
            data = []
            samples_per_subject = max_samples // len(self.subjects) if max_samples else None
            
            for subject in self.subjects:
                subject_file = data_path / "test" / f"{subject}_test.csv"
                if not subject_file.exists():
                    # Try alternative file naming
                    alt_subject_file = data_path / f"{subject}_test.csv"
                    if alt_subject_file.exists():
                        subject_file = alt_subject_file
                    else:
                        logger.warning(f"Subject file not found: {subject_file}")
                        continue
                
                try:
                    # Load CSV data with robust parsing
                    df = pd.read_csv(subject_file, header=None, encoding='utf-8')
                    
                    # Handle different CSV formats
                    if len(df.columns) >= 6:
                        df.columns = ["question", "A", "B", "C", "D", "answer"]
                    elif len(df.columns) == 5:
                        df.columns = ["question", "A", "B", "C", "answer"] 
                        # Add empty D column
                        df["D"] = ""
                    else:
                        logger.warning(f"Unexpected CSV format for {subject}: {len(df.columns)} columns")
                        continue
                    
                    # Convert to our format
                    subject_count = 0
                    for idx, row in df.iterrows():
                        if samples_per_subject and subject_count >= samples_per_subject:
                            break
                        
                        # Clean and validate data
                        question = str(row["question"]).strip()
                        if not question or len(question) < 10:
                            continue
                            
                        choices = [str(row[col]).strip() for col in ["A", "B", "C", "D"] if col in row and str(row[col]).strip()]
                        if len(choices) < 2:
                            continue
                            
                        # Ensure we have 4 choices
                        while len(choices) < 4:
                            choices.append("")
                        
                        answer = str(row["answer"]).strip().upper()
                        if answer not in ["A", "B", "C", "D"]:
                            # Try to map numeric answers
                            if answer.isdigit():
                                answer_map = {"0": "A", "1": "B", "2": "C", "3": "D"}
                                answer = answer_map.get(answer, "A")
                            else:
                                answer = "A"  # Default fallback
                        
                        sample = {
                            "subject": subject,
                            "question": question,
                            "choices": choices,
                            "answer": answer,
                            "id": f"{subject}_{idx}",
                            "source": "mmlu_csv"
                        }
                        data.append(sample)
                        subject_count += 1
                        
                except Exception as e:
                    logger.error(f"Error loading subject {subject}: {e}")
                    continue
            
            if max_samples:
                data = data[:max_samples]
            
            logger.info(f"Loaded {len(data)} real MMLU samples across {len(set(d['subject'] for d in data))} subjects")
            return data
            
        except Exception as e:
            logger.error(f"Failed to load MMLU data: {e}")
            raise
    
    def _load_mmlu_from_huggingface(self, max_samples: Optional[int] = None) -> List[Dict[str, Any]]:
        """Load MMLU dataset from HuggingFace datasets."""
        try:
            from datasets import load_dataset
            
            logger.info("Loading MMLU from HuggingFace datasets...")
            
            # Load the dataset
            dataset = load_dataset("cais/mmlu", "all", split="test", trust_remote_code=True)
            
            if not dataset:
                return []
            
            data = []
            subject_counts = {}
            samples_per_subject = max_samples // len(self.subjects) if max_samples else None
            
            for sample in dataset:
                subject = sample.get("subject", "unknown")
                
                # Filter by subjects we want
                if subject not in self.subjects:
                    continue
                
                # Limit samples per subject
                if samples_per_subject:
                    subject_counts[subject] = subject_counts.get(subject, 0) + 1
                    if subject_counts[subject] > samples_per_subject:
                        continue
                
                # Convert to our format
                choices = [sample.get(f"choice_{i}", "") for i in range(4)]
                answer_idx = sample.get("answer", 0)
                answer = chr(65 + answer_idx)  # Convert 0,1,2,3 to A,B,C,D
                
                formatted_sample = {
                    "subject": subject,
                    "question": sample.get("question", ""),
                    "choices": choices,
                    "answer": answer,
                    "id": f"hf_{subject}_{len(data)}",
                    "source": "huggingface"
                }
                
                data.append(formatted_sample)
                
                if max_samples and len(data) >= max_samples:
                    break
            
            logger.info(f"Loaded {len(data)} MMLU samples from HuggingFace")
            return data
            
        except ImportError:
            logger.warning("HuggingFace datasets not available. Install with: pip install datasets")
            return []
        except Exception as e:
            logger.error(f"Error loading MMLU from HuggingFace: {e}")
            return []
    
    def _load_placeholder_mmlu_data(self, max_samples: Optional[int] = None) -> List[Dict[str, Any]]:
        """Load placeholder MMLU data."""
        data = []
        
        for subject in self.subjects:
            # Generate sample questions for each subject
            for i in range(min(10, max_samples // len(self.subjects) if max_samples else 10)):
                sample = {
                    "subject": subject,
                    "question": f"Sample {subject} question {i+1}",
                    "choices": [
                        f"Option A for {subject}",
                        f"Option B for {subject}",
                        f"Option C for {subject}",
                        f"Option D for {subject}"
                    ],
                    "answer": "A",  # Simplified
                    "id": f"{subject}_{i}"
                }
                data.append(sample)
        
        if max_samples:
            data = data[:max_samples]
        
        logger.info(f"Loaded {len(data)} placeholder MMLU samples across {len(self.subjects)} subjects")
        return data
    
    def evaluate_sample(self, sample: Dict[str, Any], prediction: str) -> bool:
        """Evaluate a single MMLU sample."""
        # Extract the letter choice from prediction
        prediction = prediction.strip().upper()
        
        # Handle various response formats
        if prediction in ["A", "B", "C", "D"]:
            return prediction == sample["answer"]
        elif prediction.startswith("(") and prediction.endswith(")"):
            letter = prediction[1]
            return letter == sample["answer"]
        else:
            # Try to find A, B, C, or D in the response
            for choice in ["A", "B", "C", "D"]:
                if choice in prediction:
                    return choice == sample["answer"]
        
        return False
    
    def _format_single_example(self, sample: Dict[str, Any], include_answer: bool = False) -> str:
        """Format a single MMLU example."""
        prompt = f"Subject: {sample['subject'].replace('_', ' ').title()}\n"
        prompt += f"Question: {sample['question']}\n"
        
        choices = sample['choices']
        for i, choice in enumerate(choices):
            letter = chr(65 + i)  # A, B, C, D
            prompt += f"{letter}. {choice}\n"
        
        if include_answer:
            prompt += f"Answer: {sample['answer']}"
        else:
            prompt += "Answer:"
        
        return prompt


class HellaSwag(BaseBenchmark):
    """
    HellaSwag Benchmark
    
    Tests commonsense reasoning about physical situations.
    """
    
    def __init__(self):
        config = BenchmarkConfig(
            name="HellaSwag",
            description="Commonsense Reasoning about Physical Situations",
            num_choices=4,
            few_shot_examples=10
        )
        super().__init__(config)
    
    def load_data(self, max_samples: Optional[int] = None) -> List[Dict[str, Any]]:
        """Load HellaSwag data with real dataset support."""
        if self.use_real_data:
            try:
                return self._load_real_hellaswag_data(max_samples)
            except Exception as e:
                logger.warning(f"Failed to load real HellaSwag data: {e}. Falling back to placeholder data.")
                return self._load_placeholder_hellaswag_data(max_samples)
        else:
            return self._load_placeholder_hellaswag_data(max_samples)
    
    def _load_real_hellaswag_data(self, max_samples: Optional[int] = None) -> List[Dict[str, Any]]:
        """Load real HellaSwag dataset with enhanced loading and fallbacks."""
        try:
            # Try HuggingFace datasets first
            data = self._load_hellaswag_from_huggingface(max_samples)
            if data:
                return data
        except Exception as e:
            logger.warning(f"Failed to load HellaSwag from HuggingFace: {e}")
        
        try:
            # Fallback to direct download
            data_path = self.downloader.download_dataset("hellaswag")
            if not data_path or not data_path.exists():
                raise FileNotFoundError("HellaSwag dataset not found")
            
            data = []
            
            with open(data_path, 'r', encoding='utf-8') as f:
                for i, line in enumerate(f):
                    if max_samples and i >= max_samples:
                        break
                    
                    try:
                        line = line.strip()
                        if not line:
                            continue
                            
                        item = json.loads(line)
                        
                        # Validate required fields
                        if not all(key in item for key in ["ctx", "endings", "label"]):
                            logger.warning(f"Missing required fields in HellaSwag item {i}")
                            continue
                        
                        context = str(item["ctx"]).strip()
                        endings = item["endings"]
                        label = item["label"]
                        
                        # Validate data quality
                        if not context or len(context) < 10:
                            continue
                        if not endings or len(endings) < 2:
                            continue
                        
                        # Ensure we have 4 endings
                        while len(endings) < 4:
                            endings.append("No additional option")
                        endings = endings[:4]  # Limit to 4
                        
                        # Convert label to letter
                        if isinstance(label, str) and label.isdigit():
                            label = int(label)
                        if isinstance(label, int) and 0 <= label <= 3:
                            answer = chr(65 + label)  # Convert 0,1,2,3 to A,B,C,D
                        else:
                            logger.warning(f"Invalid label in HellaSwag item {i}: {label}")
                            answer = "A"  # Default fallback
                        
                        sample = {
                            "context": context,
                            "question": "What happens next?",
                            "choices": [str(ending).strip() for ending in endings],
                            "answer": answer,
                            "id": f"hellaswag_{item.get('ind', i)}",
                            "source": "hellaswag_jsonl",
                            "activity_label": item.get("activity_label", "unknown")
                        }
                        data.append(sample)
                        
                    except json.JSONDecodeError as e:
                        logger.warning(f"Failed to parse JSON in HellaSwag line {i}: {e}")
                        continue
                    except Exception as e:
                        logger.warning(f"Error processing HellaSwag item {i}: {e}")
                        continue
            
            logger.info(f"Loaded {len(data)} real HellaSwag samples")
            return data
            
        except Exception as e:
            logger.error(f"Error loading HellaSwag data: {e}")
            raise
    
    def _load_hellaswag_from_huggingface(self, max_samples: Optional[int] = None) -> List[Dict[str, Any]]:
        """Load HellaSwag dataset from HuggingFace datasets."""
        try:
            from datasets import load_dataset
            
            logger.info("Loading HellaSwag from HuggingFace datasets...")
            
            # Load the validation set (commonly used for evaluation)
            dataset = load_dataset("Rowan/hellaswag", split="validation", trust_remote_code=True)
            
            if not dataset:
                return []
            
            data = []
            
            for i, sample in enumerate(dataset):
                if max_samples and i >= max_samples:
                    break
                
                # Extract data
                context = sample.get("ctx", "")
                endings = sample.get("endings", [])
                label = sample.get("label", 0)
                
                # Validate and clean
                if not context or not endings:
                    continue
                
                # Ensure 4 endings
                while len(endings) < 4:
                    endings.append("No additional option")
                endings = endings[:4]
                
                # Convert label to letter
                if isinstance(label, (int, str)) and str(label).isdigit():
                    label_int = int(label)
                    if 0 <= label_int <= 3:
                        answer = chr(65 + label_int)
                    else:
                        answer = "A"
                else:
                    answer = "A"
                
                formatted_sample = {
                    "context": str(context).strip(),
                    "question": "What happens next?",
                    "choices": [str(ending).strip() for ending in endings],
                    "answer": answer,
                    "id": f"hf_hellaswag_{i}",
                    "source": "huggingface",
                    "activity_label": sample.get("activity_label", "unknown")
                }
                
                data.append(formatted_sample)
            
            logger.info(f"Loaded {len(data)} HellaSwag samples from HuggingFace")
            return data
            
        except ImportError:
            logger.warning("HuggingFace datasets not available. Install with: pip install datasets")
            return []
        except Exception as e:
            logger.error(f"Error loading HellaSwag from HuggingFace: {e}")
            return []
    
    def _load_placeholder_hellaswag_data(self, max_samples: Optional[int] = None) -> List[Dict[str, Any]]:
        """Load placeholder HellaSwag data."""
        data = []
        
        sample_contexts = [
            "A person is washing dishes in the kitchen",
            "Someone is riding a bicycle down a hill",
            "A chef is preparing ingredients for cooking",
            "A student is taking notes in class",
            "A gardener is planting flowers"
        ]
        
        for i, context in enumerate(sample_contexts):
            if max_samples and i >= max_samples:
                break
                
            sample = {
                "context": context,
                "question": "What happens next?",
                "choices": [
                    f"They continue with the logical next step for scenario {i+1}",
                    f"They do something completely unrelated to scenario {i+1}",
                    f"They stop and do something random in scenario {i+1}",
                    f"They repeat the same action in scenario {i+1}"
                ],
                "answer": "A",  # First choice is usually most logical
                "id": f"hellaswag_{i}"
            }
            data.append(sample)
        
        logger.info(f"Loaded {len(data)} placeholder HellaSwag samples")
        return data
    
    def evaluate_sample(self, sample: Dict[str, Any], prediction: str) -> bool:
        """Evaluate a single HellaSwag sample."""
        prediction = prediction.strip().upper()
        
        if prediction in ["A", "B", "C", "D"]:
            return prediction == sample["answer"]
        
        # Try to extract choice from longer response
        for choice in ["A", "B", "C", "D"]:
            if choice in prediction:
                return choice == sample["answer"]
        
        return False
    
    def _format_single_example(self, sample: Dict[str, Any], include_answer: bool = False) -> str:
        """Format a single HellaSwag example."""
        prompt = f"Context: {sample['context']}\n"
        prompt += f"Question: {sample['question']}\n"
        
        choices = sample['choices']
        for i, choice in enumerate(choices):
            letter = chr(65 + i)  # A, B, C, D
            prompt += f"{letter}. {choice}\n"
        
        if include_answer:
            prompt += f"Answer: {sample['answer']}"
        else:
            prompt += "Answer:"
        
        return prompt


class ARC(BaseBenchmark):
    """
    ARC (AI2 Reasoning Challenge) Benchmark
    
    Tests scientific reasoning with grade-school level science questions.
    """
    
    def __init__(self, challenge_set: str = "easy"):
        config = BenchmarkConfig(
            name=f"ARC-{challenge_set}",
            description=f"AI2 Reasoning Challenge ({challenge_set})",
            num_choices=4,
            few_shot_examples=25
        )
        super().__init__(config)
        self.challenge_set = challenge_set  # "easy" or "challenge"
    
    def load_data(self, max_samples: Optional[int] = None) -> List[Dict[str, Any]]:
        """Load ARC data (simplified implementation)."""
        # This is a simplified implementation
        # In practice, you'd load from the actual ARC dataset
        
        data = []
        
        sample_questions = [
            {
                "question": "What happens to water when it freezes?",
                "choices": ["It becomes ice", "It becomes gas", "It disappears", "It becomes hot"],
                "answer": "A"
            },
            {
                "question": "Which planet is closest to the Sun?",
                "choices": ["Earth", "Mars", "Mercury", "Venus"],
                "answer": "C"
            },
            {
                "question": "What do plants need to make their own food?",
                "choices": ["Sunlight and water", "Only water", "Only sunlight", "Soil only"],
                "answer": "A"
            },
            {
                "question": "What is the main gas in Earth's atmosphere?",
                "choices": ["Oxygen", "Carbon dioxide", "Nitrogen", "Hydrogen"],
                "answer": "C"
            },
            {
                "question": "How many legs does a spider have?",
                "choices": ["6", "8", "10", "12"],
                "answer": "B"
            }
        ]
        
        for i, q in enumerate(sample_questions):
            if max_samples and i >= max_samples:
                break
                
            sample = {
                "question": q["question"],
                "choices": q["choices"],
                "answer": q["answer"],
                "challenge_set": self.challenge_set,
                "id": f"arc_{self.challenge_set}_{i}"
            }
            data.append(sample)
        
        logger.info(f"Loaded {len(data)} ARC-{self.challenge_set} samples")
        return data
    
    def evaluate_sample(self, sample: Dict[str, Any], prediction: str) -> bool:
        """Evaluate a single ARC sample."""
        prediction = prediction.strip().upper()
        
        if prediction in ["A", "B", "C", "D"]:
            return prediction == sample["answer"]
        
        # Try to extract choice from longer response
        for choice in ["A", "B", "C", "D"]:
            if choice in prediction:
                return choice == sample["answer"]
        
        return False
    
    def _format_single_example(self, sample: Dict[str, Any], include_answer: bool = False) -> str:
        """Format a single ARC example."""
        prompt = f"Question: {sample['question']}\n"
        
        choices = sample['choices']
        for i, choice in enumerate(choices):
            letter = chr(65 + i)  # A, B, C, D
            prompt += f"{letter}. {choice}\n"
        
        if include_answer:
            prompt += f"Answer: {sample['answer']}"
        else:
            prompt += "Answer:"
        
        return prompt


class GSM8K(BaseBenchmark):
    """
    GSM8K Benchmark
    
    Tests mathematical reasoning with grade school math word problems.
    """
    
    def __init__(self):
        config = BenchmarkConfig(
            name="GSM8K",
            description="Grade School Math 8K",
            num_choices=1,  # Open-ended numerical answers
            few_shot_examples=8
        )
        super().__init__(config)
    
    def load_data(self, max_samples: Optional[int] = None) -> List[Dict[str, Any]]:
        """Load GSM8K data with real dataset support."""
        if self.use_real_data:
            try:
                return self._load_real_gsm8k_data(max_samples)
            except Exception as e:
                logger.warning(f"Failed to load real GSM8K data: {e}. Falling back to placeholder data.")
                return self._load_placeholder_gsm8k_data(max_samples)
        else:
            return self._load_placeholder_gsm8k_data(max_samples)
    
    def _load_real_gsm8k_data(self, max_samples: Optional[int] = None) -> List[Dict[str, Any]]:
        """Load real GSM8K dataset with enhanced processing."""
        try:
            # Try HuggingFace datasets first
            data = self._load_gsm8k_from_huggingface(max_samples)
            if data:
                return data
        except Exception as e:
            logger.warning(f"Failed to load GSM8K from HuggingFace: {e}")
        
        try:
            # Fallback to direct download
            data_path = self.downloader.download_dataset("gsm8k")
            if not data_path or not data_path.exists():
                raise FileNotFoundError("GSM8K dataset not found")
            
            data = []
            
            with open(data_path, 'r', encoding='utf-8') as f:
                for i, line in enumerate(f):
                    if max_samples and i >= max_samples:
                        break
                    
                    try:
                        line = line.strip()
                        if not line:
                            continue
                            
                        item = json.loads(line)
                        
                        # Validate required fields
                        if not all(key in item for key in ["question", "answer"]):
                            logger.warning(f"Missing required fields in GSM8K item {i}")
                            continue
                        
                        question = str(item["question"]).strip()
                        answer_text = str(item["answer"]).strip()
                        
                        # Validate question quality
                        if not question or len(question) < 20:
                            continue
                        if not answer_text:
                            continue
                        
                        # Extract numerical answer with improved regex
                        answer = self._extract_numerical_answer(answer_text)
                        
                        sample = {
                            "question": question,
                            "answer": answer,
                            "solution": answer_text,
                            "id": f"gsm8k_{i}",
                            "source": "gsm8k_jsonl"
                        }
                        data.append(sample)
                        
                    except json.JSONDecodeError as e:
                        logger.warning(f"Failed to parse JSON in GSM8K line {i}: {e}")
                        continue
                    except Exception as e:
                        logger.warning(f"Error processing GSM8K item {i}: {e}")
                        continue
            
            logger.info(f"Loaded {len(data)} real GSM8K samples")
            return data
            
        except Exception as e:
            logger.error(f"Error loading GSM8K data: {e}")
            raise
    
    def _load_gsm8k_from_huggingface(self, max_samples: Optional[int] = None) -> List[Dict[str, Any]]:
        """Load GSM8K dataset from HuggingFace datasets."""
        try:
            from datasets import load_dataset
            
            logger.info("Loading GSM8K from HuggingFace datasets...")
            
            # Load the test split
            dataset = load_dataset("gsm8k", "main", split="test", trust_remote_code=True)
            
            if not dataset:
                return []
            
            data = []
            
            for i, sample in enumerate(dataset):
                if max_samples and i >= max_samples:
                    break
                
                # Extract data
                question = sample.get("question", "")
                answer_text = sample.get("answer", "")
                
                # Validate
                if not question or not answer_text:
                    continue
                
                # Extract numerical answer
                answer = self._extract_numerical_answer(answer_text)
                
                formatted_sample = {
                    "question": str(question).strip(),
                    "answer": answer,
                    "solution": str(answer_text).strip(),
                    "id": f"hf_gsm8k_{i}",
                    "source": "huggingface"
                }
                
                data.append(formatted_sample)
            
            logger.info(f"Loaded {len(data)} GSM8K samples from HuggingFace")
            return data
            
        except ImportError:
            logger.warning("HuggingFace datasets not available. Install with: pip install datasets")
            return []
        except Exception as e:
            logger.error(f"Error loading GSM8K from HuggingFace: {e}")
            return []
    
    def _extract_numerical_answer(self, answer_text: str) -> str:
        """Extract numerical answer from GSM8K solution text."""
        import re
        
        # Look for various patterns of final answers
        patterns = [
            r'#### (\d+(?:,\d{3})*(?:\.\d+)?)',  # #### format
            r'The answer is (\d+(?:,\d{3})*(?:\.\d+)?)',  # "The answer is X"
            r'Therefore, .*?(\d+(?:,\d{3})*(?:\.\d+)?)\.?\s*$',  # Therefore, ... X
            r'So .*?(\d+(?:,\d{3})*(?:\.\d+)?)\.?\s*$',  # So ... X
            r'(\d+(?:,\d{3})*(?:\.\d+)?)\.?\s*$',  # Number at the end
        ]
        
        for pattern in patterns:
            match = re.search(pattern, answer_text)
            if match:
                # Remove commas and return the number
                return match.group(1).replace(',', '')
        
        # Fallback: find all numbers and take the last one
        numbers = re.findall(r'\d+(?:,\d{3})*(?:\.\d+)?', answer_text)
        if numbers:
            return numbers[-1].replace(',', '')
        
        logger.warning(f"Could not extract numerical answer from: {answer_text[:100]}...")
        return "0"
    
    def _load_placeholder_gsm8k_data(self, max_samples: Optional[int] = None) -> List[Dict[str, Any]]:
        """Load placeholder GSM8K data."""
        data = []
        
        sample_problems = [
            {
                "question": "Janet has 12 apples. She gives 3 apples to her friend and eats 2 apples. How many apples does Janet have left?",
                "answer": "7"
            },
            {
                "question": "A school has 24 students in each class. If there are 5 classes, how many students are there in total?",
                "answer": "120"
            },
            {
                "question": "Tom buys 4 books for $8 each. How much money does Tom spend in total?",
                "answer": "32"
            },
            {
                "question": "Sarah has 36 stickers. She wants to put them equally into 6 albums. How many stickers will be in each album?",
                "answer": "6"
            },
            {
                "question": "A rectangle has a length of 15 cm and a width of 8 cm. What is the area of the rectangle?",
                "answer": "120"
            }
        ]
        
        for i, problem in enumerate(sample_problems):
            if max_samples and i >= max_samples:
                break
                
            sample = {
                "question": problem["question"],
                "answer": problem["answer"],
                "id": f"gsm8k_{i}"
            }
            data.append(sample)
        
        logger.info(f"Loaded {len(data)} placeholder GSM8K samples")
        return data
    
    def evaluate_sample(self, sample: Dict[str, Any], prediction: str) -> bool:
        """Evaluate a single GSM8K sample."""
        # Extract numerical answer from prediction
        prediction = prediction.strip()
        
        # Try to find the numerical answer
        import re
        numbers = re.findall(r'\d+', prediction)
        
        if numbers:
            # Take the last number found (often the final answer)
            predicted_answer = numbers[-1]
            return predicted_answer == sample["answer"]
        
        return False
    
    def _format_single_example(self, sample: Dict[str, Any], include_answer: bool = False) -> str:
        """Format a single GSM8K example."""
        prompt = f"Problem: {sample['question']}\n"
        
        if include_answer:
            prompt += f"Answer: {sample['answer']}"
        else:
            prompt += "Answer:"
        
        return prompt


# Convenience functions for creating benchmark instances
def create_mmlu_benchmark(subjects: Optional[List[str]] = None) -> MMLU:
    """Create MMLU benchmark instance."""
    return MMLU(subjects=subjects)


def create_hellaswag_benchmark() -> HellaSwag:
    """Create HellaSwag benchmark instance."""
    return HellaSwag()


def create_arc_benchmark(challenge_set: str = "easy") -> ARC:
    """Create ARC benchmark instance."""
    return ARC(challenge_set=challenge_set)


def create_gsm8k_benchmark() -> GSM8K:
    """Create GSM8K benchmark instance."""
    return GSM8K() 