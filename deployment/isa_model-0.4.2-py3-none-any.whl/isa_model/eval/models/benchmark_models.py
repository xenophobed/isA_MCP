"""
Benchmark Models

Specialized models for benchmark evaluations, comparisons, and result analysis.
"""

import logging
from datetime import datetime, timezone
from typing import Dict, List, Optional, Any, Union, Tuple
from dataclasses import dataclass, field
from enum import Enum
import statistics

logger = logging.getLogger(__name__)

class ComparisonType(str, Enum):
    """Comparison type enumeration"""
    HEAD_TO_HEAD = "head_to_head"
    MULTI_MODEL = "multi_model"
    BASELINE = "baseline"
    HISTORICAL = "historical"
    CROSS_VALIDATION = "cross_validation"

class SignificanceTest(str, Enum):
    """Statistical significance test enumeration"""
    T_TEST = "t_test"
    WILCOXON = "wilcoxon"
    MANN_WHITNEY = "mann_whitney"
    BOOTSTRAP = "bootstrap"
    PERMUTATION = "permutation"

class RankingMethod(str, Enum):
    """Ranking method enumeration"""
    AVERAGE_SCORE = "average_score"
    WEIGHTED_SCORE = "weighted_score"
    WIN_RATE = "win_rate"
    ELO_RATING = "elo_rating"
    TOURNAMENT = "tournament"

@dataclass
class MetricResult:
    """
    Individual metric result with statistical information
    
    Represents a single metric measurement with confidence intervals,
    statistical significance, and comparison data.
    """
    metric_name: str
    value: float
    unit: Optional[str] = None
    higher_is_better: bool = True
    sample_size: int = 1
    standard_deviation: Optional[float] = None
    confidence_interval: Optional[Tuple[float, float]] = None
    confidence_level: float = 0.95
    raw_values: Optional[List[float]] = None
    percentiles: Optional[Dict[str, float]] = None
    outliers: Optional[List[float]] = None
    distribution_type: Optional[str] = None
    
    def __post_init__(self):
        if self.raw_values and len(self.raw_values) > 1:
            self._calculate_statistics()
    
    def _calculate_statistics(self):
        """Calculate statistical measures from raw values"""
        if not self.raw_values or len(self.raw_values) < 2:
            return
        
        # Basic statistics
        self.value = statistics.mean(self.raw_values)
        self.standard_deviation = statistics.stdev(self.raw_values)
        
        # Percentiles
        sorted_values = sorted(self.raw_values)
        n = len(sorted_values)
        
        self.percentiles = {
            "p10": sorted_values[int(0.1 * n)],
            "p25": sorted_values[int(0.25 * n)],
            "p50": sorted_values[int(0.5 * n)],
            "p75": sorted_values[int(0.75 * n)],
            "p90": sorted_values[int(0.9 * n)],
            "p95": sorted_values[int(0.95 * n)],
            "p99": sorted_values[int(0.99 * n)] if n > 100 else sorted_values[-1]
        }
        
        # Confidence interval (using t-distribution for small samples)
        if self.sample_size > 1 and self.standard_deviation:
            import math
            
            # Simplified t-value for common confidence levels
            t_values = {0.90: 1.645, 0.95: 1.96, 0.99: 2.576}
            t_value = t_values.get(self.confidence_level, 1.96)
            
            if self.sample_size < 30:
                t_value *= 1.2  # Rough adjustment for t-distribution
            
            margin_error = t_value * (self.standard_deviation / math.sqrt(self.sample_size))
            self.confidence_interval = (
                self.value - margin_error,
                self.value + margin_error
            )
        
        # Detect outliers using IQR method
        if self.percentiles:
            q1, q3 = self.percentiles["p25"], self.percentiles["p75"]
            iqr = q3 - q1
            lower_bound = q1 - 1.5 * iqr
            upper_bound = q3 + 1.5 * iqr
            
            self.outliers = [v for v in self.raw_values 
                           if v < lower_bound or v > upper_bound]
    
    @property
    def coefficient_of_variation(self) -> Optional[float]:
        """Calculate coefficient of variation (std/mean)"""
        if self.standard_deviation and self.value != 0:
            return self.standard_deviation / abs(self.value)
        return None
    
    @property
    def is_stable(self) -> bool:
        """Check if metric shows stable performance (low variation)"""
        cv = self.coefficient_of_variation
        if cv is None:
            return True
        return cv < 0.1  # Less than 10% variation
    
    @property
    def has_outliers(self) -> bool:
        """Check if there are significant outliers"""
        return bool(self.outliers and len(self.outliers) > 0)
    
    def format_with_confidence(self, precision: int = 3) -> str:
        """Format value with confidence interval"""
        base = f"{self.value:.{precision}f}"
        if self.unit:
            base += f" {self.unit}"
        
        if self.confidence_interval:
            ci_lower, ci_upper = self.confidence_interval
            base += f" (CI: {ci_lower:.{precision}f}-{ci_upper:.{precision}f})"
        
        return base
    
    def is_better_than(self, other: 'MetricResult', threshold: float = 0.01) -> Optional[bool]:
        """Compare this metric to another with significance threshold"""
        if not isinstance(other, MetricResult) or self.metric_name != other.metric_name:
            return None
        
        difference = abs(self.value - other.value)
        relative_difference = difference / max(abs(self.value), abs(other.value), 1e-8)
        
        if relative_difference < threshold:
            return None  # Not significantly different
        
        if self.higher_is_better:
            return self.value > other.value
        else:
            return self.value < other.value

@dataclass
class BenchmarkResult:
    """
    Complete benchmark result with multiple metrics and analysis
    
    Represents the full results from a benchmark evaluation including
    all metrics, statistical analysis, and performance summaries.
    """
    benchmark_id: str
    benchmark_name: str
    model_id: str
    model_name: Optional[str] = None
    dataset_name: Optional[str] = None
    metrics: Dict[str, MetricResult] = field(default_factory=dict)
    overall_score: Optional[float] = None
    ranking_position: Optional[int] = None
    total_participants: Optional[int] = None
    execution_time_seconds: Optional[float] = None
    cost_usd: Optional[float] = None
    timestamp: datetime = None
    metadata: Dict[str, Any] = field(default_factory=dict)
    error_analysis: Optional[Dict[str, Any]] = None
    performance_breakdown: Optional[Dict[str, Any]] = None
    
    def __post_init__(self):
        if self.timestamp is None:
            self.timestamp = datetime.now(timezone.utc)
        
        # Calculate overall score if not provided
        if self.overall_score is None and self.metrics:
            self._calculate_overall_score()
    
    def _calculate_overall_score(self):
        """Calculate overall benchmark score from individual metrics"""
        if not self.metrics:
            return
        
        # Get all numeric metric values
        scores = []
        weights = []
        
        for metric_name, metric_result in self.metrics.items():
            if isinstance(metric_result.value, (int, float)):
                # Normalize to 0-100 scale if needed
                normalized_value = metric_result.value
                if metric_result.unit == "percentage" or 0 <= normalized_value <= 1:
                    normalized_value *= 100
                elif normalized_value > 100:
                    normalized_value = min(100, normalized_value / 10)  # Simple normalization
                
                scores.append(normalized_value)
                # Equal weights for now, could be configurable
                weights.append(1.0)
        
        if scores:
            self.overall_score = sum(s * w for s, w in zip(scores, weights)) / sum(weights)
    
    @property
    def grade(self) -> str:
        """Get letter grade based on overall score"""
        if self.overall_score is None:
            return "N/A"
        
        if self.overall_score >= 90:
            return "A"
        elif self.overall_score >= 80:
            return "B"
        elif self.overall_score >= 70:
            return "C"
        elif self.overall_score >= 60:
            return "D"
        else:
            return "F"
    
    @property
    def performance_tier(self) -> str:
        """Get performance tier classification"""
        if self.overall_score is None:
            return "unknown"
        
        if self.overall_score >= 95:
            return "exceptional"
        elif self.overall_score >= 85:
            return "excellent"
        elif self.overall_score >= 75:
            return "good"
        elif self.overall_score >= 65:
            return "average"
        elif self.overall_score >= 50:
            return "below_average"
        else:
            return "poor"
    
    @property
    def cost_efficiency(self) -> Optional[float]:
        """Calculate cost efficiency (score per dollar)"""
        if self.overall_score and self.cost_usd and self.cost_usd > 0:
            return self.overall_score / self.cost_usd
        return None
    
    @property
    def throughput(self) -> Optional[float]:
        """Calculate throughput (score per second)"""
        if self.overall_score and self.execution_time_seconds and self.execution_time_seconds > 0:
            return self.overall_score / self.execution_time_seconds
        return None
    
    def get_metric(self, metric_name: str) -> Optional[MetricResult]:
        """Get specific metric result"""
        return self.metrics.get(metric_name)
    
    def add_metric(self, metric_name: str, value: float, **kwargs):
        """Add metric result"""
        self.metrics[metric_name] = MetricResult(
            metric_name=metric_name,
            value=value,
            **kwargs
        )
        self._calculate_overall_score()
    
    def get_performance_summary(self) -> Dict[str, Any]:
        """Get comprehensive performance summary"""
        summary = {
            "model_id": self.model_id,
            "benchmark_name": self.benchmark_name,
            "overall_score": self.overall_score,
            "grade": self.grade,
            "performance_tier": self.performance_tier,
            "ranking_position": self.ranking_position,
            "total_participants": self.total_participants,
            "execution_time_seconds": self.execution_time_seconds,
            "cost_usd": self.cost_usd,
            "cost_efficiency": self.cost_efficiency,
            "throughput": self.throughput,
            "metric_count": len(self.metrics),
            "stable_metrics": sum(1 for m in self.metrics.values() if m.is_stable),
            "metrics_with_outliers": sum(1 for m in self.metrics.values() if m.has_outliers)
        }
        
        return {k: v for k, v in summary.items() if v is not None}
    
    def compare_to_baseline(self, baseline: 'BenchmarkResult') -> Dict[str, Any]:
        """Compare this result to a baseline"""
        if not isinstance(baseline, BenchmarkResult):
            return {}
        
        comparison = {
            "baseline_model": baseline.model_id,
            "overall_improvement": None,
            "metric_comparisons": {},
            "better_metrics": 0,
            "worse_metrics": 0,
            "similar_metrics": 0
        }
        
        # Overall score comparison
        if self.overall_score and baseline.overall_score:
            improvement = ((self.overall_score - baseline.overall_score) / baseline.overall_score) * 100
            comparison["overall_improvement"] = round(improvement, 2)
        
        # Metric-by-metric comparison
        for metric_name, our_metric in self.metrics.items():
            baseline_metric = baseline.get_metric(metric_name)
            if baseline_metric:
                comparison_result = our_metric.is_better_than(baseline_metric)
                
                if comparison_result is True:
                    comparison["better_metrics"] += 1
                    status = "better"
                elif comparison_result is False:
                    comparison["worse_metrics"] += 1
                    status = "worse"
                else:
                    comparison["similar_metrics"] += 1
                    status = "similar"
                
                improvement = None
                if baseline_metric.value != 0:
                    improvement = ((our_metric.value - baseline_metric.value) / baseline_metric.value) * 100
                
                comparison["metric_comparisons"][metric_name] = {
                    "status": status,
                    "our_value": our_metric.value,
                    "baseline_value": baseline_metric.value,
                    "improvement_percentage": round(improvement, 2) if improvement else None
                }
        
        return comparison

@dataclass
class ComparisonResult:
    """
    Multi-model comparison result
    
    Contains results and analysis from comparing multiple models on the same benchmark.
    """
    comparison_id: str
    comparison_name: str
    benchmark_name: str
    dataset_name: str
    comparison_type: str = ComparisonType.MULTI_MODEL
    model_results: Dict[str, BenchmarkResult] = field(default_factory=dict)
    rankings: Optional[Dict[str, int]] = None
    ranking_method: str = RankingMethod.AVERAGE_SCORE
    statistical_tests: Dict[str, Any] = field(default_factory=dict)
    significance_level: float = 0.05
    pairwise_comparisons: Dict[str, Dict[str, Any]] = field(default_factory=dict)
    meta_analysis: Optional[Dict[str, Any]] = None
    created_at: datetime = None
    
    def __post_init__(self):
        if self.created_at is None:
            self.created_at = datetime.now(timezone.utc)
        
        if self.rankings is None and self.model_results:
            self._calculate_rankings()
    
    def _calculate_rankings(self):
        """Calculate model rankings based on overall scores"""
        if not self.model_results:
            return
        
        # Sort models by overall score (descending)
        sorted_models = sorted(
            self.model_results.items(),
            key=lambda x: x[1].overall_score or 0,
            reverse=True
        )
        
        self.rankings = {model_id: rank + 1 for rank, (model_id, _) in enumerate(sorted_models)}
        
        # Update ranking positions in individual results
        for model_id, rank in self.rankings.items():
            if model_id in self.model_results:
                self.model_results[model_id].ranking_position = rank
                self.model_results[model_id].total_participants = len(self.model_results)
    
    @property
    def winner(self) -> Optional[str]:
        """Get the winning model ID"""
        if not self.rankings:
            return None
        return min(self.rankings.keys(), key=lambda x: self.rankings[x])
    
    @property
    def top_models(self, n: int = 3) -> List[str]:
        """Get top N model IDs"""
        if not self.rankings:
            return []
        
        sorted_models = sorted(self.rankings.items(), key=lambda x: x[1])
        return [model_id for model_id, _ in sorted_models[:n]]
    
    @property
    def has_significant_differences(self) -> bool:
        """Check if there are statistically significant differences between models"""
        return any(
            result.get("significant", False) 
            for result in self.statistical_tests.values()
        )
    
    def add_model_result(self, model_id: str, result: BenchmarkResult):
        """Add model result to comparison"""
        self.model_results[model_id] = result
        self._calculate_rankings()
    
    def get_model_rank(self, model_id: str) -> Optional[int]:
        """Get rank for specific model"""
        return self.rankings.get(model_id) if self.rankings else None
    
    def get_ranking_table(self) -> List[Dict[str, Any]]:
        """Get formatted ranking table"""
        if not self.rankings or not self.model_results:
            return []
        
        table = []
        for model_id, rank in sorted(self.rankings.items(), key=lambda x: x[1]):
            result = self.model_results[model_id]
            table.append({
                "rank": rank,
                "model_id": model_id,
                "model_name": result.model_name or model_id,
                "overall_score": result.overall_score,
                "grade": result.grade,
                "execution_time": result.execution_time_seconds,
                "cost_usd": result.cost_usd,
                "cost_efficiency": result.cost_efficiency
            })
        
        return table
    
    def perform_pairwise_comparisons(self, metric_name: Optional[str] = None):
        """Perform all pairwise comparisons between models"""
        models = list(self.model_results.keys())
        
        for i, model_a in enumerate(models):
            for j, model_b in enumerate(models[i+1:], i+1):
                comparison_key = f"{model_a}_vs_{model_b}"
                
                result_a = self.model_results[model_a]
                result_b = self.model_results[model_b]
                
                if metric_name:
                    # Compare specific metric
                    metric_a = result_a.get_metric(metric_name)
                    metric_b = result_b.get_metric(metric_name)
                    
                    if metric_a and metric_b:
                        is_better = metric_a.is_better_than(metric_b)
                        self.pairwise_comparisons[comparison_key] = {
                            "metric": metric_name,
                            "model_a_value": metric_a.value,
                            "model_b_value": metric_b.value,
                            "winner": model_a if is_better else (model_b if is_better is False else "tie")
                        }
                else:
                    # Compare overall scores
                    self.pairwise_comparisons[comparison_key] = {
                        "metric": "overall_score",
                        "model_a_score": result_a.overall_score,
                        "model_b_score": result_b.overall_score,
                        "winner": model_a if (result_a.overall_score or 0) > (result_b.overall_score or 0) else model_b
                    }
    
    def get_win_matrix(self) -> Dict[str, Dict[str, str]]:
        """Get win/loss matrix for all models"""
        if not self.pairwise_comparisons:
            self.perform_pairwise_comparisons()
        
        models = list(self.model_results.keys())
        matrix = {model: {other: "N/A" for other in models} for model in models}
        
        # Diagonal should be ties
        for model in models:
            matrix[model][model] = "tie"
        
        # Fill in comparisons
        for comparison_key, result in self.pairwise_comparisons.items():
            model_a, model_b = comparison_key.split("_vs_")
            winner = result["winner"]
            
            if winner == model_a:
                matrix[model_a][model_b] = "win"
                matrix[model_b][model_a] = "loss"
            elif winner == model_b:
                matrix[model_a][model_b] = "loss"
                matrix[model_b][model_a] = "win"
            else:
                matrix[model_a][model_b] = "tie"
                matrix[model_b][model_a] = "tie"
        
        return matrix
    
    def generate_summary_report(self) -> Dict[str, Any]:
        """Generate comprehensive comparison summary"""
        summary = {
            "comparison_overview": {
                "comparison_name": self.comparison_name,
                "benchmark_name": self.benchmark_name,
                "dataset_name": self.dataset_name,
                "comparison_type": self.comparison_type,
                "total_models": len(self.model_results),
                "ranking_method": self.ranking_method
            },
            "winner": self.winner,
            "top_models": self.top_models,
            "rankings": self.rankings,
            "statistical_significance": self.has_significant_differences,
            "ranking_table": self.get_ranking_table()
        }
        
        # Add performance statistics
        scores = [r.overall_score for r in self.model_results.values() if r.overall_score]
        if scores:
            summary["score_statistics"] = {
                "mean": statistics.mean(scores),
                "median": statistics.median(scores),
                "std_dev": statistics.stdev(scores) if len(scores) > 1 else 0,
                "min": min(scores),
                "max": max(scores),
                "range": max(scores) - min(scores)
            }
        
        return summary

# Utility functions

def create_benchmark_result(
    model_id: str,
    benchmark_name: str,
    metrics: Dict[str, float],
    **kwargs
) -> BenchmarkResult:
    """Factory function to create benchmark result"""
    import uuid
    
    benchmark_id = f"bench_{datetime.now().strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:8]}"
    
    # Convert simple metrics to MetricResult objects
    metric_results = {}
    for name, value in metrics.items():
        metric_results[name] = MetricResult(
            metric_name=name,
            value=value,
            higher_is_better=not any(keyword in name.lower() for keyword in ['error', 'loss', 'latency', 'time'])
        )
    
    return BenchmarkResult(
        benchmark_id=benchmark_id,
        benchmark_name=benchmark_name,
        model_id=model_id,
        metrics=metric_results,
        **kwargs
    )

def compare_models(
    model_results: Dict[str, BenchmarkResult],
    comparison_name: str,
    benchmark_name: str,
    dataset_name: str
) -> ComparisonResult:
    """Factory function to create model comparison"""
    import uuid
    
    comparison_id = f"comp_{datetime.now().strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:8]}"
    
    return ComparisonResult(
        comparison_id=comparison_id,
        comparison_name=comparison_name,
        benchmark_name=benchmark_name,
        dataset_name=dataset_name,
        model_results=model_results
    )