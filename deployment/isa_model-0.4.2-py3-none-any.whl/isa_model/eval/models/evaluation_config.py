"""
Evaluation Configuration Models

Configuration models for evaluation operations, providing structured configuration
management for different evaluation types, benchmarks, and datasets.
"""

import logging
from datetime import datetime, timezone
from typing import Dict, List, Optional, Any, Union
from dataclasses import dataclass, field
from enum import Enum

logger = logging.getLogger(__name__)

class SamplingStrategy(str, Enum):
    """Sampling strategy enumeration"""
    FULL = "full"
    RANDOM = "random"
    STRATIFIED = "stratified"
    SYSTEMATIC = "systematic"
    BOOTSTRAP = "bootstrap"

class MetricAggregation(str, Enum):
    """Metric aggregation method enumeration"""
    MEAN = "mean"
    MEDIAN = "median"
    WEIGHTED_MEAN = "weighted_mean"
    MAX = "max"
    MIN = "min"
    MODE = "mode"

class ValidationStrategy(str, Enum):
    """Validation strategy enumeration"""
    HOLD_OUT = "hold_out"
    CROSS_VALIDATION = "cross_validation"
    BOOTSTRAP = "bootstrap"
    TIME_SERIES_SPLIT = "time_series_split"

@dataclass
class DatasetConfig:
    """
    Dataset configuration for evaluations
    
    Defines how to load, preprocess, and sample datasets for evaluation.
    """
    dataset_name: str
    dataset_source: str  # "huggingface", "local", "url", "database"
    dataset_path: Optional[str] = None
    split: str = "test"
    sampling_strategy: str = SamplingStrategy.FULL
    sample_size: Optional[int] = None
    random_seed: int = 42
    preprocessing_config: Optional[Dict[str, Any]] = None
    filtering_config: Optional[Dict[str, Any]] = None
    feature_columns: Optional[List[str]] = None
    target_column: Optional[str] = None
    text_column: Optional[str] = None
    image_column: Optional[str] = None
    audio_column: Optional[str] = None
    metadata_columns: Optional[List[str]] = None
    data_format: str = "auto"  # "json", "csv", "parquet", "arrow", "auto"
    cache_dataset: bool = True
    streaming: bool = False
    
    def __post_init__(self):
        if self.preprocessing_config is None:
            self.preprocessing_config = {}
        if self.filtering_config is None:
            self.filtering_config = {}
        if self.feature_columns is None:
            self.feature_columns = []
        if self.metadata_columns is None:
            self.metadata_columns = []
    
    @property
    def is_multimodal(self) -> bool:
        """Check if dataset contains multimodal data"""
        modalities = [self.text_column, self.image_column, self.audio_column]
        return sum(1 for m in modalities if m is not None) > 1
    
    @property
    def primary_modality(self) -> Optional[str]:
        """Get primary data modality"""
        if self.text_column:
            return "text"
        elif self.image_column:
            return "image"
        elif self.audio_column:
            return "audio"
        return None
    
    def validate(self) -> List[str]:
        """Validate dataset configuration"""
        issues = []
        
        if not self.dataset_name:
            issues.append("Dataset name is required")
        
        if not self.dataset_source:
            issues.append("Dataset source is required")
        
        if self.sample_size and self.sample_size < 1:
            issues.append("Sample size must be positive")
        
        if self.sampling_strategy == SamplingStrategy.RANDOM and not self.sample_size:
            issues.append("Sample size required for random sampling")
        
        # Check for required columns based on evaluation type
        required_columns = [self.text_column, self.image_column, self.audio_column, self.target_column]
        if not any(required_columns):
            issues.append("At least one data column must be specified")
        
        return issues
    
    def get_preprocessing_step(self, step_name: str, default: Any = None) -> Any:
        """Get preprocessing configuration step"""
        return self.preprocessing_config.get(step_name, default)
    
    def add_preprocessing_step(self, step_name: str, config: Dict[str, Any]):
        """Add preprocessing step"""
        self.preprocessing_config[step_name] = config
    
    def add_filter(self, filter_name: str, filter_config: Dict[str, Any]):
        """Add data filter"""
        self.filtering_config[filter_name] = filter_config

@dataclass
class BenchmarkConfig:
    """
    Benchmark configuration for standardized evaluations
    
    Defines benchmark-specific settings and parameters.
    """
    benchmark_name: str
    benchmark_type: str  # "standard", "custom", "comparative"
    version: str = "latest"
    reference_models: Optional[List[str]] = None
    baseline_scores: Optional[Dict[str, float]] = None
    evaluation_metrics: Optional[List[str]] = None
    metric_weights: Optional[Dict[str, float]] = None
    aggregation_method: str = MetricAggregation.MEAN
    normalization_method: Optional[str] = None
    comparative_analysis: bool = False
    statistical_tests: Optional[List[str]] = None
    confidence_level: float = 0.95
    custom_scoring_function: Optional[str] = None
    benchmark_metadata: Optional[Dict[str, Any]] = None
    
    def __post_init__(self):
        if self.reference_models is None:
            self.reference_models = []
        if self.baseline_scores is None:
            self.baseline_scores = {}
        if self.evaluation_metrics is None:
            self.evaluation_metrics = []
        if self.metric_weights is None:
            self.metric_weights = {}
        if self.statistical_tests is None:
            self.statistical_tests = []
        if self.benchmark_metadata is None:
            self.benchmark_metadata = {}
    
    @property
    def is_comparative(self) -> bool:
        """Check if benchmark includes comparative analysis"""
        return self.comparative_analysis or len(self.reference_models) > 0
    
    @property
    def weighted_metrics(self) -> bool:
        """Check if metrics use weighted aggregation"""
        return len(self.metric_weights) > 0
    
    def validate(self) -> List[str]:
        """Validate benchmark configuration"""
        issues = []
        
        if not self.benchmark_name:
            issues.append("Benchmark name is required")
        
        if not self.benchmark_type:
            issues.append("Benchmark type is required")
        
        if self.confidence_level <= 0 or self.confidence_level >= 1:
            issues.append("Confidence level must be between 0 and 1")
        
        # Validate metric weights sum to 1 if weighted
        if self.metric_weights:
            total_weight = sum(self.metric_weights.values())
            if abs(total_weight - 1.0) > 0.01:
                issues.append("Metric weights should sum to 1.0")
        
        return issues
    
    def get_metric_weight(self, metric_name: str) -> float:
        """Get weight for specific metric"""
        if not self.metric_weights:
            return 1.0 / len(self.evaluation_metrics) if self.evaluation_metrics else 1.0
        return self.metric_weights.get(metric_name, 0.0)
    
    def add_reference_model(self, model_id: str, baseline_score: Optional[float] = None):
        """Add reference model for comparison"""
        if model_id not in self.reference_models:
            self.reference_models.append(model_id)
        if baseline_score is not None:
            self.baseline_scores[model_id] = baseline_score
    
    def calculate_weighted_score(self, metric_scores: Dict[str, float]) -> float:
        """Calculate weighted benchmark score"""
        if not self.metric_weights:
            # Equal weighting
            return sum(metric_scores.values()) / len(metric_scores) if metric_scores else 0.0
        
        weighted_sum = 0.0
        total_weight = 0.0
        
        for metric, score in metric_scores.items():
            weight = self.metric_weights.get(metric, 0.0)
            weighted_sum += score * weight
            total_weight += weight
        
        return weighted_sum / total_weight if total_weight > 0 else 0.0

@dataclass
class ModelConfig:
    """
    Model configuration for evaluation
    
    Defines model-specific parameters and settings for evaluation.
    """
    model_id: str
    model_type: str  # "llm", "vision", "audio", "embedding", "multimodal"
    provider: Optional[str] = None
    model_version: Optional[str] = None
    inference_config: Optional[Dict[str, Any]] = None
    context_length: Optional[int] = None
    temperature: Optional[float] = None
    max_tokens: Optional[int] = None
    batch_size: int = 1
    timeout_seconds: int = 300
    retry_attempts: int = 3
    custom_prompt_template: Optional[str] = None
    system_message: Optional[str] = None
    preprocessing_required: bool = False
    postprocessing_required: bool = False
    
    def __post_init__(self):
        if self.inference_config is None:
            self.inference_config = {}
    
    @property
    def supports_batching(self) -> bool:
        """Check if model supports batch inference"""
        return self.batch_size > 1
    
    def validate(self) -> List[str]:
        """Validate model configuration"""
        issues = []
        
        if not self.model_id:
            issues.append("Model ID is required")
        
        if not self.model_type:
            issues.append("Model type is required")
        
        if self.batch_size < 1:
            issues.append("Batch size must be at least 1")
        
        if self.timeout_seconds < 1:
            issues.append("Timeout must be positive")
        
        if self.temperature is not None and (self.temperature < 0 or self.temperature > 2):
            issues.append("Temperature should be between 0 and 2")
        
        return issues
    
    def get_inference_parameter(self, param_name: str, default: Any = None) -> Any:
        """Get inference parameter"""
        return self.inference_config.get(param_name, default)
    
    def set_inference_parameter(self, param_name: str, value: Any):
        """Set inference parameter"""
        self.inference_config[param_name] = value

@dataclass
class EvaluationConfig:
    """
    Complete evaluation configuration
    
    Combines all configuration aspects for an evaluation including dataset,
    benchmark, model, and execution settings.
    """
    config_id: Optional[str] = None
    config_name: Optional[str] = None
    evaluation_type: str = "benchmark"
    dataset_config: Optional[DatasetConfig] = None
    benchmark_config: Optional[BenchmarkConfig] = None
    model_config: Optional[ModelConfig] = None
    validation_strategy: str = ValidationStrategy.HOLD_OUT
    validation_split: float = 0.2
    cross_validation_folds: int = 5
    parallel_execution: bool = False
    max_parallel_workers: int = 4
    save_predictions: bool = True
    save_intermediate_results: bool = False
    early_stopping: bool = False
    early_stopping_patience: int = 10
    early_stopping_threshold: float = 0.01
    resource_limits: Optional[Dict[str, Any]] = None
    notification_config: Optional[Dict[str, Any]] = None
    experiment_tracking: Optional[Dict[str, Any]] = None
    created_at: datetime = None
    updated_at: datetime = None
    created_by: Optional[str] = None
    updated_by: Optional[str] = None
    version: str = "1.0"
    is_template: bool = False
    tags: Optional[Dict[str, str]] = None
    
    def __post_init__(self):
        if self.created_at is None:
            self.created_at = datetime.now(timezone.utc)
        if self.updated_at is None:
            self.updated_at = self.created_at
        if self.resource_limits is None:
            self.resource_limits = {}
        if self.notification_config is None:
            self.notification_config = {}
        if self.experiment_tracking is None:
            self.experiment_tracking = {}
        if self.tags is None:
            self.tags = {}
        
        # Create default configs if not provided
        if self.dataset_config is None and self.config_name:
            self.dataset_config = DatasetConfig(
                dataset_name=f"default_dataset_{self.config_name}",
                dataset_source="local"
            )
    
    @property
    def estimated_duration_minutes(self) -> Optional[int]:
        """Estimate evaluation duration in minutes"""
        if not self.dataset_config or not self.model_config:
            return None
        
        # Basic estimation based on sample size and batch size
        sample_size = self.dataset_config.sample_size or 1000
        batch_size = self.model_config.batch_size
        timeout_per_request = self.model_config.timeout_seconds
        
        total_batches = (sample_size + batch_size - 1) // batch_size
        estimated_seconds = total_batches * timeout_per_request * 0.3  # 30% of timeout on average
        
        return max(1, int(estimated_seconds / 60))
    
    @property
    def requires_gpu(self) -> bool:
        """Check if evaluation requires GPU resources"""
        if not self.model_config:
            return False
        
        # Heuristic based on model type and size
        gpu_requiring_types = ["vision", "audio", "multimodal"]
        return (self.model_config.model_type in gpu_requiring_types or
                "large" in self.model_config.model_id.lower() or
                "xl" in self.model_config.model_id.lower())
    
    @property
    def is_comparative_evaluation(self) -> bool:
        """Check if this is a comparative evaluation"""
        return (self.benchmark_config and self.benchmark_config.is_comparative)
    
    def validate(self) -> List[str]:
        """Validate complete evaluation configuration"""
        issues = []
        
        if not self.evaluation_type:
            issues.append("Evaluation type is required")
        
        if self.validation_split <= 0 or self.validation_split >= 1:
            issues.append("Validation split must be between 0 and 1")
        
        if self.cross_validation_folds < 2:
            issues.append("Cross-validation requires at least 2 folds")
        
        if self.max_parallel_workers < 1:
            issues.append("Max parallel workers must be at least 1")
        
        # Validate sub-configurations
        if self.dataset_config:
            issues.extend([f"Dataset: {issue}" for issue in self.dataset_config.validate()])
        
        if self.benchmark_config:
            issues.extend([f"Benchmark: {issue}" for issue in self.benchmark_config.validate()])
        
        if self.model_config:
            issues.extend([f"Model: {issue}" for issue in self.model_config.validate()])
        
        return issues
    
    def merge_with(self, other: 'EvaluationConfig') -> 'EvaluationConfig':
        """Merge this configuration with another"""
        merged = EvaluationConfig()
        
        # Copy all fields from self
        for field_name in self.__dataclass_fields__:
            setattr(merged, field_name, getattr(self, field_name))
        
        # Override with non-None values from other
        for field_name in other.__dataclass_fields__:
            other_value = getattr(other, field_name)
            if other_value is not None:
                setattr(merged, field_name, other_value)
        
        merged.updated_at = datetime.now(timezone.utc)
        return merged
    
    def get_resource_limit(self, resource_type: str, default: Any = None) -> Any:
        """Get resource limit"""
        return self.resource_limits.get(resource_type, default)
    
    def set_resource_limit(self, resource_type: str, limit: Any):
        """Set resource limit"""
        self.resource_limits[resource_type] = limit
        self.updated_at = datetime.now(timezone.utc)
    
    def add_tag(self, key: str, value: str):
        """Add configuration tag"""
        self.tags[key] = value
        self.updated_at = datetime.now(timezone.utc)

# Factory functions for common evaluation configurations

def create_llm_benchmark_config(
    model_id: str,
    benchmark_name: str,
    dataset_name: str,
    sample_size: Optional[int] = None
) -> EvaluationConfig:
    """Create LLM benchmark evaluation configuration"""
    return EvaluationConfig(
        evaluation_type="benchmark",
        dataset_config=DatasetConfig(
            dataset_name=dataset_name,
            dataset_source="huggingface",
            sample_size=sample_size,
            text_column="text",
            target_column="label"
        ),
        benchmark_config=BenchmarkConfig(
            benchmark_name=benchmark_name,
            benchmark_type="standard",
            evaluation_metrics=["accuracy", "f1_score", "precision", "recall"]
        ),
        model_config=ModelConfig(
            model_id=model_id,
            model_type="llm",
            batch_size=4,
            timeout_seconds=120
        )
    )

def create_vision_evaluation_config(
    model_id: str,
    dataset_name: str,
    image_column: str = "image",
    target_column: str = "label"
) -> EvaluationConfig:
    """Create vision model evaluation configuration"""
    return EvaluationConfig(
        evaluation_type="accuracy",
        dataset_config=DatasetConfig(
            dataset_name=dataset_name,
            dataset_source="huggingface",
            image_column=image_column,
            target_column=target_column
        ),
        model_config=ModelConfig(
            model_id=model_id,
            model_type="vision",
            batch_size=8,
            timeout_seconds=60
        )
    )

def create_comparative_evaluation_config(
    model_ids: List[str],
    benchmark_name: str,
    dataset_name: str
) -> EvaluationConfig:
    """Create comparative evaluation configuration for multiple models"""
    # This would create a configuration for comparing multiple models
    # In practice, this might involve creating multiple evaluation tasks
    
    return EvaluationConfig(
        evaluation_type="comparison",
        dataset_config=DatasetConfig(
            dataset_name=dataset_name,
            dataset_source="huggingface"
        ),
        benchmark_config=BenchmarkConfig(
            benchmark_name=benchmark_name,
            benchmark_type="comparative",
            reference_models=model_ids[1:],  # Use first as primary, others as references
            comparative_analysis=True,
            statistical_tests=["t_test", "wilcoxon"]
        ),
        model_config=ModelConfig(
            model_id=model_ids[0],  # Primary model
            model_type="llm"
        )
    )