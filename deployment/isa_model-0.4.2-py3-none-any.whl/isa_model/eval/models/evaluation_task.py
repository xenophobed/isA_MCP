"""
Evaluation Task Models

Core data models for evaluation tasks, results, and metrics, extracted from repository layer
to follow the standard ISA Model architecture pattern.
"""

import logging
from datetime import datetime, timezone
from typing import Dict, List, Optional, Any, Union
from dataclasses import dataclass, field
from enum import Enum

logger = logging.getLogger(__name__)

class EvaluationStatus(str, Enum):
    """Evaluation status enumeration"""
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"
    PAUSED = "paused"

class EvaluationType(str, Enum):
    """Evaluation type enumeration"""
    BENCHMARK = "benchmark"
    CUSTOM = "custom"
    COMPARISON = "comparison"
    REGRESSION = "regression"
    PERFORMANCE = "performance"
    ACCURACY = "accuracy"

class EvaluatorType(str, Enum):
    """Evaluator type enumeration"""
    LLM = "llm"
    VISION = "vision"
    AUDIO = "audio"
    EMBEDDING = "embedding"
    MULTIMODAL = "multimodal"
    CUSTOM = "custom"

class MetricType(str, Enum):
    """Metric type enumeration"""
    ACCURACY = "accuracy"
    PRECISION = "precision"
    RECALL = "recall"
    F1_SCORE = "f1_score"
    BLEU = "bleu"
    ROUGE = "rouge"
    PERPLEXITY = "perplexity"
    COSINE_SIMILARITY = "cosine_similarity"
    LATENCY = "latency"
    THROUGHPUT = "throughput"
    COST = "cost"
    CUSTOM = "custom"

@dataclass
class EvaluationTask:
    """
    Core evaluation task model
    
    Represents an evaluation task with its configuration, status, and metadata.
    """
    task_id: str
    task_name: str
    model_id: str
    evaluator_type: str
    dataset_name: str
    config: Dict[str, Any]
    status: str = EvaluationStatus.PENDING
    evaluation_type: str = EvaluationType.BENCHMARK
    priority: int = 5  # 1-10 scale, 10 being highest
    created_at: datetime = None
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    estimated_duration_minutes: Optional[int] = None
    actual_duration_minutes: Optional[int] = None
    user_id: Optional[str] = None
    project_name: Optional[str] = None
    experiment_id: Optional[str] = None
    parent_task_id: Optional[str] = None  # For sub-tasks
    tags: Optional[Dict[str, str]] = None
    error_message: Optional[str] = None
    progress_percentage: float = 0.0
    samples_processed: int = 0
    total_samples: Optional[int] = None
    resource_usage: Optional[Dict[str, Any]] = None
    
    def __post_init__(self):
        if self.created_at is None:
            self.created_at = datetime.now(timezone.utc)
        if self.tags is None:
            self.tags = {}
        if self.resource_usage is None:
            self.resource_usage = {}
    
    @property
    def is_active(self) -> bool:
        """Check if task is in an active state"""
        return self.status in [EvaluationStatus.PENDING, EvaluationStatus.RUNNING, EvaluationStatus.PAUSED]
    
    @property
    def is_completed(self) -> bool:
        """Check if task is completed (successfully or not)"""
        return self.status in [EvaluationStatus.COMPLETED, EvaluationStatus.FAILED, EvaluationStatus.CANCELLED]
    
    @property
    def duration_seconds(self) -> Optional[int]:
        """Calculate task duration in seconds"""
        if self.started_at and self.completed_at:
            return int((self.completed_at - self.started_at).total_seconds())
        elif self.started_at and self.status == EvaluationStatus.RUNNING:
            return int((datetime.now(timezone.utc) - self.started_at).total_seconds())
        return None
    
    @property
    def estimated_completion_time(self) -> Optional[datetime]:
        """Estimate completion time based on progress"""
        if (self.started_at and self.progress_percentage > 0 and 
            self.status == EvaluationStatus.RUNNING):
            elapsed = datetime.now(timezone.utc) - self.started_at
            total_estimated = elapsed.total_seconds() / (self.progress_percentage / 100)
            return self.started_at + timedelta(seconds=total_estimated)
        return None
    
    def update_status(self, new_status: str, error_message: Optional[str] = None):
        """Update task status with timestamp"""
        old_status = self.status
        self.status = new_status
        
        now = datetime.now(timezone.utc)
        
        if new_status == EvaluationStatus.RUNNING and old_status == EvaluationStatus.PENDING:
            self.started_at = now
        elif new_status in [EvaluationStatus.COMPLETED, EvaluationStatus.FAILED, EvaluationStatus.CANCELLED]:
            if not self.completed_at:
                self.completed_at = now
            if self.started_at:
                self.actual_duration_minutes = int((self.completed_at - self.started_at).total_seconds() / 60)
        
        if error_message:
            self.error_message = error_message
        
        logger.info(f"Task {self.task_id} status updated: {old_status} -> {new_status}")
    
    def update_progress(self, samples_processed: int, total_samples: Optional[int] = None):
        """Update task progress"""
        self.samples_processed = samples_processed
        if total_samples:
            self.total_samples = total_samples
        
        if self.total_samples and self.total_samples > 0:
            self.progress_percentage = min(100.0, (self.samples_processed / self.total_samples) * 100)
    
    def add_tag(self, key: str, value: str):
        """Add or update a task tag"""
        self.tags[key] = value
    
    def get_config_value(self, key: str, default: Any = None) -> Any:
        """Get configuration value with default fallback"""
        return self.config.get(key, default)

@dataclass
class EvaluationResult:
    """
    Evaluation result model
    
    Contains the results and outputs from an evaluation task.
    """
    result_id: str
    task_id: str
    metrics: Dict[str, Any]
    overall_score: Optional[float] = None
    detailed_results: Optional[Dict[str, Any]] = None
    sample_results: Optional[List[Dict[str, Any]]] = None
    failure_cases: Optional[List[Dict[str, Any]]] = None
    execution_time_ms: Optional[int] = None
    cost_usd: Optional[float] = None
    resource_consumption: Optional[Dict[str, Any]] = None
    model_outputs: Optional[List[Any]] = None
    ground_truth: Optional[List[Any]] = None
    predictions: Optional[List[Any]] = None
    confidence_scores: Optional[List[float]] = None
    error_analysis: Optional[Dict[str, Any]] = None
    statistical_significance: Optional[Dict[str, Any]] = None
    created_at: datetime = None
    metadata: Optional[Dict[str, Any]] = None
    
    def __post_init__(self):
        if self.created_at is None:
            self.created_at = datetime.now(timezone.utc)
        if self.metadata is None:
            self.metadata = {}
        if self.detailed_results is None:
            self.detailed_results = {}
        if self.resource_consumption is None:
            self.resource_consumption = {}
    
    @property
    def success_rate(self) -> Optional[float]:
        """Calculate success rate from sample results"""
        if not self.sample_results:
            return None
        
        successful = sum(1 for result in self.sample_results 
                        if result.get('success', False))
        return successful / len(self.sample_results) * 100
    
    @property
    def has_failures(self) -> bool:
        """Check if there are failure cases"""
        return bool(self.failure_cases)
    
    @property
    def performance_summary(self) -> Dict[str, Any]:
        """Get performance summary"""
        summary = {
            "overall_score": self.overall_score,
            "execution_time_ms": self.execution_time_ms,
            "cost_usd": self.cost_usd,
            "success_rate": self.success_rate
        }
        
        # Add key metrics
        if self.metrics:
            for metric_type in [MetricType.ACCURACY, MetricType.F1_SCORE, MetricType.PRECISION, MetricType.RECALL]:
                if metric_type in self.metrics:
                    summary[metric_type] = self.metrics[metric_type]
        
        return {k: v for k, v in summary.items() if v is not None}
    
    def get_metric_value(self, metric_name: str, default: Any = None) -> Any:
        """Get specific metric value"""
        return self.metrics.get(metric_name, default)
    
    def add_failure_case(self, input_data: Any, expected: Any, actual: Any, error: Optional[str] = None):
        """Add a failure case for analysis"""
        if self.failure_cases is None:
            self.failure_cases = []
        
        failure_case = {
            "input": input_data,
            "expected": expected,
            "actual": actual,
            "error": error,
            "timestamp": datetime.now(timezone.utc).isoformat()
        }
        self.failure_cases.append(failure_case)
    
    def calculate_confidence_interval(self, confidence_level: float = 0.95) -> Optional[Dict[str, float]]:
        """Calculate confidence interval for overall score"""
        if not self.confidence_scores or not self.overall_score:
            return None
        
        import statistics
        import math
        
        n = len(self.confidence_scores)
        if n < 2:
            return None
        
        mean = statistics.mean(self.confidence_scores)
        std_dev = statistics.stdev(self.confidence_scores)
        
        # Use t-distribution for small samples
        if n < 30:
            # Simplified t-value approximation
            t_value = 2.0 if confidence_level >= 0.95 else 1.64
        else:
            # Use z-distribution for large samples
            t_value = 1.96 if confidence_level >= 0.95 else 1.64
        
        margin_error = t_value * (std_dev / math.sqrt(n))
        
        return {
            "lower_bound": mean - margin_error,
            "upper_bound": mean + margin_error,
            "confidence_level": confidence_level,
            "sample_size": n
        }

@dataclass
class EvaluationMetrics:
    """
    Individual evaluation metric record
    
    Represents a single metric from an evaluation with detailed information.
    """
    metric_id: str
    task_id: str
    result_id: str
    metric_name: str
    metric_value: float
    metric_type: str
    sample_count: int
    unit: Optional[str] = None
    higher_is_better: bool = True
    confidence_interval: Optional[Dict[str, float]] = None
    baseline_value: Optional[float] = None
    improvement_percentage: Optional[float] = None
    statistical_significance: Optional[float] = None  # p-value
    created_at: datetime = None
    additional_data: Optional[Dict[str, Any]] = None
    
    def __post_init__(self):
        if self.created_at is None:
            self.created_at = datetime.now(timezone.utc)
        if self.additional_data is None:
            self.additional_data = {}
        
        # Calculate improvement if baseline is provided
        if self.baseline_value is not None and self.baseline_value != 0:
            if self.higher_is_better:
                self.improvement_percentage = ((self.metric_value - self.baseline_value) / self.baseline_value) * 100
            else:
                self.improvement_percentage = ((self.baseline_value - self.metric_value) / self.baseline_value) * 100
    
    @property
    def is_improvement(self) -> Optional[bool]:
        """Check if metric shows improvement over baseline"""
        if self.improvement_percentage is None:
            return None
        return self.improvement_percentage > 0
    
    @property
    def is_statistically_significant(self) -> Optional[bool]:
        """Check if improvement is statistically significant"""
        if self.statistical_significance is None:
            return None
        return self.statistical_significance < 0.05  # 95% confidence
    
    @property
    def performance_category(self) -> str:
        """Categorize performance level"""
        if self.baseline_value is None:
            return "unknown"
        
        if self.improvement_percentage is None:
            return "unknown"
        
        if self.improvement_percentage > 10:
            return "excellent"
        elif self.improvement_percentage > 5:
            return "good"
        elif self.improvement_percentage > 0:
            return "improved"
        elif self.improvement_percentage > -5:
            return "comparable"
        else:
            return "degraded"
    
    def format_value(self, precision: int = 3) -> str:
        """Format metric value for display"""
        if self.unit:
            return f"{self.metric_value:.{precision}f} {self.unit}"
        else:
            return f"{self.metric_value:.{precision}f}"
    
    def compare_to_baseline(self) -> Optional[str]:
        """Generate comparison string to baseline"""
        if self.baseline_value is None or self.improvement_percentage is None:
            return None
        
        direction = "↑" if self.is_improvement else "↓"
        abs_improvement = abs(self.improvement_percentage)
        
        significance = ""
        if self.is_statistically_significant:
            significance = " (significant)"
        
        return f"{direction} {abs_improvement:.1f}%{significance}"

# Utility functions for working with evaluation models

def create_evaluation_task(
    model_id: str,
    task_name: str,
    evaluator_type: str,
    dataset_name: str,
    config: Dict[str, Any],
    user_id: Optional[str] = None,
    project_name: Optional[str] = None,
    evaluation_type: str = EvaluationType.BENCHMARK,
    priority: int = 5
) -> EvaluationTask:
    """Factory function to create a new evaluation task"""
    import uuid
    
    task_id = f"eval_{datetime.now().strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:8]}"
    
    return EvaluationTask(
        task_id=task_id,
        task_name=task_name,
        model_id=model_id,
        evaluator_type=evaluator_type,
        dataset_name=dataset_name,
        config=config,
        evaluation_type=evaluation_type,
        priority=priority,
        user_id=user_id,
        project_name=project_name
    )

def create_evaluation_result(
    task_id: str,
    metrics: Dict[str, Any],
    execution_time_ms: Optional[int] = None,
    cost_usd: Optional[float] = None
) -> EvaluationResult:
    """Factory function to create a new evaluation result"""
    import uuid
    
    result_id = f"result_{task_id}_{uuid.uuid4().hex[:8]}"
    
    # Calculate overall score if not provided
    overall_score = None
    if metrics:
        # Simple scoring based on common metrics
        score_metrics = []
        for key, value in metrics.items():
            if isinstance(value, (int, float)) and key.lower() in ['accuracy', 'f1_score', 'precision', 'recall']:
                score_metrics.append(value)
        
        if score_metrics:
            overall_score = sum(score_metrics) / len(score_metrics)
    
    return EvaluationResult(
        result_id=result_id,
        task_id=task_id,
        metrics=metrics,
        overall_score=overall_score,
        execution_time_ms=execution_time_ms,
        cost_usd=cost_usd
    )

def create_evaluation_metric(
    task_id: str,
    result_id: str,
    metric_name: str,
    metric_value: float,
    metric_type: str,
    sample_count: int,
    baseline_value: Optional[float] = None
) -> EvaluationMetrics:
    """Factory function to create a new evaluation metric"""
    import uuid
    
    metric_id = f"metric_{task_id}_{uuid.uuid4().hex[:6]}"
    
    return EvaluationMetrics(
        metric_id=metric_id,
        task_id=task_id,
        result_id=result_id,
        metric_name=metric_name,
        metric_value=metric_value,
        metric_type=metric_type,
        sample_count=sample_count,
        baseline_value=baseline_value
    )

def calculate_evaluation_summary(results: List[EvaluationResult]) -> Dict[str, Any]:
    """Calculate summary statistics from multiple evaluation results"""
    if not results:
        return {"total_evaluations": 0}
    
    total_cost = sum(r.cost_usd or 0 for r in results)
    avg_execution_time = sum(r.execution_time_ms or 0 for r in results) / len(results)
    
    # Overall scores
    scores = [r.overall_score for r in results if r.overall_score is not None]
    avg_score = sum(scores) / len(scores) if scores else None
    
    # Success rates
    success_rates = [r.success_rate for r in results if r.success_rate is not None]
    avg_success_rate = sum(success_rates) / len(success_rates) if success_rates else None
    
    return {
        "total_evaluations": len(results),
        "total_cost_usd": round(total_cost, 4),
        "avg_execution_time_ms": round(avg_execution_time, 2),
        "avg_overall_score": round(avg_score, 3) if avg_score else None,
        "avg_success_rate": round(avg_success_rate, 2) if avg_success_rate else None,
        "evaluations_with_failures": sum(1 for r in results if r.has_failures),
        "evaluation_types": list(set(r.metadata.get('evaluation_type', 'unknown') for r in results))
    }