"""
Evaluation Models

Data models for evaluation operations following the ISA Model architecture pattern.
"""

from .evaluation_task import EvaluationTask, EvaluationResult, EvaluationMetrics
from .evaluation_config import EvaluationConfig, BenchmarkConfig, DatasetConfig
from .benchmark_models import BenchmarkResult, MetricResult, ComparisonResult

__all__ = [
    "EvaluationTask",
    "EvaluationResult", 
    "EvaluationMetrics",
    "EvaluationConfig",
    "BenchmarkConfig",
    "DatasetConfig",
    "BenchmarkResult",
    "MetricResult",
    "ComparisonResult"
]