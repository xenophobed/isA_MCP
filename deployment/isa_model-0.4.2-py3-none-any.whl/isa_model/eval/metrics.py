"""
Evaluation Metrics for ISA Model Framework

This module provides various metrics for evaluating AI models:
- LLM metrics: perplexity, BLEU, ROUGE, accuracy, etc.
- Image metrics: FID, IS, LPIPS, etc.
- Custom metrics and benchmark runners
"""

import os
import json
import logging
import numpy as np
from typing import Dict, List, Any, Optional, Union
from enum import Enum
from abc import ABC, abstractmethod
from datetime import datetime

try:
    from ..inference.ai_factory import AIFactory
    AI_FACTORY_AVAILABLE = True
except ImportError:
    AI_FACTORY_AVAILABLE = False

logger = logging.getLogger(__name__)


class MetricType(str, Enum):
    """Types of evaluation metrics."""
    PERPLEXITY = "perplexity"
    BLEU = "bleu"
    ROUGE = "rouge"
    ACCURACY = "accuracy"
    F1_SCORE = "f1"
    DIVERSITY = "diversity"
    COHERENCE = "coherence"
    FLUENCY = "fluency"
    FID = "fid"
    IS = "is"
    LPIPS = "lpips"
    # 医疗评估指标
    STEM_CELL_ACCURACY = "stem_cell_accuracy"
    MEDICAL_SAFETY = "medical_safety"
    TREATMENT_COMPLETENESS = "treatment_completeness"


class BaseMetric(ABC):
    """Base class for all metrics."""
    
    @abstractmethod
    def compute(self, predictions: List[str], references: List[str] = None, **kwargs) -> Dict[str, float]:
        """Compute the metric."""
        pass


class LLMMetrics:
    """
    Metrics calculator for Language Models.
    
    Supports various metrics including:
    - Perplexity
    - BLEU score
    - ROUGE score
    - Accuracy
    - F1 score
    - Generation quality metrics
    """
    
    def __init__(self):
        self.available_metrics = [
            MetricType.PERPLEXITY,
            MetricType.BLEU,
            MetricType.ROUGE,
            MetricType.ACCURACY,
            MetricType.F1_SCORE,
            MetricType.DIVERSITY,
            MetricType.COHERENCE,
            MetricType.FLUENCY
        ]
        
        # Initialize AI factory if available
        if AI_FACTORY_AVAILABLE:
            try:
                self.ai_factory = AIFactory()
            except Exception as e:
                logger.warning(f"Failed to initialize AIFactory: {e}")
                self.ai_factory = None
        else:
            self.ai_factory = None
    
    async def evaluate(
        self,
        model_path: str,
        dataset: List[Dict[str, Any]],
        metrics: List[str],
        batch_size: int = 8,
        provider: str = "ollama",
        **kwargs
    ) -> Dict[str, Any]:
        """
        Evaluate LLM on dataset with specified metrics.
        
        Args:
            model_path: Path to the model
            dataset: Evaluation dataset
            metrics: List of metrics to compute
            batch_size: Batch size for evaluation
            provider: Model provider
            **kwargs: Additional parameters
            
        Returns:
            Dictionary with metric results
        """
        results = {
            "model_path": model_path,
            "num_samples": len(dataset),
            "metrics": {}
        }
        
        # Generate predictions
        predictions, references = await self._generate_predictions(
            model_path, dataset, batch_size, provider, **kwargs
        )
        
        # Compute each metric
        for metric in metrics:
            try:
                if metric == MetricType.PERPLEXITY:
                    score = self._compute_perplexity(predictions, references)
                elif metric == MetricType.BLEU:
                    score = self._compute_bleu(predictions, references)
                elif metric == MetricType.ROUGE:
                    score = self._compute_rouge(predictions, references)
                elif metric == MetricType.ACCURACY:
                    score = self._compute_accuracy(predictions, references)
                elif metric == MetricType.F1_SCORE:
                    score = self._compute_f1(predictions, references)
                elif metric == MetricType.DIVERSITY:
                    score = self._compute_diversity(predictions)
                elif metric == MetricType.COHERENCE:
                    score = self._compute_coherence(predictions)
                elif metric == MetricType.FLUENCY:
                    score = self._compute_fluency(predictions)
                else:
                    logger.warning(f"Unknown metric: {metric}")
                    continue
                
                results["metrics"][metric] = score
                logger.info(f"Computed {metric}: {score}")
                
            except Exception as e:
                logger.error(f"Failed to compute {metric}: {e}")
                results["metrics"][metric] = {"error": str(e)}
        
        return results
    
    async def evaluate_generation(
        self,
        model_path: str,
        prompts: List[str],
        reference_texts: List[str] = None,
        metrics: List[str] = None,
        provider: str = "ollama",
        **kwargs
    ) -> Dict[str, Any]:
        """
        Evaluate text generation quality.
        
        Args:
            model_path: Path to the model
            prompts: Input prompts
            reference_texts: Reference texts (optional)
            metrics: Metrics to compute
            provider: Model provider
            **kwargs: Additional parameters
            
        Returns:
            Generation evaluation results
        """
        if metrics is None:
            metrics = [MetricType.DIVERSITY, MetricType.COHERENCE, MetricType.FLUENCY]
        
        # Generate texts
        generated_texts = self._generate_texts(model_path, prompts, provider, **kwargs)
        
        results = {
            "model_path": model_path,
            "num_prompts": len(prompts),
            "metrics": {}
        }
        
        # Compute metrics
        for metric in metrics:
            try:
                if metric == MetricType.DIVERSITY:
                    score = self._compute_diversity(generated_texts)
                elif metric == MetricType.COHERENCE:
                    score = self._compute_coherence(generated_texts)
                elif metric == MetricType.FLUENCY:
                    score = self._compute_fluency(generated_texts)
                elif metric == MetricType.BLEU and reference_texts:
                    score = self._compute_bleu(generated_texts, reference_texts)
                elif metric == MetricType.ROUGE and reference_texts:
                    score = self._compute_rouge(generated_texts, reference_texts)
                else:
                    continue
                
                results["metrics"][metric] = score
                
            except Exception as e:
                logger.error(f"Failed to compute {metric}: {e}")
                results["metrics"][metric] = {"error": str(e)}
        
        return results
    
    async def _generate_predictions(
        self,
        model_path: str,
        dataset: List[Dict[str, Any]],
        batch_size: int,
        provider: str,
        **kwargs
    ) -> tuple:
        """Generate predictions from model using actual inference."""
        predictions = []
        references = []
        
        if not self.ai_factory:
            logger.warning("AIFactory not available, using placeholder predictions")
            # Fallback to placeholder predictions
            for item in dataset:
                if isinstance(item, dict):
                    if "input" in item and "output" in item:
                        predictions.append(f"Generated response for: {item['input']}")
                        references.append(item["output"])
                    elif "prompt" in item and "response" in item:
                        predictions.append(f"Generated response for: {item['prompt']}")
                        references.append(item["response"])
            return predictions, references
        
        try:
            # Get LLM service
            llm_service = self.ai_factory.get_llm(model_name=model_path, provider=provider)
            
            # Process dataset in batches
            for i in range(0, len(dataset), batch_size):
                batch = dataset[i:i + batch_size]
                batch_predictions = []
                batch_references = []
                
                for item in batch:
                    if isinstance(item, dict):
                        prompt = None
                        reference = None
                        
                        # Extract prompt and reference based on data format
                        if "input" in item and "output" in item:
                            prompt = item["input"]
                            reference = item["output"]
                        elif "prompt" in item and "response" in item:
                            prompt = item["prompt"]
                            reference = item["response"]
                        elif "question" in item and "answer" in item:
                            prompt = item["question"]
                            reference = item["answer"]
                        elif "text" in item and "label" in item:
                            prompt = item["text"]
                            reference = str(item["label"])
                        
                        if prompt and reference:
                            try:
                                # Generate prediction using actual model
                                response = await llm_service.ainvoke(prompt)
                                
                                # Extract text from response
                                if hasattr(response, 'text'):
                                    prediction = response.text
                                elif isinstance(response, dict) and 'text' in response:
                                    prediction = response['text']
                                elif isinstance(response, str):
                                    prediction = response
                                else:
                                    prediction = str(response)
                                
                                batch_predictions.append(prediction.strip())
                                batch_references.append(reference)
                                
                            except Exception as e:
                                logger.error(f"Failed to generate prediction for item: {e}")
                                # Use fallback prediction
                                batch_predictions.append(f"Error generating prediction: {str(e)}")
                                batch_references.append(reference)
                
                predictions.extend(batch_predictions)
                references.extend(batch_references)
                
                logger.info(f"Processed batch {i//batch_size + 1}/{(len(dataset) + batch_size - 1)//batch_size}")
        
        except Exception as e:
            logger.error(f"Failed to use AIFactory for predictions: {e}")
            # Fallback to placeholder predictions
            for item in dataset:
                if isinstance(item, dict):
                    if "input" in item and "output" in item:
                        predictions.append(f"Generated response for: {item['input']}")
                        references.append(item["output"])
                    elif "prompt" in item and "response" in item:
                        predictions.append(f"Generated response for: {item['prompt']}")
                        references.append(item["response"])
        
        logger.info(f"Generated {len(predictions)} predictions")
        return predictions, references
    
    async def _generate_texts(
        self,
        model_path: str,
        prompts: List[str],
        provider: str,
        **kwargs
    ) -> List[str]:
        """Generate texts from prompts using actual model inference."""
        generated_texts = []
        
        if not self.ai_factory:
            logger.warning("AIFactory not available, using placeholder text generation")
            # Fallback to placeholder generation
            for prompt in prompts:
                generated_texts.append(f"Generated response for: {prompt}")
            return generated_texts
        
        try:
            # Get LLM service
            llm_service = self.ai_factory.get_llm(model_name=model_path, provider=provider)
            
            for prompt in prompts:
                try:
                    # Generate text using actual model
                    response = await llm_service.ainvoke(prompt)
                    
                    # Extract text from response
                    if hasattr(response, 'text'):
                        generated_text = response.text
                    elif isinstance(response, dict) and 'text' in response:
                        generated_text = response['text']
                    elif isinstance(response, str):
                        generated_text = response
                    else:
                        generated_text = str(response)
                    
                    generated_texts.append(generated_text.strip())
                    
                except Exception as e:
                    logger.error(f"Failed to generate text for prompt: {e}")
                    # Use fallback generation
                    generated_texts.append(f"Error generating text: {str(e)}")
        
        except Exception as e:
            logger.error(f"Failed to use AIFactory for text generation: {e}")
            # Fallback to placeholder generation
            for prompt in prompts:
                generated_texts.append(f"Generated response for: {prompt}")
        
        return generated_texts
    
    def _compute_perplexity(self, predictions: List[str], references: List[str]) -> Dict[str, float]:
        """Compute perplexity score (simplified implementation)."""
        # This is a placeholder - actual perplexity requires model probabilities
        return {
            "perplexity": np.random.uniform(10, 100),  # Placeholder
            "log_perplexity": np.random.uniform(2, 5)
        }
    
    def _compute_bleu(self, predictions: List[str], references: List[str]) -> Dict[str, float]:
        """Compute professional BLEU score using multiple implementations."""
        try:
            # Try to use NLTK BLEU first (most accurate)
            result = self._compute_nltk_bleu(predictions, references)
            if result and "error" not in result:
                return result
                
            logger.warning("NLTK BLEU failed, trying sacrebleu...")
            
            # Try sacrebleu as fallback
            result = self._compute_sacrebleu(predictions, references)
            if result and "error" not in result:
                return result
                
            logger.warning("Both NLTK and sacrebleu failed, using custom implementation...")
            
            # Custom implementation as final fallback
            return self._compute_custom_bleu(predictions, references)
            
        except Exception as e:
            logger.error(f"BLEU computation failed: {e}")
            return {"bleu": 0.0, "error": str(e)}
    
    def _compute_nltk_bleu(self, predictions: List[str], references: List[str]) -> Dict[str, float]:
        """Compute BLEU using NLTK implementation."""
        try:
            from nltk.translate.bleu_score import sentence_bleu, corpus_bleu, SmoothingFunction
            import nltk
            
            # Download necessary NLTK data
            try:
                nltk.data.find('tokenizers/punkt')
            except LookupError:
                nltk.download('punkt', quiet=True)
            
            smoothing = SmoothingFunction()
            
            # Tokenize all texts
            pred_tokens = [pred.lower().split() for pred in predictions]
            ref_tokens = [[ref.lower().split()] for ref in references]  # BLEU expects list of reference lists
            
            # Compute individual BLEU scores
            individual_scores = []
            for pred_tok, ref_tok in zip(pred_tokens, ref_tokens):
                try:
                    score = sentence_bleu(
                        ref_tok, 
                        pred_tok,
                        smoothing_function=smoothing.method1
                    )
                    individual_scores.append(score)
                except:
                    individual_scores.append(0.0)
            
            # Compute corpus-level BLEU
            try:
                corpus_score = corpus_bleu(
                    ref_tokens, 
                    pred_tokens,
                    smoothing_function=smoothing.method1
                )
            except:
                corpus_score = np.mean(individual_scores) if individual_scores else 0.0
            
            # Compute BLEU-1, BLEU-2, BLEU-3, BLEU-4 separately
            bleu_scores = {}
            for n in range(1, 5):
                weights = [1.0/n] * n + [0.0] * (4-n)  # Equal weights up to n-gram
                try:
                    bleu_n = corpus_bleu(
                        ref_tokens,
                        pred_tokens, 
                        weights=weights,
                        smoothing_function=smoothing.method1
                    )
                    bleu_scores[f"bleu_{n}"] = bleu_n
                except:
                    bleu_scores[f"bleu_{n}"] = 0.0
            
            return {
                "bleu": corpus_score,
                "bleu_std": np.std(individual_scores),
                **bleu_scores,
                "individual_scores": individual_scores,
                "method": "nltk"
            }
            
        except ImportError:
            logger.warning("NLTK not available. Install with: pip install nltk")
            return {"error": "nltk_not_available"}
        except Exception as e:
            logger.error(f"NLTK BLEU computation failed: {e}")
            return {"error": str(e)}
    
    def _compute_sacrebleu(self, predictions: List[str], references: List[str]) -> Dict[str, float]:
        """Compute BLEU using sacrebleu implementation."""
        try:
            import sacrebleu
            
            # sacrebleu expects list of references for each prediction
            refs_formatted = [[ref] for ref in references]
            
            # Compute BLEU score
            bleu = sacrebleu.corpus_bleu(predictions, list(zip(*refs_formatted)))
            
            return {
                "bleu": bleu.score / 100.0,  # sacrebleu returns percentage
                "bleu_1": bleu.precisions[0] / 100.0,
                "bleu_2": bleu.precisions[1] / 100.0,
                "bleu_3": bleu.precisions[2] / 100.0,
                "bleu_4": bleu.precisions[3] / 100.0,
                "brevity_penalty": bleu.bp,
                "length_ratio": bleu.ratio,
                "method": "sacrebleu"
            }
            
        except ImportError:
            logger.warning("sacrebleu not available. Install with: pip install sacrebleu")
            return {"error": "sacrebleu_not_available"}
        except Exception as e:
            logger.error(f"sacrebleu computation failed: {e}")
            return {"error": str(e)}
    
    def _compute_custom_bleu(self, predictions: List[str], references: List[str]) -> Dict[str, float]:
        """Custom BLEU implementation as final fallback."""
        try:
            from collections import defaultdict, Counter
            import math
            
            def get_ngrams(tokens, n):
                """Extract n-grams from tokens."""
                return [tuple(tokens[i:i+n]) for i in range(len(tokens) - n + 1)]
            
            def compute_bleu_n(pred_tokens, ref_tokens, n):
                """Compute BLEU score for specific n-gram order."""
                pred_ngrams = Counter(get_ngrams(pred_tokens, n))
                ref_ngrams = Counter(get_ngrams(ref_tokens, n))
                
                if not pred_ngrams:
                    return 0.0
                
                matches = sum(min(pred_ngrams[ng], ref_ngrams[ng]) for ng in pred_ngrams)
                total = sum(pred_ngrams.values())
                
                return matches / total if total > 0 else 0.0
            
            individual_scores = []
            bleu_n_scores = {f"bleu_{n}": [] for n in range(1, 5)}
            
            for pred, ref in zip(predictions, references):
                pred_tokens = pred.lower().split()
                ref_tokens = ref.lower().split()
                
                if not pred_tokens:
                    individual_scores.append(0.0)
                    for n in range(1, 5):
                        bleu_n_scores[f"bleu_{n}"].append(0.0)
                    continue
                
                # Compute n-gram precisions
                precisions = []
                for n in range(1, 5):
                    precision = compute_bleu_n(pred_tokens, ref_tokens, n)
                    precisions.append(precision)
                    bleu_n_scores[f"bleu_{n}"].append(precision)
                
                # Compute geometric mean of precisions
                if all(p > 0 for p in precisions):
                    geometric_mean = math.exp(sum(math.log(p) for p in precisions) / len(precisions))
                else:
                    geometric_mean = 0.0
                
                # Apply brevity penalty
                bp = min(1.0, math.exp(1 - len(ref_tokens) / len(pred_tokens))) if pred_tokens else 0.0
                
                score = geometric_mean * bp
                individual_scores.append(score)
            
            return {
                "bleu": np.mean(individual_scores),
                "bleu_std": np.std(individual_scores),
                "bleu_1": np.mean(bleu_n_scores["bleu_1"]),
                "bleu_2": np.mean(bleu_n_scores["bleu_2"]),
                "bleu_3": np.mean(bleu_n_scores["bleu_3"]),
                "bleu_4": np.mean(bleu_n_scores["bleu_4"]),
                "individual_scores": individual_scores,
                "method": "custom"
            }
            
        except Exception as e:
            logger.error(f"Custom BLEU computation failed: {e}")
            return {"bleu": 0.0, "error": str(e)}
    
    def _compute_rouge(self, predictions: List[str], references: List[str]) -> Dict[str, float]:
        """Compute professional ROUGE scores using multiple implementations."""
        try:
            # Try rouge-score library first (most accurate)
            result = self._compute_rouge_score(predictions, references)
            if result and "error" not in result:
                return result
                
            logger.warning("rouge-score failed, trying custom implementation...")
            
            # Custom implementation as fallback
            return self._compute_custom_rouge(predictions, references)
            
        except Exception as e:
            logger.error(f"ROUGE computation failed: {e}")
            return {"rouge_1": 0.0, "rouge_l": 0.0, "error": str(e)}
    
    def _compute_rouge_score(self, predictions: List[str], references: List[str]) -> Dict[str, float]:
        """Compute ROUGE using rouge-score library."""
        try:
            from rouge_score import rouge_scorer
            
            scorer = rouge_scorer.RougeScorer(
                ['rouge1', 'rouge2', 'rougeL', 'rougeLsum'], 
                use_stemmer=True
            )
            
            rouge_1_scores = []
            rouge_2_scores = []
            rouge_l_scores = []
            rouge_lsum_scores = []
            
            for pred, ref in zip(predictions, references):
                scores = scorer.score(ref, pred)
                
                rouge_1_scores.append(scores['rouge1'].fmeasure)
                rouge_2_scores.append(scores['rouge2'].fmeasure)
                rouge_l_scores.append(scores['rougeL'].fmeasure)
                rouge_lsum_scores.append(scores['rougeLsum'].fmeasure)
            
            return {
                "rouge_1": np.mean(rouge_1_scores),
                "rouge_2": np.mean(rouge_2_scores),
                "rouge_l": np.mean(rouge_l_scores),
                "rouge_lsum": np.mean(rouge_lsum_scores),
                "rouge_1_std": np.std(rouge_1_scores),
                "rouge_2_std": np.std(rouge_2_scores),
                "rouge_l_std": np.std(rouge_l_scores),
                "rouge_lsum_std": np.std(rouge_lsum_scores),
                "individual_scores": {
                    "rouge_1": rouge_1_scores,
                    "rouge_2": rouge_2_scores,
                    "rouge_l": rouge_l_scores,
                    "rouge_lsum": rouge_lsum_scores
                },
                "method": "rouge_score"
            }
            
        except ImportError:
            logger.warning("rouge-score not available. Install with: pip install rouge-score")
            return {"error": "rouge_score_not_available"}
        except Exception as e:
            logger.error(f"rouge-score computation failed: {e}")
            return {"error": str(e)}
    
    def _compute_custom_rouge(self, predictions: List[str], references: List[str]) -> Dict[str, float]:
        """Custom ROUGE implementation with proper LCS calculation."""
        try:
            from collections import Counter
            
            def get_ngrams(tokens, n):
                """Extract n-grams from tokens."""
                return [tuple(tokens[i:i+n]) for i in range(len(tokens) - n + 1)]
            
            def lcs_length(seq1, seq2):
                """Compute longest common subsequence length."""
                m, n = len(seq1), len(seq2)
                dp = [[0] * (n + 1) for _ in range(m + 1)]
                
                for i in range(1, m + 1):
                    for j in range(1, n + 1):
                        if seq1[i-1] == seq2[j-1]:
                            dp[i][j] = dp[i-1][j-1] + 1
                        else:
                            dp[i][j] = max(dp[i-1][j], dp[i][j-1])
                
                return dp[m][n]
            
            def compute_rouge_n(pred_tokens, ref_tokens, n):
                """Compute ROUGE-N score."""
                if not pred_tokens or not ref_tokens:
                    return {"precision": 0.0, "recall": 0.0, "fmeasure": 0.0}
                
                pred_ngrams = Counter(get_ngrams(pred_tokens, n))
                ref_ngrams = Counter(get_ngrams(ref_tokens, n))
                
                overlap = sum(min(pred_ngrams[ng], ref_ngrams[ng]) for ng in pred_ngrams)
                
                precision = overlap / sum(pred_ngrams.values()) if pred_ngrams else 0.0
                recall = overlap / sum(ref_ngrams.values()) if ref_ngrams else 0.0
                
                if precision + recall > 0:
                    fmeasure = 2 * precision * recall / (precision + recall)
                else:
                    fmeasure = 0.0
                
                return {"precision": precision, "recall": recall, "fmeasure": fmeasure}
            
            def compute_rouge_l(pred_tokens, ref_tokens):
                """Compute ROUGE-L score based on LCS."""
                if not pred_tokens or not ref_tokens:
                    return {"precision": 0.0, "recall": 0.0, "fmeasure": 0.0}
                
                lcs_len = lcs_length(pred_tokens, ref_tokens)
                
                precision = lcs_len / len(pred_tokens)
                recall = lcs_len / len(ref_tokens)
                
                if precision + recall > 0:
                    fmeasure = 2 * precision * recall / (precision + recall)
                else:
                    fmeasure = 0.0
                
                return {"precision": precision, "recall": recall, "fmeasure": fmeasure}
            
            # Compute scores for all pairs
            rouge_1_scores = []
            rouge_2_scores = []
            rouge_l_scores = []
            
            for pred, ref in zip(predictions, references):
                pred_tokens = pred.lower().split()
                ref_tokens = ref.lower().split()
                
                # ROUGE-1
                rouge_1 = compute_rouge_n(pred_tokens, ref_tokens, 1)
                rouge_1_scores.append(rouge_1["fmeasure"])
                
                # ROUGE-2
                rouge_2 = compute_rouge_n(pred_tokens, ref_tokens, 2)
                rouge_2_scores.append(rouge_2["fmeasure"])
                
                # ROUGE-L
                rouge_l = compute_rouge_l(pred_tokens, ref_tokens)
                rouge_l_scores.append(rouge_l["fmeasure"])
            
            return {
                "rouge_1": np.mean(rouge_1_scores),
                "rouge_2": np.mean(rouge_2_scores),
                "rouge_l": np.mean(rouge_l_scores),
                "rouge_1_std": np.std(rouge_1_scores),
                "rouge_2_std": np.std(rouge_2_scores),
                "rouge_l_std": np.std(rouge_l_scores),
                "individual_scores": {
                    "rouge_1": rouge_1_scores,
                    "rouge_2": rouge_2_scores,
                    "rouge_l": rouge_l_scores
                },
                "method": "custom"
            }
            
        except Exception as e:
            logger.error(f"Custom ROUGE computation failed: {e}")
            return {"rouge_1": 0.0, "rouge_l": 0.0, "error": str(e)}
    
    def _compute_accuracy(self, predictions: List[str], references: List[str]) -> Dict[str, float]:
        """Compute accuracy score."""
        try:
            correct = 0
            total = len(predictions)
            
            for pred, ref in zip(predictions, references):
                if pred.strip().lower() == ref.strip().lower():
                    correct += 1
            
            accuracy = correct / total if total > 0 else 0.0
            
            return {
                "accuracy": accuracy,
                "correct": correct,
                "total": total
            }
        except Exception as e:
            logger.error(f"Accuracy computation failed: {e}")
            return {"accuracy": 0.0, "error": str(e)}
    
    def _compute_f1(self, predictions: List[str], references: List[str]) -> Dict[str, float]:
        """Compute F1 score (simplified implementation)."""
        try:
            f1_scores = []
            
            for pred, ref in zip(predictions, references):
                pred_words = set(pred.lower().split())
                ref_words = set(ref.lower().split())
                
                if len(pred_words) == 0 and len(ref_words) == 0:
                    f1_scores.append(1.0)
                elif len(pred_words) == 0 or len(ref_words) == 0:
                    f1_scores.append(0.0)
                else:
                    intersection = len(pred_words & ref_words)
                    precision = intersection / len(pred_words)
                    recall = intersection / len(ref_words)
                    
                    if precision + recall > 0:
                        f1 = 2 * (precision * recall) / (precision + recall)
                        f1_scores.append(f1)
                    else:
                        f1_scores.append(0.0)
            
            return {
                "f1": np.mean(f1_scores),
                "f1_std": np.std(f1_scores)
            }
        except Exception as e:
            logger.error(f"F1 computation failed: {e}")
            return {"f1": 0.0, "error": str(e)}
    
    def compute_fid_score(self, real_images: List[Any], generated_images: List[Any]) -> Dict[str, float]:
        """
        Compute Fréchet Inception Distance (FID) for image quality evaluation.
        
        Args:
            real_images: List of real images (can be file paths, PIL Images, or tensors)
            generated_images: List of generated images
            
        Returns:
            FID score and related metrics
        """
        try:
            # Try pytorch-fid library first
            result = self._compute_pytorch_fid(real_images, generated_images)
            if result and "error" not in result:
                return result
                
            logger.warning("pytorch-fid failed, trying custom implementation...")
            
            # Custom implementation as fallback
            return self._compute_custom_fid(real_images, generated_images)
            
        except Exception as e:
            logger.error(f"FID computation failed: {e}")
            return {"fid": float('inf'), "error": str(e)}
    
    def _compute_pytorch_fid(self, real_images: List[Any], generated_images: List[Any]) -> Dict[str, float]:
        """Compute FID using pytorch-fid library."""
        try:
            import torch
            import torchvision.transforms as transforms
            from torchvision.models import inception_v3
            import numpy as np
            from scipy import linalg
            from PIL import Image
            import io
            
            # Load pre-trained Inception v3
            device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
            model = inception_v3(pretrained=True, transform_input=False).to(device)
            model.eval()
            
            # Remove final classification layer
            model.fc = torch.nn.Identity()
            
            # Image preprocessing
            preprocess = transforms.Compose([
                transforms.Resize(299),
                transforms.CenterCrop(299),
                transforms.ToTensor(),
                transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
            ])
            
            def extract_features(images):
                """Extract Inception features from images."""
                features = []
                
                with torch.no_grad():
                    for img in images:
                        # Convert to PIL if necessary
                        if isinstance(img, str):  # File path
                            pil_img = Image.open(img).convert('RGB')
                        elif isinstance(img, bytes):  # Raw bytes
                            pil_img = Image.open(io.BytesIO(img)).convert('RGB')
                        elif hasattr(img, 'convert'):  # PIL Image
                            pil_img = img.convert('RGB')
                        else:
                            # Assume it's already a tensor or numpy array
                            if isinstance(img, np.ndarray):
                                pil_img = Image.fromarray(img).convert('RGB')
                            else:
                                pil_img = transforms.ToPILImage()(img).convert('RGB')
                        
                        # Preprocess and get features
                        tensor = preprocess(pil_img).unsqueeze(0).to(device)
                        feature = model(tensor).cpu().numpy().flatten()
                        features.append(feature)
                
                return np.array(features)
            
            def calculate_frechet_distance(mu1, sigma1, mu2, sigma2, eps=1e-6):
                """Calculate Fréchet distance between two multivariate Gaussians."""
                mu1, mu2 = np.atleast_1d(mu1), np.atleast_1d(mu2)
                sigma1, sigma2 = np.atleast_2d(sigma1), np.atleast_2d(sigma2)
                
                diff = mu1 - mu2
                
                # Product might be almost singular
                covmean, _ = linalg.sqrtm(sigma1.dot(sigma2), disp=False)
                if not np.isfinite(covmean).all():
                    offset = np.eye(sigma1.shape[0]) * eps
                    covmean = linalg.sqrtm((sigma1 + offset).dot(sigma2 + offset))
                
                # Numerical error might give slight imaginary component
                if np.iscomplexobj(covmean):
                    if not np.allclose(np.diagonal(covmean).imag, 0, atol=1e-3):
                        m = np.max(np.abs(covmean.imag))
                        logger.warning(f"Imaginary component in FID calculation: {m}")
                    covmean = covmean.real
                
                tr_covmean = np.trace(covmean)
                fid = diff.dot(diff) + np.trace(sigma1) + np.trace(sigma2) - 2 * tr_covmean
                
                return fid
            
            # Extract features
            logger.info("Extracting features from real images...")
            real_features = extract_features(real_images)
            
            logger.info("Extracting features from generated images...")
            gen_features = extract_features(generated_images)
            
            # Calculate statistics
            mu_real, sigma_real = np.mean(real_features, axis=0), np.cov(real_features, rowvar=False)
            mu_gen, sigma_gen = np.mean(gen_features, axis=0), np.cov(gen_features, rowvar=False)
            
            # Calculate FID
            fid_score = calculate_frechet_distance(mu_real, sigma_real, mu_gen, sigma_gen)
            
            return {
                "fid": float(fid_score),
                "mu_real_norm": float(np.linalg.norm(mu_real)),
                "mu_gen_norm": float(np.linalg.norm(mu_gen)),
                "sigma_real_trace": float(np.trace(sigma_real)),
                "sigma_gen_trace": float(np.trace(sigma_gen)),
                "num_real_images": len(real_images),
                "num_gen_images": len(generated_images),
                "method": "pytorch_fid"
            }
            
        except ImportError as e:
            logger.warning(f"Required packages not available for FID: {e}")
            return {"error": "pytorch_fid_dependencies_missing"}
        except Exception as e:
            logger.error(f"PyTorch FID computation failed: {e}")
            return {"error": str(e)}
    
    def _compute_custom_fid(self, real_images: List[Any], generated_images: List[Any]) -> Dict[str, float]:
        """Custom FID implementation with basic feature extraction."""
        try:
            import numpy as np
            from PIL import Image
            import io
            
            def extract_simple_features(images):
                """Extract simple statistical features from images."""
                features = []
                
                for img in images:
                    # Convert to PIL if necessary
                    if isinstance(img, str):  # File path
                        pil_img = Image.open(img).convert('RGB')
                    elif isinstance(img, bytes):  # Raw bytes
                        pil_img = Image.open(io.BytesIO(img)).convert('RGB')
                    elif hasattr(img, 'convert'):  # PIL Image
                        pil_img = img.convert('RGB')
                    else:
                        # Assume it's already a PIL image or can be converted
                        continue
                    
                    # Resize to standard size
                    pil_img = pil_img.resize((256, 256))
                    img_array = np.array(pil_img)
                    
                    # Extract basic statistics as features
                    feature_vector = []
                    
                    for channel in range(3):  # RGB channels
                        channel_data = img_array[:, :, channel].flatten()
                        feature_vector.extend([
                            np.mean(channel_data),
                            np.std(channel_data),
                            np.median(channel_data),
                            np.percentile(channel_data, 25),
                            np.percentile(channel_data, 75),
                            np.min(channel_data),
                            np.max(channel_data)
                        ])
                    
                    # Add texture features
                    gray = np.array(pil_img.convert('L'))
                    feature_vector.extend([
                        np.std(np.gradient(gray)),  # Edge strength
                        np.mean(np.abs(np.gradient(gray))),  # Average gradient
                    ])
                    
                    features.append(feature_vector)
                
                return np.array(features)
            
            def simple_frechet_distance(mu1, sigma1, mu2, sigma2):
                """Simplified Fréchet distance calculation."""
                diff = mu1 - mu2
                
                # Use Frobenius norm for covariance difference (approximation)
                cov_diff = sigma1 + sigma2 - 2 * np.sqrt(np.diag(sigma1) * np.diag(sigma2))
                
                return np.dot(diff, diff) + np.sum(cov_diff)
            
            # Extract features
            real_features = extract_simple_features(real_images)
            gen_features = extract_simple_features(generated_images)
            
            if real_features.size == 0 or gen_features.size == 0:
                return {"fid": float('inf'), "error": "No valid features extracted"}
            
            # Calculate statistics
            mu_real, sigma_real = np.mean(real_features, axis=0), np.cov(real_features, rowvar=False)
            mu_gen, sigma_gen = np.mean(gen_features, axis=0), np.cov(gen_features, rowvar=False)
            
            # Handle single sample case
            if sigma_real.ndim == 0:
                sigma_real = np.array([[sigma_real]])
            if sigma_gen.ndim == 0:
                sigma_gen = np.array([[sigma_gen]])
            
            # Calculate simplified FID
            fid_score = simple_frechet_distance(mu_real, sigma_real, mu_gen, sigma_gen)
            
            return {
                "fid": float(fid_score),
                "num_real_images": len(real_images),
                "num_gen_images": len(generated_images),
                "method": "custom_simple",
                "note": "Simplified FID using basic image statistics"
            }
            
        except Exception as e:
            logger.error(f"Custom FID computation failed: {e}")
            return {"fid": float('inf'), "error": str(e)}
    
    def _compute_diversity(self, texts: List[str]) -> Dict[str, float]:
        """Compute diversity metrics."""
        try:
            # Distinct-1 and Distinct-2
            all_unigrams = []
            all_bigrams = []
            
            for text in texts:
                words = text.lower().split()
                all_unigrams.extend(words)
                
                # Create bigrams
                for i in range(len(words) - 1):
                    all_bigrams.append((words[i], words[i + 1]))
            
            distinct_1 = len(set(all_unigrams)) / len(all_unigrams) if all_unigrams else 0
            distinct_2 = len(set(all_bigrams)) / len(all_bigrams) if all_bigrams else 0
            
            return {
                "distinct_1": distinct_1,
                "distinct_2": distinct_2,
                "vocab_size": len(set(all_unigrams))
            }
        except Exception as e:
            logger.error(f"Diversity computation failed: {e}")
            return {"distinct_1": 0.0, "distinct_2": 0.0, "error": str(e)}
    
    def _compute_coherence(self, texts: List[str]) -> Dict[str, float]:
        """Compute coherence score (simplified implementation)."""
        try:
            # Simplified coherence based on sentence length consistency
            coherence_scores = []
            
            for text in texts:
                sentences = text.split('.')
                if len(sentences) > 1:
                    lengths = [len(s.split()) for s in sentences if s.strip()]
                    if lengths:
                        # Coherence as inverse of length variance
                        coherence = 1.0 / (1.0 + np.var(lengths))
                        coherence_scores.append(coherence)
                    else:
                        coherence_scores.append(0.5)
                else:
                    coherence_scores.append(0.5)
            
            return {
                "coherence": np.mean(coherence_scores),
                "coherence_std": np.std(coherence_scores)
            }
        except Exception as e:
            logger.error(f"Coherence computation failed: {e}")
            return {"coherence": 0.5, "error": str(e)}
    
    def _compute_fluency(self, texts: List[str]) -> Dict[str, float]:
        """Compute fluency score (simplified implementation)."""
        try:
            fluency_scores = []
            
            for text in texts:
                # Simplified fluency based on word count and sentence structure
                words = text.split()
                sentences = text.split('.')
                
                if len(words) > 0 and len(sentences) > 0:
                    avg_words_per_sentence = len(words) / len(sentences)
                    # Fluency based on reasonable sentence length (5-20 words)
                    if 5 <= avg_words_per_sentence <= 20:
                        fluency = 1.0
                    else:
                        fluency = max(0.0, 1.0 - abs(avg_words_per_sentence - 12.5) / 12.5)
                    
                    fluency_scores.append(fluency)
                else:
                    fluency_scores.append(0.0)
            
            return {
                "fluency": np.mean(fluency_scores),
                "fluency_std": np.std(fluency_scores)
            }
        except Exception as e:
            logger.error(f"Fluency computation failed: {e}")
            return {"fluency": 0.0, "error": str(e)}


class ImageMetrics:
    """
    Metrics calculator for Image Generation Models.
    
    Supports metrics including:
    - FID (Fréchet Inception Distance)
    - IS (Inception Score)
    - LPIPS (Learned Perceptual Image Patch Similarity)
    """
    
    def __init__(self):
        self.available_metrics = [
            MetricType.FID,
            MetricType.IS,
            MetricType.LPIPS
        ]
    
    def evaluate(
        self,
        model_path: str,
        test_images_dir: str,
        reference_images_dir: Optional[str] = None,
        metrics: List[str] = None,
        **kwargs
    ) -> Dict[str, Any]:
        """
        Evaluate image generation model.
        
        Args:
            model_path: Path to the image model
            test_images_dir: Directory with test images
            reference_images_dir: Directory with reference images
            metrics: Metrics to compute
            **kwargs: Additional parameters
            
        Returns:
            Image evaluation results
        """
        if metrics is None:
            metrics = [MetricType.FID, MetricType.IS]
        
        results = {
            "model_path": model_path,
            "test_images_dir": test_images_dir,
            "reference_images_dir": reference_images_dir,
            "metrics": {}
        }
        
        for metric in metrics:
            try:
                if metric == MetricType.FID:
                    score = self._compute_fid(test_images_dir, reference_images_dir)
                elif metric == MetricType.IS:
                    score = self._compute_is(test_images_dir)
                elif metric == MetricType.LPIPS:
                    score = self._compute_lpips(test_images_dir, reference_images_dir)
                else:
                    logger.warning(f"Unknown image metric: {metric}")
                    continue
                
                results["metrics"][metric] = score
                logger.info(f"Computed {metric}: {score}")
                
            except Exception as e:
                logger.error(f"Failed to compute {metric}: {e}")
                results["metrics"][metric] = {"error": str(e)}
        
        return results
    
    def _compute_fid(self, test_dir: str, reference_dir: Optional[str]) -> Dict[str, float]:
        """Compute FID score (placeholder implementation)."""
        # This is a placeholder - actual FID requires complex neural network computations
        logger.warning("FID computation not fully implemented - returning placeholder")
        return {
            "fid": np.random.uniform(20, 100),  # Placeholder
            "note": "Placeholder implementation"
        }
    
    def _compute_is(self, images_dir: str) -> Dict[str, float]:
        """Compute Inception Score (placeholder implementation)."""
        # This is a placeholder - actual IS requires Inception network
        logger.warning("IS computation not fully implemented - returning placeholder")
        return {
            "is_mean": np.random.uniform(2, 10),  # Placeholder
            "is_std": np.random.uniform(0.1, 1.0),
            "note": "Placeholder implementation"
        }
    
    def _compute_lpips(self, test_dir: str, reference_dir: Optional[str]) -> Dict[str, float]:
        """Compute LPIPS score (placeholder implementation)."""
        # This is a placeholder - actual LPIPS requires perceptual loss networks
        logger.warning("LPIPS computation not fully implemented - returning placeholder")
        return {
            "lpips": np.random.uniform(0.1, 0.8),  # Placeholder
            "note": "Placeholder implementation"
        }


class BenchmarkRunner:
    """
    Runner for standard AI benchmarks.
    
    Supports running various benchmarks and collecting results.
    """
    
    def __init__(self):
        self.supported_benchmarks = ["mmlu", "hellaswag", "arc", "gsm8k"]
        
        # Initialize AI factory if available
        if AI_FACTORY_AVAILABLE:
            try:
                self.ai_factory = AIFactory()
            except Exception as e:
                logger.warning(f"Failed to initialize AIFactory: {e}")
                self.ai_factory = None
        else:
            self.ai_factory = None
    
    def run(
        self,
        benchmark,
        model_path: str,
        num_shots: int = 0,
        max_samples: Optional[int] = None,
        provider: str = "ollama",
        **kwargs
    ) -> Dict[str, Any]:
        """
        Run a benchmark evaluation.
        
        Args:
            benchmark: Benchmark instance
            model_path: Path to the model
            num_shots: Number of few-shot examples
            max_samples: Maximum samples to evaluate
            provider: Model provider
            **kwargs: Additional parameters
            
        Returns:
            Benchmark results
        """
        logger.info(f"Running benchmark {benchmark.name} on {model_path}")
        
        # Load benchmark data
        test_data = benchmark.load_data(max_samples=max_samples)
        
        # Run evaluation
        results = {
            "benchmark": benchmark.name,
            "model_path": model_path,
            "num_shots": num_shots,
            "num_samples": len(test_data),
            "results": {}
        }
        
        # Process each sample
        correct = 0
        total = 0
        
        for sample in test_data:
            try:
                # Format prompt using benchmark's method
                prompt = benchmark.format_prompt(sample)
                
                # Generate prediction using actual model
                prediction = self._generate_prediction(
                    model_path, {"prompt": prompt}, num_shots, provider, **kwargs
                )
                
                # Check if correct
                is_correct = benchmark.evaluate_sample(sample, prediction)
                if is_correct:
                    correct += 1
                total += 1
                
            except Exception as e:
                logger.error(f"Failed to process sample: {e}")
                continue
        
        # Calculate final score
        accuracy = correct / total if total > 0 else 0.0
        
        results["results"] = {
            "accuracy": accuracy,
            "correct": correct,
            "total": total
        }
        
        logger.info(f"Benchmark completed: {accuracy:.3f} accuracy ({correct}/{total})")
        return results
    
    def _generate_prediction(
        self,
        model_path: str,
        sample: Dict[str, Any],
        num_shots: int,
        provider: str,
        **kwargs
    ) -> str:
        """Generate prediction for a sample using actual model inference."""
        if not self.ai_factory:
            logger.warning("AIFactory not available, using placeholder prediction")
            return "A"  # Placeholder answer
        
        try:
            # Get LLM service
            llm_service = self.ai_factory.get_llm(model_name=model_path, provider=provider)
            
            # Format the prompt (this should be done by the benchmark)
            if hasattr(sample, 'get'):
                prompt = sample.get('prompt', str(sample))
            else:
                prompt = str(sample)
            
            # Generate prediction using actual model
            response = llm_service.generate(
                prompt=prompt,
                max_tokens=kwargs.get("max_tokens", 50),
                temperature=kwargs.get("temperature", 0.0)  # Low temperature for consistency
            )
            
            # Extract text from response
            if hasattr(response, 'text'):
                prediction = response.text
            elif isinstance(response, dict) and 'text' in response:
                prediction = response['text']
            elif isinstance(response, str):
                prediction = response
            else:
                prediction = str(response)
            
            return prediction.strip()
            
        except Exception as e:
            logger.error(f"Failed to generate prediction: {e}")
            return "A"  # Fallback answer


# Utility functions for evaluators
def compute_text_metrics(predictions: Union[str, List[str]], 
                        references: Union[str, List[str]], 
                        aggregate: bool = False) -> Dict[str, float]:
    """
    Compute standard text evaluation metrics.
    
    Args:
        predictions: Single prediction or list of predictions
        references: Single reference or list of references
        aggregate: Whether to compute aggregate metrics for lists
        
    Returns:
        Dictionary of computed metrics
    """
    try:
        # Handle single string inputs
        if isinstance(predictions, str) and isinstance(references, str):
            pred_list = [predictions]
            ref_list = [references]
        else:
            pred_list = predictions if isinstance(predictions, list) else [str(predictions)]
            ref_list = references if isinstance(references, list) else [str(references)]
        
        # Ensure equal lengths
        min_len = min(len(pred_list), len(ref_list))
        pred_list = pred_list[:min_len]
        ref_list = ref_list[:min_len]
        
        metrics = {}
        
        # Exact match
        exact_matches = sum(1 for p, r in zip(pred_list, ref_list) if p.strip().lower() == r.strip().lower())
        metrics["exact_match"] = exact_matches / len(pred_list) if pred_list else 0.0
        
        # F1 Score (token-level)
        f1_scores = []
        for pred, ref in zip(pred_list, ref_list):
            pred_tokens = set(pred.lower().split())
            ref_tokens = set(ref.lower().split())
            
            if not ref_tokens and not pred_tokens:
                f1_scores.append(1.0)
            elif not ref_tokens or not pred_tokens:
                f1_scores.append(0.0)
            else:
                intersection = len(pred_tokens & ref_tokens)
                precision = intersection / len(pred_tokens)
                recall = intersection / len(ref_tokens)
                
                if precision + recall > 0:
                    f1 = 2 * (precision * recall) / (precision + recall)
                    f1_scores.append(f1)
                else:
                    f1_scores.append(0.0)
        
        metrics["f1_score"] = np.mean(f1_scores) if f1_scores else 0.0
        
        # BLEU Score (simplified)
        bleu_scores = []
        for pred, ref in zip(pred_list, ref_list):
            pred_words = pred.lower().split()
            ref_words = ref.lower().split()
            
            # Simple n-gram overlap
            overlap = len(set(pred_words) & set(ref_words))
            total = len(set(pred_words) | set(ref_words))
            
            bleu_scores.append(overlap / total if total > 0 else 0.0)
        
        metrics["bleu_score"] = np.mean(bleu_scores) if bleu_scores else 0.0
        
        # ROUGE-L (simplified)
        rouge_scores = []
        for pred, ref in zip(pred_list, ref_list):
            pred_words = set(pred.lower().split())
            ref_words = set(ref.lower().split())
            
            if len(ref_words) > 0:
                rouge_l = len(pred_words & ref_words) / len(ref_words)
                rouge_scores.append(rouge_l)
            else:
                rouge_scores.append(0.0)
        
        metrics["rouge_l"] = np.mean(rouge_scores) if rouge_scores else 0.0
        
        # Response length metrics
        pred_lengths = [len(p.split()) for p in pred_list]
        ref_lengths = [len(r.split()) for r in ref_list]
        
        metrics["avg_prediction_length"] = np.mean(pred_lengths) if pred_lengths else 0.0
        metrics["avg_reference_length"] = np.mean(ref_lengths) if ref_lengths else 0.0
        metrics["length_ratio"] = (np.mean(pred_lengths) / np.mean(ref_lengths)) if np.mean(ref_lengths) > 0 else 0.0
        
        # Diversity metrics for predictions
        if len(pred_list) > 1:
            all_words = []
            for pred in pred_list:
                all_words.extend(pred.lower().split())
            
            unique_words = len(set(all_words))
            total_words = len(all_words)
            
            metrics["vocabulary_diversity"] = unique_words / total_words if total_words > 0 else 0.0
        
        return metrics
        
    except Exception as e:
        logger.error(f"Error computing text metrics: {e}")
        return {"text_metrics_error": 1.0}


def compute_vision_metrics(predictions: List[Any], 
                          references: List[Any], 
                          task_type: str = "general") -> Dict[str, float]:
    """
    Compute vision-specific evaluation metrics.
    
    Args:
        predictions: List of vision model predictions
        references: List of reference outputs
        task_type: Type of vision task (ocr, detection, etc.)
        
    Returns:
        Dictionary of computed metrics
    """
    try:
        metrics = {}
        
        # Basic success rate
        successful_predictions = sum(1 for p in predictions if p is not None)
        metrics["prediction_success_rate"] = successful_predictions / len(predictions) if predictions else 0.0
        
        # Task-specific metrics would be computed by individual evaluators
        # This is a placeholder for common vision metrics
        
        if task_type == "ocr":
            # OCR-specific metrics would be computed in VisionEvaluator
            pass
        elif task_type == "detection":
            # Object detection metrics (IoU, mAP, etc.)
            pass
        elif task_type == "classification":
            # Image classification metrics
            pass
        
        return metrics
        
    except Exception as e:
        logger.error(f"Error computing vision metrics: {e}")
        return {"vision_metrics_error": 1.0}


# MCP集成的医疗评估功能
class MedicalMetrics:
    """
    医疗评估指标类，集成MCP服务进行专业的医疗AI评估
    
    支持的医疗评估类型:
    - 干细胞治疗方案评估
    - 医疗安全性评估
    - 治疗方案完整性评估
    """
    
    def __init__(self, mcp_base_url: str = "http://localhost:8081"):
        """
        初始化医疗评估指标
        
        Args:
            mcp_base_url: MCP服务器地址
        """
        self.mcp_base_url = mcp_base_url
        self.available_metrics = [
            MetricType.STEM_CELL_ACCURACY,
            MetricType.MEDICAL_SAFETY,
            MetricType.TREATMENT_COMPLETENESS
        ]
        
        # 尝试导入MCP客户端
        try:
            from .mcp_client import MCPClient, compute_stem_cell_accuracy_via_mcp
            self.MCPClient = MCPClient
            self.compute_via_mcp = compute_stem_cell_accuracy_via_mcp
            self.mcp_available = True
            logger.info("MCP客户端导入成功，医疗评估功能可用")
        except ImportError as e:
            logger.warning(f"MCP客户端导入失败: {e}，医疗评估功能不可用")
            self.mcp_available = False
    
    async def evaluate(self,
                      predictions: List[str],
                      references: List[str],
                      metrics: List[str],
                      patient_info: Optional[List[Dict[str, Any]]] = None,
                      user_id: Optional[str] = None,
                      **kwargs) -> Dict[str, Any]:
        """
        执行医疗评估
        
        Args:
            predictions: 模型预测结果
            references: 参考答案
            metrics: 要计算的评估指标
            patient_info: 患者信息(可选)
            user_id: 用户ID(用于定制化配置)
            **kwargs: 额外参数
            
        Returns:
            医疗评估结果
        """
        if not self.mcp_available:
            logger.error("MCP客户端不可用，无法进行医疗评估")
            return {
                "error": "MCP客户端不可用",
                "available_metrics": [],
                "timestamp": datetime.now().isoformat()
            }
        
        results = {
            "medical_evaluation": True,
            "user_id": user_id,
            "metrics": {},
            "num_samples": len(predictions),
            "timestamp": datetime.now().isoformat()
        }
        
        for metric in metrics:
            try:
                if metric == MetricType.STEM_CELL_ACCURACY:
                    result = await self._compute_stem_cell_accuracy(
                        predictions, references, patient_info, user_id
                    )
                elif metric == MetricType.MEDICAL_SAFETY:
                    result = await self._compute_medical_safety(
                        predictions, references, patient_info
                    )
                elif metric == MetricType.TREATMENT_COMPLETENESS:
                    result = await self._compute_treatment_completeness(
                        predictions, references
                    )
                else:
                    logger.warning(f"不支持的医疗评估指标: {metric}")
                    continue
                
                results["metrics"][metric] = result
                logger.info(f"计算完成医疗指标 {metric}")
                
            except Exception as e:
                logger.error(f"计算医疗指标 {metric} 时出错: {e}")
                results["metrics"][metric] = {
                    "error": str(e),
                    "timestamp": datetime.now().isoformat()
                }
        
        return results
    
    async def _compute_stem_cell_accuracy(self,
                                        predictions: List[str],
                                        references: List[str],
                                        patient_info: Optional[List[Dict[str, Any]]],
                                        user_id: Optional[str]) -> Dict[str, Any]:
        """计算干细胞治疗方案准确率"""
        if not self.mcp_available:
            raise RuntimeError("MCP客户端不可用")
        
        result = await self.compute_via_mcp(
            predictions=predictions,
            references=references,
            patient_info=patient_info,
            user_id=user_id,
            mcp_base_url=self.mcp_base_url
        )
        
        if result is None:
            raise RuntimeError("MCP服务器返回空结果")
        
        return result
    
    async def _compute_medical_safety(self,
                                    predictions: List[str],
                                    references: List[str],
                                    patient_info: Optional[List[Dict[str, Any]]]) -> Dict[str, Any]:
        """计算医疗安全性评分"""
        if not self.mcp_available:
            raise RuntimeError("MCP客户端不可用")
        
        async with self.MCPClient(self.mcp_base_url) as client:
            # 获取安全性要求
            safety_requirements = await client.get_safety_requirements()
            
            if not safety_requirements:
                raise RuntimeError("无法获取安全性要求配置")
            
            # 逐个检查治疗方案的安全性
            safety_scores = []
            
            for i, (pred, ref) in enumerate(zip(predictions, references)):
                patient_profile = patient_info[i] if patient_info and i < len(patient_info) else None
                
                safety_result = await client.check_safety_compliance(
                    treatment_plan=pred,
                    patient_profile=patient_profile
                )
                
                if safety_result and safety_result.get("status") == "success":
                    safety_data = safety_result.get("data", {})
                    safety_scores.append(safety_data.get("safety_score", 0.0))
                else:
                    safety_scores.append(0.0)
            
            return {
                "status": "success",
                "data": {
                    "overall_safety_score": np.mean(safety_scores) if safety_scores else 0.0,
                    "individual_scores": safety_scores,
                    "safety_requirements_used": safety_requirements.get("version", "unknown"),
                    "samples_evaluated": len(safety_scores)
                },
                "timestamp": datetime.now().isoformat()
            }
    
    async def _compute_treatment_completeness(self,
                                           predictions: List[str],
                                           references: List[str]) -> Dict[str, Any]:
        """计算治疗方案完整性评分"""
        if not self.mcp_available:
            raise RuntimeError("MCP客户端不可用")
        
        async with self.MCPClient(self.mcp_base_url) as client:
            # 获取评估标准
            criteria = await client.get_stem_cell_criteria()
            
            if not criteria:
                raise RuntimeError("无法获取评估标准配置")
            
            completeness_scores = []
            
            for pred, ref in zip(predictions, references):
                validation_result = await client.validate_treatment_plan(
                    treatment_plan=pred,
                    validation_rules=criteria
                )
                
                if validation_result and validation_result.get("status") == "success":
                    validation_data = validation_result.get("data", {})
                    completeness_scores.append(validation_data.get("completeness_score", 0.0))
                else:
                    completeness_scores.append(0.0)
            
            return {
                "status": "success",
                "data": {
                    "overall_completeness_score": np.mean(completeness_scores) if completeness_scores else 0.0,
                    "individual_scores": completeness_scores,
                    "criteria_used": criteria.get("version", "unknown"),
                    "samples_evaluated": len(completeness_scores)
                },
                "timestamp": datetime.now().isoformat()
            }


# 便捷函数：计算干细胞治疗方案准确率
async def compute_stem_cell_accuracy(predictions: List[str],
                                   references: List[str],
                                   patient_info: Optional[List[Dict[str, Any]]] = None,
                                   user_id: Optional[str] = None,
                                   mcp_base_url: str = "http://localhost:8081") -> Optional[Dict[str, Any]]:
    """
    计算干细胞治疗方案准确率的便捷函数
    
    Args:
        predictions: 模型预测的治疗方案
        references: 参考治疗方案
        patient_info: 患者信息(可选)
        user_id: 用户ID(用于定制化配置)
        mcp_base_url: MCP服务器地址
        
    Returns:
        评估结果，包含各维度评分和总体准确率
    """
    try:
        medical_metrics = MedicalMetrics(mcp_base_url)
        
        result = await medical_metrics.evaluate(
            predictions=predictions,
            references=references,
            metrics=[MetricType.STEM_CELL_ACCURACY],
            patient_info=patient_info,
            user_id=user_id
        )
        
        return result.get("metrics", {}).get(MetricType.STEM_CELL_ACCURACY)
        
    except Exception as e:
        logger.error(f"计算干细胞准确率时出错: {e}")
        return None


# 便捷函数：综合医疗评估
async def compute_comprehensive_medical_evaluation(predictions: List[str],
                                                 references: List[str],
                                                 patient_info: Optional[List[Dict[str, Any]]] = None,
                                                 user_id: Optional[str] = None,
                                                 mcp_base_url: str = "http://localhost:8081") -> Optional[Dict[str, Any]]:
    """
    执行综合医疗评估的便捷函数
    
    Args:
        predictions: 模型预测结果
        references: 参考答案
        patient_info: 患者信息
        user_id: 用户ID
        mcp_base_url: MCP服务器地址
        
    Returns:
        综合评估结果
    """
    try:
        medical_metrics = MedicalMetrics(mcp_base_url)
        
        return await medical_metrics.evaluate(
            predictions=predictions,
            references=references,
            metrics=[
                MetricType.STEM_CELL_ACCURACY,
                MetricType.MEDICAL_SAFETY,
                MetricType.TREATMENT_COMPLETENESS
            ],
            patient_info=patient_info,
            user_id=user_id
        )
        
    except Exception as e:
        logger.error(f"综合医疗评估时出错: {e}")
        return None 