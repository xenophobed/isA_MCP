"""
MCP客户端接口 - 用于与MCP服务器通信

提供访问医疗评估资源和工具的接口，
支持干细胞治疗方案评估的定制化功能。

Usage:
    from isa_model.eval.mcp_client import MCPClient
    
    client = MCPClient()
    criteria = await client.read_resource("medical://stem_cell/criteria")
    result = await client.call_tool("compute_stem_cell_accuracy", {...})
"""

import aiohttp
import asyncio
import json
import logging
from typing import Dict, List, Any, Optional, Union
from datetime import datetime

logger = logging.getLogger(__name__)


class MCPClient:
    """MCP客户端，用于与MCP服务器通信"""
    
    def __init__(self, 
                 base_url: str = "http://localhost:8081",
                 timeout: int = 30):
        """
        初始化MCP客户端
        
        Args:
            base_url: MCP服务器地址
            timeout: 请求超时时间(秒)
        """
        self.base_url = base_url.rstrip('/')
        self.timeout = aiohttp.ClientTimeout(total=timeout)
        self._session = None
        
    async def __aenter__(self):
        """异步上下文管理器入口"""
        await self._ensure_session()
        return self
        
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """异步上下文管理器出口"""
        await self.close()
    
    async def _ensure_session(self):
        """确保HTTP会话已建立"""
        if self._session is None or self._session.closed:
            self._session = aiohttp.ClientSession(timeout=self.timeout)
    
    async def close(self):
        """关闭HTTP会话"""
        if self._session and not self._session.closed:
            await self._session.close()
            self._session = None
    
    async def read_resource(self, uri: str) -> Optional[Dict[str, Any]]:
        """
        读取MCP资源
        
        Args:
            uri: 资源URI，如 "medical://stem_cell/criteria"
            
        Returns:
            资源内容字典，读取失败时返回None
        """
        try:
            await self._ensure_session()
            
            # MCP resources/read 端点
            url = f"{self.base_url}/mcp/resources/read"
            
            payload = {
                "jsonrpc": "2.0",
                "id": 1,
                "method": "resources/read",
                "params": {
                    "uri": uri
                }
            }
            
            headers = {
                'Content-Type': 'application/json',
                'Accept': 'application/json, text/event-stream'
            }
            
            async with self._session.post(url, json=payload, headers=headers) as response:
                if response.status != 200:
                    logger.error(f"MCP资源读取失败，状态码: {response.status}")
                    return None
                
                text = await response.text()
                return self._parse_event_stream_response(text)
                
        except Exception as e:
            logger.error(f"读取MCP资源 {uri} 时出错: {e}")
            return None
    
    async def call_tool(self, 
                       tool_name: str, 
                       arguments: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """
        调用MCP工具
        
        Args:
            tool_name: 工具名称，如 "compute_stem_cell_accuracy"
            arguments: 工具参数
            
        Returns:
            工具执行结果，调用失败时返回None
        """
        try:
            await self._ensure_session()
            
            # MCP tools/call 端点
            url = f"{self.base_url}/mcp/tools/call"
            
            payload = {
                "jsonrpc": "2.0",
                "id": 1,
                "method": "tools/call",
                "params": {
                    "name": tool_name,
                    "arguments": arguments
                }
            }
            
            headers = {
                'Content-Type': 'application/json',
                'Accept': 'application/json, text/event-stream'
            }
            
            async with self._session.post(url, json=payload, headers=headers) as response:
                if response.status != 200:
                    logger.error(f"MCP工具调用失败，状态码: {response.status}")
                    return None
                
                text = await response.text()
                return self._parse_event_stream_response(text)
                
        except Exception as e:
            logger.error(f"调用MCP工具 {tool_name} 时出错: {e}")
            return None
    
    async def search_resources(self, 
                              query: str, 
                              resource_types: Optional[List[str]] = None,
                              max_results: int = 10) -> Optional[Dict[str, Any]]:
        """
        搜索MCP资源
        
        Args:
            query: 搜索关键词
            resource_types: 资源类型过滤器
            max_results: 最大结果数量
            
        Returns:
            搜索结果，失败时返回None
        """
        try:
            await self._ensure_session()
            
            url = f"{self.base_url}/search"
            
            payload = {
                "query": query,
                "max_results": max_results
            }
            
            if resource_types:
                payload["filters"] = {"types": resource_types}
            
            headers = {'Content-Type': 'application/json'}
            
            async with self._session.post(url, json=payload, headers=headers) as response:
                if response.status != 200:
                    logger.error(f"MCP资源搜索失败，状态码: {response.status}")
                    return None
                
                return await response.json()
                
        except Exception as e:
            logger.error(f"搜索MCP资源时出错: {e}")
            return None
    
    def _parse_event_stream_response(self, text: str) -> Optional[Dict[str, Any]]:
        """
        解析事件流响应
        
        Args:
            text: 响应文本
            
        Returns:
            解析后的数据，失败时返回None
        """
        try:
            lines = text.strip().split('\n')
            for line in lines:
                if line.startswith('data: '):
                    data = json.loads(line[6:])
                    if 'result' in data:
                        # 对于资源读取，返回资源内容
                        if 'contents' in data['result']:
                            content = data['result']['contents'][0]
                            if content.get('mimeType') == 'text/plain':
                                content_text = content['text']
                                try:
                                    # 尝试解析JSON内容
                                    return json.loads(content_text)
                                except json.JSONDecodeError:
                                    # 如果不是JSON，返回原始文本
                                    return {"text": content_text}
                        
                        # 对于工具调用，返回工具结果
                        elif 'content' in data['result']:
                            tool_result = data['result']['content'][0]['text']
                            try:
                                return json.loads(tool_result)
                            except json.JSONDecodeError:
                                return {"text": tool_result}
                        
                        # 直接返回结果
                        return data['result']
            
            return None
            
        except Exception as e:
            logger.error(f"解析事件流响应时出错: {e}")
            return None
    
    async def get_stem_cell_criteria(self, user_id: Optional[str] = None) -> Optional[Dict[str, Any]]:
        """
        获取干细胞评估标准
        
        Args:
            user_id: 用户ID，如果提供则获取用户定制配置
            
        Returns:
            评估标准配置
        """
        if user_id:
            # 优先获取用户定制配置
            user_config = await self.read_resource(f"medical://stem_cell/user/{user_id}/configs")
            if user_config:
                return user_config
        
        # 获取默认标准
        return await self.read_resource("medical://stem_cell/criteria")
    
    async def get_medical_knowledge_base(self) -> Optional[Dict[str, Any]]:
        """获取医学知识库"""
        return await self.read_resource("medical://stem_cell/knowledge_base")
    
    async def get_safety_requirements(self) -> Optional[Dict[str, Any]]:
        """获取安全性要求"""
        return await self.read_resource("medical://stem_cell/safety_requirements")
    
    async def compute_stem_cell_accuracy(self, 
                                       predictions: List[str],
                                       references: List[str],
                                       patient_info: Optional[List[Dict[str, Any]]] = None,
                                       user_id: Optional[str] = None) -> Optional[Dict[str, Any]]:
        """
        计算干细胞治疗方案准确率
        
        Args:
            predictions: 模型预测结果
            references: 参考答案
            patient_info: 患者信息(可选)
            user_id: 用户ID(用于获取定制配置)
            
        Returns:
            评估结果
        """
        # 获取评估标准
        criteria = await self.get_stem_cell_criteria(user_id)
        
        arguments = {
            "predictions": predictions,
            "references": references,
            "criteria": criteria,
            "patient_info": patient_info
        }
        
        return await self.call_tool("compute_stem_cell_accuracy", arguments)
    
    async def validate_treatment_plan(self, 
                                    treatment_plan: str,
                                    validation_rules: Optional[Dict[str, Any]] = None) -> Optional[Dict[str, Any]]:
        """验证治疗方案"""
        arguments = {
            "treatment_plan": treatment_plan,
            "validation_rules": validation_rules
        }
        
        return await self.call_tool("validate_treatment_plan", arguments)
    
    async def check_safety_compliance(self, 
                                    treatment_plan: str,
                                    patient_profile: Optional[Dict[str, Any]] = None) -> Optional[Dict[str, Any]]:
        """检查安全性合规"""
        arguments = {
            "treatment_plan": treatment_plan,
            "patient_profile": patient_profile
        }
        
        return await self.call_tool("check_safety_compliance", arguments)
    
    async def health_check(self) -> bool:
        """检查MCP服务器健康状态"""
        try:
            await self._ensure_session()
            
            url = f"{self.base_url}/capabilities"
            
            async with self._session.get(url) as response:
                if response.status == 200:
                    capabilities = await response.json()
                    return capabilities.get("status") == "success"
                else:
                    return False
                    
        except Exception as e:
            logger.error(f"MCP健康检查失败: {e}")
            return False


class MCPClientSingleton:
    """MCP客户端单例"""
    
    _instance = None
    _client = None
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance
    
    async def get_client(self, base_url: str = "http://localhost:8081") -> MCPClient:
        """获取MCP客户端实例"""
        if self._client is None:
            self._client = MCPClient(base_url)
        return self._client
    
    async def close(self):
        """关闭客户端"""
        if self._client:
            await self._client.close()
            self._client = None


# 便捷函数
async def get_mcp_client() -> MCPClient:
    """获取MCP客户端实例"""
    singleton = MCPClientSingleton()
    return await singleton.get_client()


async def compute_stem_cell_accuracy_via_mcp(
    predictions: List[str],
    references: List[str],
    patient_info: Optional[List[Dict[str, Any]]] = None,
    user_id: Optional[str] = None,
    mcp_base_url: str = "http://localhost:8081"
) -> Optional[Dict[str, Any]]:
    """
    通过MCP计算干细胞治疗方案准确率的便捷函数
    
    Args:
        predictions: 模型预测结果
        references: 参考答案
        patient_info: 患者信息
        user_id: 用户ID
        mcp_base_url: MCP服务器地址
        
    Returns:
        评估结果
    """
    async with MCPClient(mcp_base_url) as client:
        # 检查服务器可用性
        if not await client.health_check():
            logger.warning("MCP服务器不可用，无法进行评估")
            return None
        
        return await client.compute_stem_cell_accuracy(
            predictions=predictions,
            references=references,
            patient_info=patient_info,
            user_id=user_id
        )