"""
Evaluation Repository - Data persistence layer for evaluation operations

Provides standardized data access for evaluation tasks, results, and metrics
following the ISA Model architecture pattern.
"""

import logging
import json
import uuid
from datetime import datetime, timezone
from typing import Dict, List, Optional, Any, Union
from pathlib import Path
from dataclasses import dataclass, asdict

try:
    # Try to import Supabase for centralized data storage
    from ...core.database.supabase_client import get_supabase_client
    SUPABASE_AVAILABLE = True
except ImportError:
    SUPABASE_AVAILABLE = False

try:
    # Try to import PostgreSQL for evaluation-specific storage
    import psycopg2
    from psycopg2.extras import RealDictCursor
    POSTGRES_AVAILABLE = True
except ImportError:
    POSTGRES_AVAILABLE = False

logger = logging.getLogger(__name__)

@dataclass
class EvaluationTask:
    """Evaluation task record"""
    task_id: str
    task_name: str
    model_id: str
    evaluator_type: str
    dataset_name: str
    config: Dict[str, Any]
    status: str = "pending"  # pending, running, completed, failed
    created_at: datetime = None
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    user_id: Optional[str] = None
    project_name: Optional[str] = None
    tags: Optional[Dict[str, str]] = None
    error_message: Optional[str] = None
    
    def __post_init__(self):
        if self.created_at is None:
            self.created_at = datetime.now(timezone.utc)

@dataclass
class EvaluationResult:
    """Evaluation result record"""
    result_id: str
    task_id: str
    metrics: Dict[str, Any]
    detailed_results: Optional[Dict[str, Any]] = None
    sample_results: Optional[List[Dict[str, Any]]] = None
    execution_time_ms: Optional[int] = None
    cost_usd: Optional[float] = None
    created_at: datetime = None
    metadata: Optional[Dict[str, Any]] = None
    
    def __post_init__(self):
        if self.created_at is None:
            self.created_at = datetime.now(timezone.utc)

@dataclass
class EvaluationMetrics:
    """Evaluation metrics record"""
    metric_id: str
    task_id: str
    metric_name: str
    metric_value: float
    metric_type: str  # accuracy, f1_score, bleu, rouge, etc.
    sample_count: int
    created_at: datetime = None
    additional_data: Optional[Dict[str, Any]] = None
    
    def __post_init__(self):
        if self.created_at is None:
            self.created_at = datetime.now(timezone.utc)

class EvaluationRepository:
    """
    Repository for evaluation data persistence
    
    Supports multiple backend storage options:
    1. Supabase (preferred for centralized storage)
    2. PostgreSQL (dedicated evaluation database)
    3. Local file system (fallback for development)
    """
    
    def __init__(self, storage_backend: str = "auto", **kwargs):
        """
        Initialize evaluation repository
        
        Args:
            storage_backend: "supabase", "postgres", "file", or "auto"
            **kwargs: Backend-specific configuration
        """
        self.storage_backend = self._determine_backend(storage_backend)
        self.config = kwargs
        
        # Initialize storage backend
        if self.storage_backend == "supabase":
            self._init_supabase()
        elif self.storage_backend == "postgres":
            self._init_postgres()
        else:  # file system fallback
            self._init_file_system()
        
        logger.info(f"Evaluation repository initialized with {self.storage_backend} backend")
    
    def _determine_backend(self, preference: str) -> str:
        """Determine the best available storage backend"""
        if preference == "supabase" and SUPABASE_AVAILABLE:
            return "supabase"
        elif preference == "postgres" and POSTGRES_AVAILABLE:
            return "postgres"
        elif preference in ["supabase", "postgres", "file"]:
            return preference
        
        # Auto-select best available backend
        if SUPABASE_AVAILABLE:
            return "supabase"
        elif POSTGRES_AVAILABLE:
            return "postgres"
        else:
            return "file"
    
    def _init_supabase(self):
        """Initialize Supabase backend"""
        try:
            self.supabase_client = get_supabase_client()
            self._ensure_supabase_tables()
            logger.info("Supabase backend initialized for evaluations")
        except Exception as e:
            logger.error(f"Failed to initialize Supabase backend: {e}")
            self.storage_backend = "file"
            self._init_file_system()
    
    def _init_postgres(self):
        """Initialize PostgreSQL backend"""
        try:
            self.pg_config = {
                "host": self.config.get("pg_host", "localhost"),
                "port": self.config.get("pg_port", 5432),
                "database": self.config.get("pg_database", "isa_evaluations"),
                "user": self.config.get("pg_user", "postgres"),
                "password": self.config.get("pg_password", "")
            }
            
            # Test connection
            with psycopg2.connect(**self.pg_config) as conn:
                with conn.cursor() as cur:
                    cur.execute("SELECT version()")
                    version = cur.fetchone()[0]
                    logger.info(f"PostgreSQL backend initialized: {version}")
            
            self._ensure_postgres_tables()
            
        except Exception as e:
            logger.error(f"Failed to initialize PostgreSQL backend: {e}")
            self.storage_backend = "file"
            self._init_file_system()
    
    def _init_file_system(self):
        """Initialize file system backend"""
        self.data_dir = Path(self.config.get("data_dir", "./evaluation_data"))
        self.data_dir.mkdir(parents=True, exist_ok=True)
        
        # Create subdirectories
        (self.data_dir / "tasks").mkdir(exist_ok=True)
        (self.data_dir / "results").mkdir(exist_ok=True)
        (self.data_dir / "metrics").mkdir(exist_ok=True)
        
        logger.info(f"File system backend initialized: {self.data_dir}")
    
    def _ensure_supabase_tables(self):
        """Ensure required Supabase tables exist"""
        # Tables should be created via Supabase migrations
        # This is just a verification check
        try:
            self.supabase_client.table("evaluation_tasks").select("task_id").limit(1).execute()
            self.supabase_client.table("evaluation_results").select("result_id").limit(1).execute()
            self.supabase_client.table("evaluation_metrics").select("metric_id").limit(1).execute()
        except Exception as e:
            logger.warning(f"Some evaluation tables may not exist in Supabase: {e}")
    
    def _ensure_postgres_tables(self):
        """Ensure required PostgreSQL tables exist"""
        create_tables_sql = """
        CREATE SCHEMA IF NOT EXISTS evaluations;
        
        CREATE TABLE IF NOT EXISTS evaluations.evaluation_tasks (
            task_id VARCHAR(255) PRIMARY KEY,
            task_name VARCHAR(255) NOT NULL,
            model_id VARCHAR(255) NOT NULL,
            evaluator_type VARCHAR(100) NOT NULL,
            dataset_name VARCHAR(255) NOT NULL,
            config JSONB NOT NULL,
            status VARCHAR(50) DEFAULT 'pending',
            created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
            started_at TIMESTAMP WITH TIME ZONE,
            completed_at TIMESTAMP WITH TIME ZONE,
            user_id VARCHAR(255),
            project_name VARCHAR(255),
            tags JSONB,
            error_message TEXT
        );
        
        CREATE TABLE IF NOT EXISTS evaluations.evaluation_results (
            result_id VARCHAR(255) PRIMARY KEY,
            task_id VARCHAR(255) NOT NULL REFERENCES evaluations.evaluation_tasks(task_id) ON DELETE CASCADE,
            metrics JSONB NOT NULL,
            detailed_results JSONB,
            sample_results JSONB,
            execution_time_ms INTEGER,
            cost_usd NUMERIC(10, 4),
            created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
            metadata JSONB
        );
        
        CREATE TABLE IF NOT EXISTS evaluations.evaluation_metrics (
            metric_id VARCHAR(255) PRIMARY KEY,
            task_id VARCHAR(255) NOT NULL REFERENCES evaluations.evaluation_tasks(task_id) ON DELETE CASCADE,
            metric_name VARCHAR(100) NOT NULL,
            metric_value NUMERIC(10, 6) NOT NULL,
            metric_type VARCHAR(100) NOT NULL,
            sample_count INTEGER NOT NULL,
            created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
            additional_data JSONB
        );
        
        CREATE INDEX IF NOT EXISTS idx_eval_tasks_status ON evaluations.evaluation_tasks(status);
        CREATE INDEX IF NOT EXISTS idx_eval_tasks_created ON evaluations.evaluation_tasks(created_at);
        CREATE INDEX IF NOT EXISTS idx_eval_results_task ON evaluations.evaluation_results(task_id);
        CREATE INDEX IF NOT EXISTS idx_eval_metrics_task ON evaluations.evaluation_metrics(task_id);
        """
        
        try:
            with psycopg2.connect(**self.pg_config) as conn:
                with conn.cursor() as cur:
                    cur.execute(create_tables_sql)
                    conn.commit()
                    logger.info("PostgreSQL evaluation tables ensured")
        except Exception as e:
            logger.error(f"Failed to create PostgreSQL tables: {e}")
            raise
    
    # Task Management Methods
    
    def create_evaluation_task(
        self,
        task_name: str,
        model_id: str,
        evaluator_type: str,
        dataset_name: str,
        config: Dict[str, Any],
        user_id: Optional[str] = None,
        project_name: Optional[str] = None,
        tags: Optional[Dict[str, str]] = None
    ) -> str:
        """Create a new evaluation task"""
        task_id = f"eval_{datetime.now().strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:8]}"
        
        task = EvaluationTask(
            task_id=task_id,
            task_name=task_name,
            model_id=model_id,
            evaluator_type=evaluator_type,
            dataset_name=dataset_name,
            config=config,
            user_id=user_id,
            project_name=project_name,
            tags=tags
        )
        
        if self.storage_backend == "supabase":
            return self._create_task_supabase(task)
        elif self.storage_backend == "postgres":
            return self._create_task_postgres(task)
        else:
            return self._create_task_file(task)
    
    def update_task_status(
        self,
        task_id: str,
        status: str,
        error_message: Optional[str] = None,
        additional_updates: Optional[Dict[str, Any]] = None
    ) -> bool:
        """Update evaluation task status"""
        updates = {"status": status}
        
        if status == "running" and additional_updates is None:
            updates["started_at"] = datetime.now(timezone.utc).isoformat()
        elif status in ["completed", "failed"]:
            updates["completed_at"] = datetime.now(timezone.utc).isoformat()
        
        if error_message:
            updates["error_message"] = error_message
        
        if additional_updates:
            updates.update(additional_updates)
        
        if self.storage_backend == "supabase":
            return self._update_task_supabase(task_id, updates)
        elif self.storage_backend == "postgres":
            return self._update_task_postgres(task_id, updates)
        else:
            return self._update_task_file(task_id, updates)
    
    def get_evaluation_task(self, task_id: str) -> Optional[EvaluationTask]:
        """Get evaluation task by ID"""
        if self.storage_backend == "supabase":
            return self._get_task_supabase(task_id)
        elif self.storage_backend == "postgres":
            return self._get_task_postgres(task_id)
        else:
            return self._get_task_file(task_id)
    
    def list_evaluation_tasks(
        self,
        status: Optional[str] = None,
        user_id: Optional[str] = None,
        project_name: Optional[str] = None,
        limit: int = 100
    ) -> List[EvaluationTask]:
        """List evaluation tasks with optional filtering"""
        if self.storage_backend == "supabase":
            return self._list_tasks_supabase(status, user_id, project_name, limit)
        elif self.storage_backend == "postgres":
            return self._list_tasks_postgres(status, user_id, project_name, limit)
        else:
            return self._list_tasks_file(status, user_id, project_name, limit)
    
    # Result Management Methods
    
    def save_evaluation_results(
        self,
        task_id: str,
        metrics: Dict[str, Any],
        detailed_results: Optional[Dict[str, Any]] = None,
        sample_results: Optional[List[Dict[str, Any]]] = None,
        execution_time_ms: Optional[int] = None,
        cost_usd: Optional[float] = None,
        metadata: Optional[Dict[str, Any]] = None
    ) -> str:
        """Save evaluation results"""
        result_id = f"result_{task_id}_{uuid.uuid4().hex[:8]}"
        
        result = EvaluationResult(
            result_id=result_id,
            task_id=task_id,
            metrics=metrics,
            detailed_results=detailed_results,
            sample_results=sample_results,
            execution_time_ms=execution_time_ms,
            cost_usd=cost_usd,
            metadata=metadata
        )
        
        if self.storage_backend == "supabase":
            return self._save_results_supabase(result)
        elif self.storage_backend == "postgres":
            return self._save_results_postgres(result)
        else:
            return self._save_results_file(result)
    
    def get_task_results(self, task_id: str) -> List[EvaluationResult]:
        """Get all results for a task"""
        if self.storage_backend == "supabase":
            return self._get_results_supabase(task_id)
        elif self.storage_backend == "postgres":
            return self._get_results_postgres(task_id)
        else:
            return self._get_results_file(task_id)
    
    def list_evaluation_history(
        self,
        model_id: Optional[str] = None,
        evaluator_type: Optional[str] = None,
        days: int = 30,
        limit: int = 100
    ) -> List[Dict[str, Any]]:
        """List evaluation history with aggregated results"""
        if self.storage_backend == "supabase":
            return self._list_history_supabase(model_id, evaluator_type, days, limit)
        elif self.storage_backend == "postgres":
            return self._list_history_postgres(model_id, evaluator_type, days, limit)
        else:
            return self._list_history_file(model_id, evaluator_type, days, limit)
    
    # Statistics and Analytics
    
    def get_evaluation_statistics(self, user_id: Optional[str] = None) -> Dict[str, Any]:
        """Get evaluation statistics"""
        if self.storage_backend == "supabase":
            return self._get_stats_supabase(user_id)
        elif self.storage_backend == "postgres":
            return self._get_stats_postgres(user_id)
        else:
            return self._get_stats_file(user_id)
    
    def delete_evaluation_task(self, task_id: str) -> bool:
        """Delete evaluation task and all associated data"""
        if self.storage_backend == "supabase":
            return self._delete_task_supabase(task_id)
        elif self.storage_backend == "postgres":
            return self._delete_task_postgres(task_id)
        else:
            return self._delete_task_file(task_id)
    
    # Backend-specific implementations (simplified versions)
    # In production, these would have full implementations
    
    def _create_task_supabase(self, task: EvaluationTask) -> str:
        """Create task in Supabase"""
        try:
            task_data = asdict(task)
            # Convert datetime objects to ISO strings
            for key in ['created_at', 'started_at', 'completed_at']:
                if task_data[key] and isinstance(task_data[key], datetime):
                    task_data[key] = task_data[key].isoformat()
            
            result = self.supabase_client.table("evaluation_tasks").insert(task_data).execute()
            return task.task_id
        except Exception as e:
            logger.error(f"Failed to create task in Supabase: {e}")
            raise
    
    def _create_task_postgres(self, task: EvaluationTask) -> str:
        """Create task in PostgreSQL"""
        try:
            with psycopg2.connect(**self.pg_config) as conn:
                with conn.cursor() as cur:
                    cur.execute("""
                        INSERT INTO evaluations.evaluation_tasks 
                        (task_id, task_name, model_id, evaluator_type, dataset_name, config, 
                         status, created_at, user_id, project_name, tags)
                        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                    """, (
                        task.task_id, task.task_name, task.model_id, task.evaluator_type,
                        task.dataset_name, json.dumps(task.config), task.status,
                        task.created_at, task.user_id, task.project_name, 
                        json.dumps(task.tags) if task.tags else None
                    ))
                    conn.commit()
            return task.task_id
        except Exception as e:
            logger.error(f"Failed to create task in PostgreSQL: {e}")
            raise
    
    def _create_task_file(self, task: EvaluationTask) -> str:
        """Create task in file system"""
        try:
            task_file = self.data_dir / "tasks" / f"{task.task_id}.json"
            task_data = asdict(task)
            # Convert datetime objects to ISO strings
            for key in ['created_at', 'started_at', 'completed_at']:
                if task_data[key] and isinstance(task_data[key], datetime):
                    task_data[key] = task_data[key].isoformat()
            
            with open(task_file, 'w') as f:
                json.dump(task_data, f, indent=2, ensure_ascii=False)
            
            return task.task_id
        except Exception as e:
            logger.error(f"Failed to create task in file system: {e}")
            raise
    
    # Simplified implementations for other methods...
    def _update_task_supabase(self, task_id: str, updates: Dict[str, Any]) -> bool:
        """Update task in Supabase"""
        try:
            result = self.supabase_client.table("evaluation_tasks").update(updates).eq("task_id", task_id).execute()
            return len(result.data) > 0
        except Exception as e:
            logger.error(f"Failed to update task in Supabase: {e}")
            return False
    
    def _update_task_postgres(self, task_id: str, updates: Dict[str, Any]) -> bool:
        """Update task in PostgreSQL"""
        try:
            set_clause = ", ".join([f"{key} = %s" for key in updates.keys()])
            query = f"UPDATE evaluations.evaluation_tasks SET {set_clause} WHERE task_id = %s"
            
            with psycopg2.connect(**self.pg_config) as conn:
                with conn.cursor() as cur:
                    cur.execute(query, list(updates.values()) + [task_id])
                    conn.commit()
                    return cur.rowcount > 0
        except Exception as e:
            logger.error(f"Failed to update task in PostgreSQL: {e}")
            return False
    
    def _update_task_file(self, task_id: str, updates: Dict[str, Any]) -> bool:
        """Update task in file system"""
        try:
            task_file = self.data_dir / "tasks" / f"{task_id}.json"
            if not task_file.exists():
                return False
            
            with open(task_file, 'r') as f:
                task_data = json.load(f)
            
            task_data.update(updates)
            
            with open(task_file, 'w') as f:
                json.dump(task_data, f, indent=2, ensure_ascii=False)
            
            return True
        except Exception as e:
            logger.error(f"Failed to update task in file system: {e}")
            return False
    
    def _get_task_file(self, task_id: str) -> Optional[EvaluationTask]:
        """Get task from file system"""
        try:
            task_file = self.data_dir / "tasks" / f"{task_id}.json"
            if not task_file.exists():
                return None
            
            with open(task_file, 'r') as f:
                task_data = json.load(f)
            
            # Convert ISO strings back to datetime objects
            for key in ['created_at', 'started_at', 'completed_at']:
                if task_data[key]:
                    task_data[key] = datetime.fromisoformat(task_data[key])
            
            return EvaluationTask(**task_data)
        except Exception as e:
            logger.error(f"Failed to get task from file system: {e}")
            return None
    
    def _list_tasks_file(self, status: Optional[str], user_id: Optional[str], project_name: Optional[str], limit: int) -> List[EvaluationTask]:
        """List tasks from file system"""
        try:
            tasks = []
            tasks_dir = self.data_dir / "tasks"
            
            for task_file in tasks_dir.glob("*.json"):
                with open(task_file, 'r') as f:
                    task_data = json.load(f)
                
                # Apply filters
                if status and task_data.get('status') != status:
                    continue
                if user_id and task_data.get('user_id') != user_id:
                    continue
                if project_name and task_data.get('project_name') != project_name:
                    continue
                
                # Convert datetime fields
                for key in ['created_at', 'started_at', 'completed_at']:
                    if task_data[key]:
                        task_data[key] = datetime.fromisoformat(task_data[key])
                
                tasks.append(EvaluationTask(**task_data))
                
                if len(tasks) >= limit:
                    break
            
            return sorted(tasks, key=lambda x: x.created_at, reverse=True)
        except Exception as e:
            logger.error(f"Failed to list tasks from file system: {e}")
            return []
    
    # Placeholder implementations for other backend methods
    def _get_task_supabase(self, task_id: str) -> Optional[EvaluationTask]:
        return None  # Implementation needed
    
    def _get_task_postgres(self, task_id: str) -> Optional[EvaluationTask]:
        return None  # Implementation needed
    
    def _list_tasks_supabase(self, status, user_id, project_name, limit) -> List[EvaluationTask]:
        return []  # Implementation needed
    
    def _list_tasks_postgres(self, status, user_id, project_name, limit) -> List[EvaluationTask]:
        return []  # Implementation needed
    
    # Result storage placeholder implementations
    def _save_results_supabase(self, result: EvaluationResult) -> str:
        return result.result_id  # Implementation needed
    
    def _save_results_postgres(self, result: EvaluationResult) -> str:
        return result.result_id  # Implementation needed
    
    def _save_results_file(self, result: EvaluationResult) -> str:
        try:
            result_file = self.data_dir / "results" / f"{result.result_id}.json"
            result_data = asdict(result)
            if result_data['created_at'] and isinstance(result_data['created_at'], datetime):
                result_data['created_at'] = result_data['created_at'].isoformat()
            
            with open(result_file, 'w') as f:
                json.dump(result_data, f, indent=2, ensure_ascii=False)
            
            return result.result_id
        except Exception as e:
            logger.error(f"Failed to save results to file system: {e}")
            raise
    
    def _get_results_file(self, task_id: str) -> List[EvaluationResult]:
        try:
            results = []
            results_dir = self.data_dir / "results"
            
            for result_file in results_dir.glob("*.json"):
                with open(result_file, 'r') as f:
                    result_data = json.load(f)
                
                if result_data.get('task_id') == task_id:
                    if result_data['created_at']:
                        result_data['created_at'] = datetime.fromisoformat(result_data['created_at'])
                    results.append(EvaluationResult(**result_data))
            
            return sorted(results, key=lambda x: x.created_at, reverse=True)
        except Exception as e:
            logger.error(f"Failed to get results from file system: {e}")
            return []
    
    # Placeholder implementations for remaining methods
    def _get_results_supabase(self, task_id: str) -> List[EvaluationResult]:
        return []
    
    def _get_results_postgres(self, task_id: str) -> List[EvaluationResult]:
        return []
    
    def _list_history_supabase(self, model_id, evaluator_type, days, limit) -> List[Dict[str, Any]]:
        return []
    
    def _list_history_postgres(self, model_id, evaluator_type, days, limit) -> List[Dict[str, Any]]:
        return []
    
    def _list_history_file(self, model_id, evaluator_type, days, limit) -> List[Dict[str, Any]]:
        return []
    
    def _get_stats_supabase(self, user_id) -> Dict[str, Any]:
        return {"total_tasks": 0}
    
    def _get_stats_postgres(self, user_id) -> Dict[str, Any]:
        return {"total_tasks": 0}
    
    def _get_stats_file(self, user_id) -> Dict[str, Any]:
        return {"total_tasks": 0}
    
    def _delete_task_supabase(self, task_id: str) -> bool:
        return False
    
    def _delete_task_postgres(self, task_id: str) -> bool:
        return False
    
    def _delete_task_file(self, task_id: str) -> bool:
        try:
            task_file = self.data_dir / "tasks" / f"{task_id}.json"
            if task_file.exists():
                task_file.unlink()
            return True
        except Exception as e:
            logger.error(f"Failed to delete task from file system: {e}")
            return False