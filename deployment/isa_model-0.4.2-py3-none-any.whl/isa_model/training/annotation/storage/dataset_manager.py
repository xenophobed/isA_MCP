# app/services/llm_model/annotation/dataset/dataset_manager.py
from typing import Dict, Any, List
from datetime import datetime
import json
import io
import logging
import uuid
from isa_model.core.database.supabase_client import get_supabase_client
from isa_model.core.config import config_manager
from .dataset_schema import Dataset, DatasetType, DatasetStatus, DatasetFiles, DatasetStats

class DatasetManager:
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        self.minio_client = None
        self.bucket_name = "training-datasets"

    async def _ensure_minio_client(self):
        if not self.minio_client:
            # 模拟MinIO客户端，实际使用时需要从config_manager获取
            from isa_model.core.storage.minio_storage import MinIOStorage
            self.minio_client = MinIOStorage()

    async def create_dataset(
        self, 
        name: str,
        type: str,
        version: str,
        source_annotations: List[str]
    ) -> Dataset:
        """Create a new dataset record"""
        supabase = get_supabase_client()
        
        dataset_id = str(uuid.uuid4())
        dataset = Dataset(
            id=dataset_id,
            name=name,
            type=type,
            version=version,
            storage_path=f"datasets/{type}/{version}",
            files=DatasetFiles(
                train="train.jsonl",
                eval=None,
                test=None
            ),
            stats=DatasetStats(
                total_examples=0,
                avg_length=0.0,
                num_conversations=0,
                additional_metrics={}
            ),
            source_annotations=source_annotations,
            created_at=datetime.utcnow().isoformat(),
            status="pending",
            metadata={}
        )
        
        result = supabase.table('training_datasets').insert(
            dataset.dict(exclude_none=True)
        ).execute()
        
        return dataset

    async def upload_dataset_file(
        self,
        dataset_id: str,
        data: List[Dict[str, Any]],
        file_type: str = "train"
    ) -> bool:
        """Upload dataset to MinIO"""
        try:
            await self._ensure_minio_client()
            supabase = get_supabase_client()
            
            result = supabase.table('training_datasets').select('*').eq('id', dataset_id).execute()
            
            if not result.data:
                self.logger.error(f"Dataset not found with id: {dataset_id}")
                return False
            
            dataset = result.data[0]
            
            # Convert to JSONL
            buffer = io.StringIO()
            for item in data:
                buffer.write(json.dumps(item) + "\n")
            
            storage_path = dataset['storage_path'].rstrip('/')
            file_path = f"{storage_path}/{file_type}.jsonl"
            
            buffer_value = buffer.getvalue().encode()
            
            self.logger.debug(f"Uploading to MinIO path: {file_path}")
            
            self.minio_client.put_object(
                self.bucket_name,
                file_path,
                io.BytesIO(buffer_value),
                len(buffer_value)
            )
            
            avg_length = sum(len(str(item)) for item in data) / len(data) if data else 0
            
            # Update files and stats as nested JSON
            files = dataset.get('files', {})
            files[file_type] = f"{file_type}.jsonl"
            
            stats = dataset.get('stats', {})
            stats['total_examples'] = len(data)
            stats['avg_length'] = avg_length
            stats['num_conversations'] = len(data)
            
            supabase.table('training_datasets').update({
                "files": files,
                "stats": stats,
                "status": "ready"
            }).eq('id', dataset_id).execute()
            
            return True
            
        except Exception as e:
            self.logger.error(f"Failed to upload dataset: {e}")
            return False

    async def get_dataset_info(self, dataset_id: str) -> Dict[str, Any]:
        """Get dataset information"""
        try:
            supabase = get_supabase_client()
            result = supabase.table('training_datasets').select('*').eq('id', dataset_id).execute()
            
            if not result.data:
                self.logger.error(f"Dataset not found with id: {dataset_id}")
                return None
            
            return result.data[0]
            
        except Exception as e:
            self.logger.error(f"Failed to get dataset info: {e}")
            return None