# app/services/llm_model/tracing/annotation/annotation_controller.py
from typing import Dict, Any, List, Optional
from datetime import datetime
import uuid
import logging
from isa_model.core.database.supabase_client import get_supabase_client
from isa_model.core.config import config_manager
from isa_model.training.annotation.annotation_schema import AnnotationFeedback, RatingScale
from isa_model.training.annotation.storage.dataset_manager import DatasetManager


class AnnotationController:
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        
    async def get_pending_annotations(
        self, 
        project_name: str,
        category: Optional[str] = None,
        min_rating: Optional[int] = None,
        page: int = 1,
        limit: int = 10
    ) -> Dict[str, Any]:
        """Get filtered list of pending annotations"""
        supabase = get_supabase_client()
        
        # Build query with filters
        query = supabase.table('annotations').select('*').eq('status', 'pending').eq('project_name', project_name)
        
        if category:
            query = query.eq('annotation_type', category)
        if min_rating:
            # For nested JSON queries in Supabase, we'll need to filter in Python
            pass
            
        # Apply pagination
        offset = (page - 1) * limit
        query = query.order('created_at', desc=True).range(offset, offset + limit - 1)
        
        result = query.execute()
        annotations = result.data if result.data else []
        
        # Get total count
        count_query = supabase.table('annotations').select('*', count='exact').eq('status', 'pending').eq('project_name', project_name)
        if category:
            count_query = count_query.eq('annotation_type', category)
        count_result = count_query.execute()
        total = count_result.count if count_result.count else 0
            
        return {
            "annotations": annotations,
            "pagination": {
                "page": page,
                "limit": limit,
                "total": total
            }
        }

    async def submit_annotation(
        self,
        annotation_id: str,
        item_id: str,
        feedback: AnnotationFeedback,
        annotator_id: str
    ) -> Dict[str, Any]:
        """Submit and process annotation feedback"""
        supabase = get_supabase_client()
        
        # Determine if annotation should be selected for training
        is_selected = self._evaluate_for_training(feedback)
        feedback_dict = feedback.dict()
        feedback_dict["is_selected_for_training"] = is_selected
        
        # Get the annotation first
        annotation_result = supabase.table('annotations').select('*').eq('id', annotation_id).execute()
        if not annotation_result.data:
            raise ValueError(f"Annotation {annotation_id} not found")
        
        annotation = annotation_result.data[0]
        items = annotation.get('items', [])
        
        # Update the specific item
        for item in items:
            if item['item_id'] == item_id:
                item['feedback'] = feedback_dict
                item['status'] = 'completed'
                item['annotated_at'] = datetime.utcnow().isoformat()
                item['annotator_id'] = annotator_id
                item['training_status'] = 'pending' if is_selected else 'none'
                break
        
        # Update annotation in database
        update_result = supabase.table('annotations').update({
            'items': items,
            'updated_at': datetime.utcnow().isoformat()
        }).eq('id', annotation_id).execute()
        
        # Process for training if selected
        if is_selected:
            await self._queue_for_training(annotation_id, item_id, feedback)
        
        return {
            "status": "success",
            "selected_for_training": is_selected,
            "message": "Annotation submitted successfully"
        }

    def _evaluate_for_training(self, feedback: AnnotationFeedback) -> bool:
        """Evaluate if annotation should be used for training"""
        # Select for SFT if rating is excellent and aspects are positive
        if feedback.rating == RatingScale.EXCELLENT:
            aspects = feedback.aspects
            if all([
                aspects.factually_correct,
                aspects.relevant,
                not aspects.harmful,
                not aspects.biased
            ]):
                return True
        
        # Select for RLHF if better response is provided
        if feedback.better_response:
            return True
            
        return False

    async def _queue_for_training(
        self,
        annotation_id: str,
        item_id: str,
        feedback: AnnotationFeedback
    ):
        """Queue selected annotations for training data generation"""
        supabase = get_supabase_client()
        
        supabase.table('training_queue').insert({
            "id": str(uuid.uuid4()),
            "annotation_id": annotation_id,
            "item_id": item_id,
            "type": "sft" if feedback.rating == RatingScale.EXCELLENT else "rlhf",
            "feedback": feedback.dict(),
            "status": "pending",
            "created_at": datetime.utcnow().isoformat()
        }).execute()

class DatasetPreparationProcessor:
    def __init__(self):
        self.logger = config_manager.get_logger(__name__)
        self.dataset_manager = DatasetManager()
        self.batch_size = 1000  # Configure as needed
    
    async def process_annotation_queue(self) -> None:
        """Process pending annotations and prepare datasets"""
        db = await config_manager.get_db('mongodb')
        annotation_queue = db['dataset_preparation_queue']
        
        # Process items for SFT dataset
        sft_items = await self._get_pending_annotations("sft")
        if len(sft_items) >= self.batch_size:
            await self._create_sft_dataset(sft_items)
        
        # Process items for RLHF dataset
        rlhf_items = await self._get_pending_annotations("rlhf")
        if len(rlhf_items) >= self.batch_size:
            await self._create_rlhf_dataset(rlhf_items)

    async def _get_pending_annotations(self, dataset_type: str) -> List[Dict[str, Any]]:
        """Get pending annotations for dataset preparation"""
        supabase = get_supabase_client()
        
        result = supabase.table('dataset_preparation_queue').select('*').eq('status', 'pending').eq('dataset_type', dataset_type).limit(self.batch_size).execute()
        return result.data if result.data else []