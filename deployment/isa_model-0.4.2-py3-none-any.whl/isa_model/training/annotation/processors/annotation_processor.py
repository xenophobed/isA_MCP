from typing import Dict, Any, List
from datetime import datetime
import logging
import uuid
from isa_model.core.database.supabase_client import get_supabase_client
from isa_model.core.config import config_manager
from isa_model.training.annotation.annotation_schema import AnnotationFeedback, RatingScale, AnnotationAspects
from isa_model.training.annotation.storage.dataset_manager import DatasetManager

class AnnotationProcessor:
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        self.dataset_manager = DatasetManager()
        self.batch_size = 1000  # Configure as needed
    
    async def process_queue(self) -> Dict[str, Any]:
        """Process pending items and create datasets"""
        supabase = get_supabase_client()
        
        results = {
            "sft_processed": 0,
            "rlhf_processed": 0,
            "errors": []
        }
        
        # Get all pending items
        result = supabase.table('training_queue').select('*').eq('status', 'pending').execute()
        
        if not result.data:
            return results
        
        # Process items and mark them as completed immediately
        for item in result.data:
            try:
                # Mark as processed
                supabase.table('training_queue').update({
                    "status": "processed",
                    "processed_at": datetime.utcnow().isoformat()
                }).eq('id', item['id']).execute()
                
                # Count by type based on rating
                if item.get('feedback', {}).get('rating', 0) >= 3:
                    results["sft_processed"] += 1
                else:
                    results["rlhf_processed"] += 1
                    
            except Exception as e:
                results["errors"].append(str(e))
                self.logger.error(f"Failed to process item {item.get('id')}: {e}")
        
        return results

    async def _create_sft_dataset(self, items: List[Dict[str, Any]]):
        """Create and upload SFT dataset"""
        dataset = await self.dataset_manager.create_dataset(
            name=f"sft_dataset_v{datetime.now().strftime('%Y%m%d')}",
            type="sft",
            version=datetime.now().strftime("%Y%m%d"),
            source_annotations=[item["annotation_id"] for item in items]
        )
        
        formatted_data = [
            await self._process_sft_item(item) 
            for item in items
        ]
        
        await self.dataset_manager.upload_dataset_file(
            dataset.id,
            formatted_data
        )
        
        # Mark items as processed
        supabase = get_supabase_client()
        
        for item in items:
            supabase.table('training_queue').update({
                "status": "processed",
                "processed_at": datetime.utcnow().isoformat()
            }).eq('id', item['id']).execute()

    async def _process_sft_item(self, item: Dict[str, Any]) -> Dict[str, Any]:
        """Process item for SFT dataset generation
        Format follows HF conversation format for SFT training
        """
        supabase = get_supabase_client()
        
        # Get full annotation context
        result = supabase.table('annotations').select('*').eq('id', item["annotation_id"]).execute()
        if not result.data:
            raise ValueError(f"Annotation {item['annotation_id']} not found")
        
        annotation = result.data[0]
        target_item = next(i for i in annotation["items"] if i["item_id"] == item["item_id"])
        
        # Extract prompt and response based on item structure
        prompt = target_item.get("prompt", "")
        response = target_item.get("response", "")
        
        # Handle different data structures
        if not prompt and "input" in target_item:
            if isinstance(target_item["input"], dict) and "messages" in target_item["input"]:
                prompt = target_item["input"]["messages"][0]["content"]
            else:
                prompt = str(target_item["input"])
        
        if not response and "output" in target_item:
            if isinstance(target_item["output"], dict) and "content" in target_item["output"]:
                response = target_item["output"]["content"]
            else:
                response = str(target_item["output"])
        
        # Use better_response if provided and rating is low
        feedback = item.get("feedback", {})
        if feedback.get("better_response") and feedback.get("rating", 0) < 3:
            response = feedback["better_response"].get("content", response)
        
        # Format as conversation
        messages = [
            {
                "role": "user",
                "content": prompt
            },
            {
                "role": "assistant", 
                "content": response
            }
        ]

        return {
            "messages": messages,
            "metadata": {
                "rating": item["feedback"]["rating"],
                "aspects": item["feedback"]["aspects"],
                "category": item["feedback"]["category"],
                "annotator_id": item.get("annotator_id", "unknown")
            }
        }

    async def _process_rlhf_item(self, items: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Process items for RLHF dataset generation
        Format follows preference pairs structure for RLHF training
        Takes a list of items sorted by rating (highest first)
        """
        if len(items) < 2:
            raise ValueError("Need at least 2 items for RLHF pair")
        
        supabase = get_supabase_client()
        
        # Use highest rated as chosen, lowest as rejected
        chosen_item = items[0]
        rejected_item = items[-1]
        
        # Get full annotation context
        result = supabase.table('annotations').select('*').eq('id', chosen_item["annotation_id"]).execute()
        if not result.data:
            raise ValueError(f"Annotation {chosen_item['annotation_id']} not found")
        
        annotation = result.data[0]
        
        # Find the annotation items
        chosen_ann_item = next((i for i in annotation["items"] if i["item_id"] == chosen_item["item_id"]), None)
        rejected_ann_item = next((i for i in annotation["items"] if i["item_id"] == rejected_item["item_id"]), None)
        
        if not chosen_ann_item or not rejected_ann_item:
            raise ValueError("Could not find annotation items")
        
        # Extract prompt (should be the same for both)
        prompt = chosen_ann_item.get("prompt", "")
        if not prompt and "input" in chosen_ann_item:
            prompt = str(chosen_ann_item["input"])
        
        # Get responses
        chosen_response = chosen_ann_item.get("response", "")
        if not chosen_response and "output" in chosen_ann_item:
            chosen_response = str(chosen_ann_item["output"])
        
        # Check if better_response was provided for chosen item
        if chosen_item.get("feedback", {}).get("better_response"):
            chosen_response = chosen_item["feedback"]["better_response"].get("content", chosen_response)
        
        rejected_response = rejected_ann_item.get("response", "")
        if not rejected_response and "output" in rejected_ann_item:
            rejected_response = str(rejected_ann_item["output"])
        
        # Format as preference pair
        return {
            "prompt": prompt,
            "chosen": chosen_response,
            "rejected": rejected_response,
            "metadata": {
                "chosen_rating": chosen_item.get("feedback", {}).get("rating", 0),
                "rejected_rating": rejected_item.get("feedback", {}).get("rating", 0),
                "category": chosen_item.get("feedback", {}).get("category", "unknown")
            }
        }

    async def _get_pending_items(self, dataset_type: str) -> List[Dict[str, Any]]:
        """Get pending items from training queue"""
        supabase = get_supabase_client()
        
        # Get all pending items, we'll filter by rating later
        result = supabase.table('training_queue').select('*').eq('status', 'pending').limit(self.batch_size).execute()
        
        if not result.data:
            return []
        
        # Filter based on dataset type
        if dataset_type == "sft":
            # For SFT, get high-rated items (3-4)
            return [item for item in result.data if item.get('feedback', {}).get('rating', 0) >= 3]
        else:  # rlhf
            # For RLHF, we need pairs with different ratings
            return result.data  # Process all for RLHF pairing
    
    async def _create_rlhf_dataset(self, items: List[Dict[str, Any]]):
        """Create and upload RLHF dataset"""
        dataset = await self.dataset_manager.create_dataset(
            name=f"rlhf_dataset_v{datetime.now().strftime('%Y%m%d')}",
            type="rlhf",
            version=datetime.now().strftime("%Y%m%d"),
            source_annotations=[item["annotation_id"] for item in items]
        )
        
        formatted_data = [
            await self._process_rlhf_item(item) 
            for item in items
        ]
        
        await self.dataset_manager.upload_dataset_file(
            dataset.id,
            formatted_data
        )
        
        # Mark items as processed
        supabase = get_supabase_client()
        
        for item in items:
            supabase.table('training_queue').update({
                "status": "processed",
                "processed_at": datetime.utcnow().isoformat()
            }).eq('id', item['id']).execute()

    async def get_training_data(
        self,
        data_type: str,
        limit: int = 1000
    ) -> List[Dict[str, Any]]:
        """Retrieve formatted training data from processed queue items"""
        supabase = get_supabase_client()
        
        # Get processed items from training queue
        result = supabase.table('training_queue').select('*').eq('status', 'processed').limit(limit).execute()
        
        if not result.data:
            return []
        
        formatted_data = []
        
        if data_type == "sft":
            # Process items with high ratings for SFT
            for item in result.data:
                if item.get('feedback', {}).get('rating', 0) >= 3:
                    try:
                        sft_item = await self._process_sft_item(item)
                        formatted_data.append(sft_item)
                    except Exception as e:
                        self.logger.warning(f"Failed to process SFT item: {e}")
        
        elif data_type == "rlhf":
            # Group items by prompt for RLHF pairs
            items_by_annotation = {}
            for item in result.data:
                ann_id = item.get('annotation_id')
                if ann_id not in items_by_annotation:
                    items_by_annotation[ann_id] = []
                items_by_annotation[ann_id].append(item)
            
            # Create RLHF pairs from items with different ratings
            for ann_id, items in items_by_annotation.items():
                if len(items) >= 2:
                    # Sort by rating to identify chosen/rejected
                    sorted_items = sorted(items, key=lambda x: x.get('feedback', {}).get('rating', 0), reverse=True)
                    if sorted_items[0].get('feedback', {}).get('rating', 0) > sorted_items[-1].get('feedback', {}).get('rating', 0):
                        try:
                            rlhf_item = await self._process_rlhf_item(sorted_items)
                            formatted_data.append(rlhf_item)
                        except Exception as e:
                            self.logger.warning(f"Failed to process RLHF item: {e}")
        
        return formatted_data