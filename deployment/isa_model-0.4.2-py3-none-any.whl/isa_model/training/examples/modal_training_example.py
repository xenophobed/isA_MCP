"""
Modal Training Example

演示如何使用ISA Model的Modal集成进行GPU训练
包括基础训练、LlamaFactory训练和自定义场景训练
"""

import os
import json
from isa_model.training import IntelligentTrainingFactory

def main():
    """演示Modal训练功能"""
    
    print("🚀 ISA Model Modal Training 演示")
    print("=" * 60)
    
    # 初始化智能训练工厂
    try:
        factory = IntelligentTrainingFactory(enable_intelligence=True)
        print("✅ 智能训练工厂初始化成功")
    except Exception as e:
        print(f"❌ 初始化失败: {e}")
        return
    
    # 检查Modal状态
    modal_status = factory.get_modal_training_status()
    print(f"\n📡 Modal状态: {modal_status}")
    
    if not modal_status.get("available", False):
        print("❌ Modal不可用，请安装: pip install modal")
        print("然后配置Modal token: modal token new")
        return
    
    # 1. 基础训练示例
    print("\n" + "=" * 60)
    print("🔥 示例1: Modal基础训练")
    print("=" * 60)
    
    try:
        basic_result = factory.train_on_modal(
            description="训练一个小型中文对话模型用于客服",
            dataset_path="tatsu-lab/alpaca",  # 使用公开数据集
            training_type="basic",
            quality_target="balanced",
            # 小规模测试参数
            num_epochs=1,
            batch_size=1,
            use_lora=True
        )
        
        print(f"✅ 基础训练完成")
        print(f"   模型: {basic_result.get('model_name')}")
        print(f"   状态: {basic_result.get('status')}")
        print(f"   平台: {basic_result.get('training_platform')}")
        
    except Exception as e:
        print(f"❌ 基础训练失败: {e}")
    
    # 2. LlamaFactory训练示例
    print("\n" + "=" * 60)
    print("🔬 示例2: Modal LlamaFactory训练")
    print("=" * 60)
    
    try:
        llamafactory_result = factory.train_llamafactory_on_modal(
            description="使用SFT训练代码生成模型",
            dataset_path="tatsu-lab/alpaca",
            training_stage="sft",
            quality_target="high",
            # 小规模测试参数
            num_epochs=1,
            batch_size=1
        )
        
        print(f"✅ LlamaFactory训练完成")
        print(f"   训练阶段: {llamafactory_result.get('training_stage')}")
        print(f"   状态: {llamafactory_result.get('status')}")
        print(f"   智能优化: {llamafactory_result.get('intelligent_optimization')}")
        
    except Exception as e:
        print(f"❌ LlamaFactory训练失败: {e}")
    
    # 3. 自定义场景训练示例
    print("\n" + "=" * 60)
    print("🎯 示例3: Modal自定义场景训练")
    print("=" * 60)
    
    try:
        # 多模态训练场景
        custom_result = factory.train_custom_scenario_on_modal(
            scenario_type="multimodal",
            base_model="TinyLlama/TinyLlama-1.1B-Chat-v1.0",
            data_sources=["text_data.json", "image_data.json"],
            modalities=["text", "image"],
            fusion_strategy="late_fusion",
            # 小规模测试参数
            num_epochs=1,
            batch_size=1
        )
        
        print(f"✅ 自定义场景训练完成")
        print(f"   场景类型: {custom_result.get('scenario_type')}")
        print(f"   状态: {custom_result.get('status')}")
        print(f"   平台: {custom_result.get('training_platform')}")
        
    except Exception as e:
        print(f"❌ 自定义场景训练失败: {e}")
    
    # 4. 获取训练监控信息
    print("\n" + "=" * 60)
    print("📊 示例4: 训练监控和管理")
    print("=" * 60)
    
    try:
        # 获取训练仪表板
        dashboard = factory.get_training_dashboard()
        print(f"📋 系统状态: {dashboard.get('system_status')}")
        print(f"📋 活跃任务: {len(dashboard.get('active_jobs', []))}")
        print(f"📋 最近完成: {len(dashboard.get('recent_completions', []))}")
        
        # 获取智能统计
        stats = factory.get_intelligence_statistics()
        print(f"🧠 智能功能: {stats.get('intelligence_enabled')}")
        print(f"🧠 支持任务: {stats.get('supported_tasks')}")
        
    except Exception as e:
        print(f"❌ 获取监控信息失败: {e}")
    
    print("\n" + "=" * 60)
    print("🎉 Modal Training 演示完成!")
    print("=" * 60)

def create_sample_dataset():
    """创建示例数据集用于测试"""
    sample_data = [
        {
            "instruction": "你好，请介绍一下你自己",
            "input": "",
            "output": "你好！我是一个AI助手，很高兴为您服务。"
        },
        {
            "instruction": "请解释什么是机器学习",
            "input": "",
            "output": "机器学习是人工智能的一个分支，通过算法让计算机从数据中学习模式。"
        },
        {
            "instruction": "如何使用Python进行数据分析",
            "input": "",
            "output": "可以使用pandas、numpy等库来处理和分析数据。"
        }
    ]
    
    # 保存示例数据
    with open("sample_training_data.json", "w", encoding="utf-8") as f:
        json.dump(sample_data, f, ensure_ascii=False, indent=2)
    
    print("✅ 创建示例数据集: sample_training_data.json")

if __name__ == "__main__":
    # 首先创建示例数据集
    create_sample_dataset()
    
    # 运行演示
    main()