"""
简单Modal训练测试

最小化GPU资源消耗的快速测试：
- 使用最小的模型 (TinyLlama-1.1B)
- 最小数据集 (只有3个样本)
- 最短训练时间 (1个epoch, batch_size=1)
- 预计运行时间: 2-5分钟
"""

import json
import tempfile
import os
from pathlib import Path

def create_tiny_dataset():
    """创建最小测试数据集"""
    tiny_data = [
        {
            "instruction": "说你好",
            "input": "",
            "output": "你好！"
        },
        {
            "instruction": "1+1等于几",
            "input": "",
            "output": "1+1等于2"
        },
        {
            "instruction": "介绍自己",
            "input": "",
            "output": "我是AI助手"
        }
    ]
    
    # 创建临时文件
    temp_file = tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False, encoding='utf-8')
    json.dump(tiny_data, temp_file, ensure_ascii=False, indent=2)
    temp_file.close()
    
    return temp_file.name

def test_modal_basic_training():
    """测试Modal基础训练 - 最小化资源消耗"""
    
    print("🧪 开始Modal基础训练测试")
    print("📊 配置: TinyLlama-1.1B, 3样本, 1epoch, batch_size=1")
    print("⏱️  预计时间: 2-3分钟")
    print("-" * 50)
    
    try:
        from isa_model.training import IntelligentTrainingFactory
        
        # 初始化工厂
        factory = IntelligentTrainingFactory(enable_intelligence=True)
        
        # 检查Modal状态
        modal_status = factory.get_modal_training_status()
        if not modal_status.get("available", False):
            print("❌ Modal不可用:", modal_status.get("reason"))
            return False
        
        print("✅ Modal状态正常")
        
        # 创建最小数据集
        dataset_path = create_tiny_dataset()
        print(f"✅ 创建测试数据集: {dataset_path}")
        
        # 最小化训练配置
        result = factory.train_on_modal(
            description="快速测试训练一个简单对话模型",
            dataset_path=dataset_path,
            training_type="basic",
            quality_target="fast",  # 使用最快配置
            # 最小化参数
            num_epochs=1,           # 只训练1个epoch
            batch_size=1,           # 最小batch
            learning_rate=1e-4,     # 较高学习率加快收敛
            max_length=128,         # 短序列长度
            use_lora=True           # 用LoRA减少计算量
        )
        
        print("\n📊 训练结果:")
        print(f"   状态: {result.get('status')}")
        print(f"   模型: {result.get('model_name')}")
        print(f"   平台: {result.get('training_platform')}")
        print(f"   智能优化: {result.get('intelligent_optimization')}")
        
        if result.get('status') == 'completed':
            print("🎉 测试成功!")
            return True
        else:
            print(f"❌ 测试失败: {result.get('error')}")
            return False
            
    except Exception as e:
        print(f"❌ 测试异常: {e}")
        return False
    finally:
        # 清理临时文件
        if 'dataset_path' in locals():
            try:
                os.unlink(dataset_path)
                print("🧹 清理临时文件完成")
            except:
                pass

def test_modal_status_only():
    """仅测试Modal连接状态 - 不消耗GPU"""
    
    print("🔍 检查Modal连接状态...")
    print("-" * 30)
    
    try:
        from isa_model.training import IntelligentTrainingFactory
        
        factory = IntelligentTrainingFactory(enable_intelligence=True)
        
        # 检查Modal状态
        modal_status = factory.get_modal_training_status()
        print("📡 Modal状态:")
        print(f"   可用: {modal_status.get('available')}")
        print(f"   状态: {modal_status.get('status', 'unknown')}")
        
        if modal_status.get('available'):
            print(f"   支持GPU: {modal_status.get('gpu_types')}")
            print(f"   启动时间: {modal_status.get('estimated_startup_time')}")
            print(f"   支持训练: {modal_status.get('supported_training_types')}")
            print("✅ Modal连接正常，可以进行训练")
            return True
        else:
            print(f"❌ Modal不可用: {modal_status.get('reason')}")
            return False
            
    except Exception as e:
        print(f"❌ 连接测试失败: {e}")
        return False

def main():
    """主测试函数"""
    
    print("🚀 ISA Model Modal 快速测试")
    print("=" * 50)
    print("目标: 最小资源消耗验证训练功能")
    print("=" * 50)
    
    # 首先测试连接状态
    print("\n🔍 步骤1: 检查Modal连接")
    if not test_modal_status_only():
        print("\n❌ Modal连接失败，无法继续测试")
        print("\n💡 请检查:")
        print("   1. 安装Modal: pip install modal")
        print("   2. 配置Token: modal token new")
        print("   3. 网络连接正常")
        return
    
    # 询问是否继续GPU训练测试
    print("\n" + "=" * 50)
    print("⚠️  下一步将使用GPU资源进行实际训练测试")
    print("📊 预计消耗: A100 GPU ~2-3分钟")
    print("💰 预计成本: ~$0.10-0.20")
    
    user_input = input("\n继续GPU训练测试? (y/n): ").strip().lower()
    
    if user_input == 'y':
        print("\n🔥 步骤2: 执行最小化训练测试")
        success = test_modal_basic_training()
        
        if success:
            print("\n🎉 所有测试通过!")
            print("✅ Modal GPU训练功能正常")
        else:
            print("\n❌ 训练测试失败")
    else:
        print("\n⏹️  跳过GPU训练测试")
    
    print("\n" + "=" * 50)
    print("📝 测试完成")
    print("=" * 50)

if __name__ == "__main__":
    main()