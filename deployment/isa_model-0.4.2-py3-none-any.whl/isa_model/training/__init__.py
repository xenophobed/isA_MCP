"""
ISA Model Training Module

Provides unified training capabilities for AI models including:
- Local training with SFT (Supervised Fine-Tuning)
- Cloud training on RunPod
- Model evaluation and management
- HuggingFace integration
- 🧠 Intelligent training with AI-powered optimization

Example usage:
    ```python
    from isa_model.training import TrainingFactory, train_gemma
    
    # Quick Gemma training
    model_path = train_gemma(
        dataset_path="tatsu-lab/alpaca",
        model_size="4b",
        num_epochs=3
    )
    
    # Advanced training with custom configuration
    factory = TrainingFactory()
    model_path = factory.train_model(
        model_name="google/gemma-2-4b-it",
        dataset_path="your-dataset.json",
        use_lora=True,
        batch_size=4,
        num_epochs=3
    )
    
    # 🧠 Intelligent training with natural language
    from isa_model.training import IntelligentTrainingFactory
    
    intelligent_factory = IntelligentTrainingFactory()
    recommendation = intelligent_factory.analyze_training_request(
        "Train a customer service chatbot for medical domain",
        dataset_path="medical_dialogues.json",
        quality_target="high",
        budget_limit=200.0
    )
    model_path = intelligent_factory.train_with_recommendation(recommendation)
    
    # 🔬 Advanced training with LlamaFactory integration
    result = intelligent_factory.train_with_llamafactory(
        "Fine-tune a model for code generation with DPO",
        "code_dataset.json",
        training_stage="dpo",
        quality_target="high"
    )
    
    # 🎯 Custom training scenarios
    result = intelligent_factory.train_custom_scenario(
        scenario_type="multimodal",
        base_model="google/gemma-2-4b-it",
        data_sources=["text_data.json", "image_data.json"],
        output_dir="./multimodal_output",
        modalities=["text", "image"]
    )
    ```
"""

# Import the new clean factory
from .factory import TrainingFactory, train_gemma

# Import core components
from .core import (
    TrainingConfig,
    LoRAConfig, 
    DatasetConfig,
    BaseTrainer,
    SFTTrainer,
    TrainingUtils,
    DatasetManager,
    RunPodConfig,
    StorageConfig,
    JobConfig
)

# Import cloud training components
from .cloud import (
    TrainingJobOrchestrator
)

# Import intelligent training components (optional)
try:
    from .intelligent import (
        IntelligentTrainingFactory,
        IntelligentDecisionEngine,
        TaskClassifier,
        KnowledgeBase,
        ResourceOptimizer,
        TrainingRequest,
        TrainingRecommendation
    )
    # Import enhanced training capabilities
    from .enhanced.llamafactory_integration import (
        LlamaFactoryTrainer,
        LlamaFactoryConfig,
        EnhancedLlamaFactoryIntegration
    )
    from .enhanced.custom_scenarios import (
        CustomScenarioManager,
        CustomTrainingConfig,
        MultiModalTrainingScenario,
        DomainAdaptationScenario,
        ContinualLearningScenario,
        FederatedLearningScenario
    )
    INTELLIGENT_AVAILABLE = True
    ENHANCED_TRAINING_AVAILABLE = True
except ImportError as e:
    INTELLIGENT_AVAILABLE = False
    ENHANCED_TRAINING_AVAILABLE = False
    # Create placeholder classes for graceful degradation
    class IntelligentTrainingFactory:
        def __init__(self, *args, **kwargs):
            raise ImportError("Intelligent training features not available. Please install required dependencies.")
    
    class IntelligentDecisionEngine:
        def __init__(self, *args, **kwargs):
            raise ImportError("Intelligent training features not available.")
    
    class TaskClassifier:
        def __init__(self, *args, **kwargs):
            raise ImportError("Intelligent training features not available.")
    
    class KnowledgeBase:
        def __init__(self, *args, **kwargs):
            raise ImportError("Intelligent training features not available.")
    
    class ResourceOptimizer:
        def __init__(self, *args, **kwargs):
            raise ImportError("Intelligent training features not available.")
    
    class TrainingRequest:
        def __init__(self, *args, **kwargs):
            raise ImportError("Intelligent training features not available.")
    
    class TrainingRecommendation:
        def __init__(self, *args, **kwargs):
            raise ImportError("Intelligent training features not available.")

__all__ = [
    # Main factory
    'TrainingFactory',
    'train_gemma',
    
    # Core components
    'TrainingConfig',
    'LoRAConfig',
    'DatasetConfig', 
    'BaseTrainer',
    'SFTTrainer',
    'TrainingUtils',
    'DatasetManager',
    
    # Cloud components
    'RunPodConfig',
    'StorageConfig',
    'JobConfig',
    'TrainingJobOrchestrator',
    
    # Intelligent training components
    'IntelligentTrainingFactory',
    'IntelligentDecisionEngine',
    'TaskClassifier',
    'KnowledgeBase',
    'ResourceOptimizer',
    'TrainingRequest',
    'TrainingRecommendation',
    'INTELLIGENT_AVAILABLE',
    
    # Enhanced training components
    'LlamaFactoryTrainer',
    'LlamaFactoryConfig',
    'EnhancedLlamaFactoryIntegration',
    'CustomScenarioManager',
    'CustomTrainingConfig',
    'MultiModalTrainingScenario',
    'DomainAdaptationScenario',
    'ContinualLearningScenario',
    'FederatedLearningScenario',
    'ENHANCED_TRAINING_AVAILABLE',
    
    # Computer vision training components (optional)
    'ImageClassificationTrainer',
    'CVDataPreprocessor',
    'CV_TRAINING_AVAILABLE',
    
    # Legacy model processors (migrated from isA_MCP)
    'TimeSeriesProcessor',
    'DeepLearningProcessor', 
    'UnsupervisedProcessor',
    'EnsembleProcessor',
    'MLProcessor',
    'ModelServingProcessor',
    'LEGACY_PROCESSORS_AVAILABLE',
    
    # Training storage components (optional)
    'TrainingStorage',
    'TrainingRepository',
    'CoreModelIntegration'
]

# Import computer vision training components (optional)
try:
    from .computer_vision import (
        ImageClassificationTrainer,
        CVDataPreprocessor
    )
    CV_TRAINING_AVAILABLE = True
except ImportError:
    CV_TRAINING_AVAILABLE = False
    ImageClassificationTrainer = None
    CVDataPreprocessor = None

# Import legacy model processors (migrated from isA_MCP)
try:
    from .legacy_processors import (
        TimeSeriesProcessor,
        DeepLearningProcessor,
        UnsupervisedProcessor,
        EnsembleProcessor,
        MLProcessor,
        ModelServingProcessor
    )
    LEGACY_PROCESSORS_AVAILABLE = True
except ImportError:
    LEGACY_PROCESSORS_AVAILABLE = False
    TimeSeriesProcessor = None
    DeepLearningProcessor = None
    UnsupervisedProcessor = None
    EnsembleProcessor = None
    MLProcessor = None
    ModelServingProcessor = None

# Import training storage components (optional)
try:
    from .storage import (
        TrainingStorage,
        TrainingRepository,
        CoreModelIntegration
    )
    STORAGE_AVAILABLE = True
except ImportError:
    STORAGE_AVAILABLE = False
    # Create placeholder classes for graceful degradation
    class TrainingStorage:
        def __init__(self, *args, **kwargs):
            raise ImportError("Training storage features not available.")
    
    class TrainingRepository:
        def __init__(self, *args, **kwargs):
            raise ImportError("Training repository features not available.")
    
    class CoreModelIntegration:
        def __init__(self, *args, **kwargs):
            raise ImportError("Core model integration features not available.") 