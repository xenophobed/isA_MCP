"""
Computer Vision Training Module
Training components for computer vision models including image classification
"""

from .image_classification_trainer import ImageClassificationTrainer
from .data_preprocessing import CVDataPreprocessor

__all__ = [
    'ImageClassificationTrainer',
    'CVDataPreprocessor'
]