#!/usr/bin/env python3
"""
Image Classification Trainer
Integrates VGG16 and other CNN training with isA_model training infrastructure
Based on the aircraft damage detection notebook
"""

import os
import numpy as np
from typing import Dict, List, Any, Optional, Tuple, Union
import logging
from datetime import datetime
import json

from ..core.trainer import BaseTrainer
from ..core.config import TrainingConfig

logger = logging.getLogger(__name__)

def _lazy_import_cv_deps():
    """Lazy import computer vision dependencies"""
    try:
        import tensorflow as tf
        from tensorflow.keras.applications import VGG16, ResNet50, EfficientNetB0
        from tensorflow.keras.layers import Dense, Dropout, Flatten, GlobalAveragePooling2D
        from tensorflow.keras.models import Sequential, Model
        from tensorflow.keras.optimizers import Adam
        from tensorflow.keras.callbacks import EarlyStopping, ModelCheckpoint, ReduceLROnPlateau
        from tensorflow.keras.preprocessing.image import ImageDataGenerator
        
        return {
            'tf': tf,
            'VGG16': VGG16,
            'ResNet50': ResNet50,
            'EfficientNetB0': EfficientNetB0,
            'Dense': Dense,
            'Dropout': Dropout,
            'Flatten': Flatten,
            'GlobalAveragePooling2D': GlobalAveragePooling2D,
            'Sequential': Sequential,
            'Model': Model,
            'Adam': Adam,
            'EarlyStopping': EarlyStopping,
            'ModelCheckpoint': ModelCheckpoint,
            'ReduceLROnPlateau': ReduceLROnPlateau,
            'ImageDataGenerator': ImageDataGenerator,
            'available': True
        }
    except ImportError as e:
        logger.warning(f"Computer vision dependencies not available: {e}")
        return {'available': False}

class ImageClassificationTrainer(BaseTrainer):
    """
    Image classification trainer integrating with isA_model infrastructure
    Supports VGG16, ResNet50, EfficientNet for transfer learning
    """
    
    SUPPORTED_ARCHITECTURES = {
        'vgg16': 'VGG16',
        'resnet50': 'ResNet50',
        'efficientnet': 'EfficientNetB0'
    }
    
    def __init__(self, config: Dict[str, Any]):
        """
        Initialize image classification trainer
        
        Args:
            config: Training configuration dict
        """
        super().__init__(config)
        
        # Computer vision specific config
        self.architecture = config.get('architecture', 'vgg16')
        self.input_shape = tuple(config.get('input_shape', (224, 224, 3)))
        self.num_classes = config.get('num_classes', 2)
        self.task_type = config.get('task_type', 'binary')  # binary or multiclass
        
        # Training parameters from notebook
        self.batch_size = config.get('batch_size', 32)
        self.learning_rate = config.get('learning_rate', 0.0001)
        self.dropout_rate = config.get('dropout_rate', 0.3)
        self.dense_units = config.get('dense_units', [512, 512])
        self.freeze_base = config.get('freeze_base', True)
        self.use_augmentation = config.get('use_augmentation', False)
        
        # Data directories
        self.train_dir = config.get('train_dir')
        self.valid_dir = config.get('valid_dir')
        self.test_dir = config.get('test_dir')
        
        # Lazy load dependencies
        self.cv_components = _lazy_import_cv_deps()
        
        if not self.cv_components['available']:
            raise ImportError("TensorFlow and computer vision dependencies are required")
        
        self.model = None
        self.class_names = None
        self.training_history = None
        
        # Data generators
        self.train_generator = None
        self.valid_generator = None
        self.test_generator = None
        
        # Set random seeds for reproducibility
        self._set_random_seeds()
    
    def _set_random_seeds(self, seed: int = 42):
        """Set random seeds for reproducible results"""
        import random
        random.seed(seed)
        np.random.seed(seed)
        
        if self.cv_components['available']:
            self.cv_components['tf'].random.set_seed(seed)
    
    def prepare_data(self) -> Dict[str, Any]:
        """
        Prepare data generators for training (Tasks 1-2 from notebook)
        
        Returns:
            Data preparation results
        """
        try:
            if not all([self.train_dir, self.valid_dir]):
                return {"error": "train_dir and valid_dir must be specified"}
            
            ImageDataGenerator = self.cv_components['ImageDataGenerator']
            
            # Create data generators following notebook structure
            if self.use_augmentation:
                train_datagen = ImageDataGenerator(
                    rescale=1./255,
                    rotation_range=20,
                    width_shift_range=0.2,
                    height_shift_range=0.2,
                    shear_range=0.2,
                    zoom_range=0.2,
                    horizontal_flip=True,
                    fill_mode='nearest'
                )
            else:
                # Following notebook (no augmentation)
                train_datagen = ImageDataGenerator(rescale=1./255)
            
            # Validation and test generators (no augmentation)
            valid_datagen = ImageDataGenerator(rescale=1./255)
            test_datagen = ImageDataGenerator(rescale=1./255)
            
            # Create training generator
            self.train_generator = train_datagen.flow_from_directory(
                self.train_dir,
                target_size=(self.input_shape[0], self.input_shape[1]),
                batch_size=self.batch_size,
                seed=42,
                class_mode='binary' if self.task_type == 'binary' else 'categorical',
                shuffle=True
            )
            
            # Store class information
            self.class_names = list(self.train_generator.class_indices.keys())
            self.num_classes = len(self.class_names)
            
            # Auto-detect task type if not specified
            if self.num_classes == 2:
                self.task_type = 'binary'
            else:
                self.task_type = 'multiclass'
                # Recreate with categorical mode
                self.train_generator = train_datagen.flow_from_directory(
                    self.train_dir,
                    target_size=(self.input_shape[0], self.input_shape[1]),
                    batch_size=self.batch_size,
                    seed=42,
                    class_mode='categorical',
                    shuffle=True
                )
            
            # Create validation generator (Task 1)
            self.valid_generator = valid_datagen.flow_from_directory(
                directory=self.valid_dir,
                class_mode='binary' if self.task_type == 'binary' else 'categorical',
                seed=42,
                batch_size=self.batch_size,
                shuffle=False,
                target_size=(self.input_shape[0], self.input_shape[1])
            )
            
            # Create test generator if test_dir provided (Task 2)
            if self.test_dir and os.path.exists(self.test_dir):
                self.test_generator = test_datagen.flow_from_directory(
                    directory=self.test_dir,
                    class_mode='binary' if self.task_type == 'binary' else 'categorical',
                    seed=42,
                    batch_size=self.batch_size,
                    shuffle=False,
                    target_size=(self.input_shape[0], self.input_shape[1])
                )
            
            return {
                "data_prepared": True,
                "train_samples": self.train_generator.samples,
                "valid_samples": self.valid_generator.samples,
                "test_samples": self.test_generator.samples if self.test_generator else 0,
                "class_names": self.class_names,
                "num_classes": self.num_classes,
                "task_type": self.task_type
            }
            
        except Exception as e:
            logger.error(f"Error preparing data: {e}")
            return {"error": str(e)}
    
    def build_model(self) -> Dict[str, Any]:
        """
        Build image classification model (Task 3 from notebook)
        
        Returns:
            Model build information
        """
        try:
            # Get the appropriate pre-trained model
            if self.architecture == 'vgg16':
                base_model = self.cv_components['VGG16'](
                    weights='imagenet',
                    include_top=False,
                    input_shape=self.input_shape
                )
            elif self.architecture == 'resnet50':
                base_model = self.cv_components['ResNet50'](
                    weights='imagenet',
                    include_top=False,
                    input_shape=self.input_shape
                )
            elif self.architecture == 'efficientnet':
                base_model = self.cv_components['EfficientNetB0'](
                    weights='imagenet',
                    include_top=False,
                    input_shape=self.input_shape
                )
            else:
                return {"error": f"Unsupported architecture: {self.architecture}"}
            
            # Extract features from base model (following notebook pattern)
            output = base_model.layers[-1].output
            output = self.cv_components['Flatten']()(output)
            base_model_modified = self.cv_components['Model'](base_model.input, output)
            
            # Freeze base model if requested
            if self.freeze_base:
                for layer in base_model_modified.layers:
                    layer.trainable = False
            
            # Build the model (following notebook structure)
            model = self.cv_components['Sequential']()
            model.add(base_model_modified)
            
            # Add custom classifier layers
            for units in self.dense_units:
                model.add(self.cv_components['Dense'](units, activation='relu'))
                model.add(self.cv_components['Dropout'](self.dropout_rate))
            
            # Output layer
            if self.task_type == 'binary':
                model.add(self.cv_components['Dense'](1, activation='sigmoid'))
                loss = 'binary_crossentropy'
            else:  # multiclass
                model.add(self.cv_components['Dense'](self.num_classes, activation='softmax'))
                loss = 'categorical_crossentropy'
            
            # Compile model (Task 4 from notebook)
            model.compile(
                optimizer=self.cv_components['Adam'](learning_rate=self.learning_rate),
                loss=loss,
                metrics=['accuracy']
            )
            
            self.model = model
            
            return {
                "model_built": True,
                "architecture": self.architecture,
                "total_params": model.count_params(),
                "trainable_params": sum([
                    layer.count_params() for layer in model.layers if layer.trainable
                ]),
                "task_type": self.task_type,
                "num_classes": self.num_classes,
                "loss": loss,
                "optimizer": "Adam",
                "learning_rate": self.learning_rate
            }
            
        except Exception as e:
            logger.error(f"Error building model: {e}")
            return {"error": str(e)}
    
    def train(self) -> Dict[str, Any]:
        """
        Train the image classification model (Task 5 from notebook)
        
        Returns:
            Training results
        """
        try:
            # Prepare data if not already done
            if self.train_generator is None:
                data_result = self.prepare_data()
                if "error" in data_result:
                    return data_result
            
            # Build model if not already done
            if self.model is None:
                build_result = self.build_model()
                if "error" in build_result:
                    return build_result
            
            epochs = self.config.get('epochs', 5)
            use_callbacks = self.config.get('use_callbacks', True)
            save_best_model = self.config.get('save_best_model', True)
            
            # Setup callbacks
            callbacks = []
            if use_callbacks:
                # Early stopping
                callbacks.append(
                    self.cv_components['EarlyStopping'](
                        monitor='val_loss' if self.valid_generator else 'loss',
                        patience=3,
                        restore_best_weights=True
                    )
                )
                
                # Reduce learning rate on plateau
                callbacks.append(
                    self.cv_components['ReduceLROnPlateau'](
                        monitor='val_loss' if self.valid_generator else 'loss',
                        factor=0.5,
                        patience=2,
                        min_lr=1e-7
                    )
                )
                
                # Model checkpoint
                if save_best_model:
                    checkpoint_path = self._get_checkpoint_path()
                    os.makedirs(os.path.dirname(checkpoint_path), exist_ok=True)
                    callbacks.append(
                        self.cv_components['ModelCheckpoint'](
                            checkpoint_path,
                            monitor='val_loss' if self.valid_generator else 'loss',
                            save_best_only=True,
                            save_weights_only=False
                        )
                    )
            
            # Train model
            history = self.model.fit(
                self.train_generator,
                epochs=epochs,
                validation_data=self.valid_generator,
                callbacks=callbacks if callbacks else None,
                verbose=1
            )
            
            # Store training history
            self.training_history = history.history
            
            # Prepare results
            final_train_loss = history.history['loss'][-1]
            final_train_acc = history.history['accuracy'][-1]
            
            result = {
                "training_completed": True,
                "epochs_completed": len(history.history['loss']),
                "final_train_loss": float(final_train_loss),
                "final_train_accuracy": float(final_train_acc),
                "training_history": history.history,
                "class_names": self.class_names,
                "model_path": checkpoint_path if save_best_model else None
            }
            
            # Add validation metrics if available
            if self.valid_generator and 'val_loss' in history.history:
                final_val_loss = history.history['val_loss'][-1]
                final_val_acc = history.history['val_accuracy'][-1]
                result.update({
                    "final_val_loss": float(final_val_loss),
                    "final_val_accuracy": float(final_val_acc)
                })
            
            return result
            
        except Exception as e:
            logger.error(f"Error during training: {e}")
            return {"error": str(e)}
    
    def evaluate(self) -> Dict[str, Any]:
        """
        Evaluate the trained model
        
        Returns:
            Evaluation results
        """
        try:
            if self.model is None:
                return {"error": "No trained model available"}
            
            if self.test_generator is None:
                return {"error": "No test data available"}
            
            # Evaluate model
            test_loss, test_accuracy = self.model.evaluate(
                self.test_generator,
                steps=self.test_generator.samples // self.test_generator.batch_size,
                verbose=0
            )
            
            return {
                "test_loss": float(test_loss),
                "test_accuracy": float(test_accuracy),
                "samples_evaluated": self.test_generator.samples
            }
            
        except Exception as e:
            logger.error(f"Error evaluating model: {e}")
            return {"error": str(e)}
    
    def save_model(self, save_path: Optional[str] = None) -> Dict[str, Any]:
        """
        Save the trained model
        
        Args:
            save_path: Path to save the model
            
        Returns:
            Save operation result
        """
        try:
            if self.model is None:
                return {"error": "No model to save"}
            
            if save_path is None:
                save_path = self._get_default_save_path()
            
            # Ensure directory exists
            os.makedirs(os.path.dirname(save_path), exist_ok=True)
            
            # Save model
            self.model.save(save_path)
            
            # Save model metadata
            metadata = {
                'architecture': self.architecture,
                'task_type': self.task_type,
                'num_classes': self.num_classes,
                'class_names': self.class_names,
                'input_shape': self.input_shape,
                'training_config': self.config,
                'training_history': self.training_history
            }
            
            metadata_path = save_path.replace('.h5', '_metadata.json').replace('.keras', '_metadata.json')
            with open(metadata_path, 'w') as f:
                json.dump(metadata, f, indent=2, default=str)
            
            return {
                "model_saved": save_path,
                "metadata_saved": metadata_path,
                "model_size_mb": os.path.getsize(save_path) / (1024 * 1024)
            }
            
        except Exception as e:
            logger.error(f"Error saving model: {e}")
            return {"error": str(e)}
    
    def _get_checkpoint_path(self) -> str:
        """Get checkpoint path for training"""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        return f"checkpoints/cv/{self.architecture}_{self.task_type}_{timestamp}.h5"
    
    def _get_default_save_path(self) -> str:
        """Get default save path"""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        return f"saved_models/cv/{self.architecture}_{self.task_type}_{timestamp}.h5"
    
    def get_training_info(self) -> Dict[str, Any]:
        """Get training information"""
        return {
            "trainer_type": "ImageClassificationTrainer",
            "architecture": self.architecture,
            "task_type": self.task_type,
            "num_classes": self.num_classes,
            "input_shape": self.input_shape,
            "model_built": self.model is not None,
            "data_prepared": self.train_generator is not None,
            "class_names": self.class_names,
            "supported_architectures": list(self.SUPPORTED_ARCHITECTURES.keys()),
            "training_completed": self.training_history is not None
        }