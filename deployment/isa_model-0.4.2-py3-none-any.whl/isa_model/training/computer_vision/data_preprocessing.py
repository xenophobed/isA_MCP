#!/usr/bin/env python3
"""
Computer Vision Data Preprocessing
Data preprocessing utilities for computer vision training
Based on the notebook data preprocessing tasks
"""

import os
import numpy as np
from typing import Dict, List, Any, Optional, Tuple
import logging

logger = logging.getLogger(__name__)

def _lazy_import_keras():
    """Lazy import Keras components"""
    try:
        import tensorflow as tf
        from tensorflow.keras.preprocessing.image import ImageDataGenerator
        
        return {
            'tf': tf,
            'ImageDataGenerator': ImageDataGenerator,
            'available': True
        }
    except ImportError:
        return {'available': False}

class CVDataPreprocessor:
    """
    Computer vision data preprocessing utilities
    Following the structure from the Jupyter notebook
    """
    
    def __init__(self):
        """Initialize data preprocessor"""
        self.keras_components = _lazy_import_keras()
        
        if not self.keras_components['available']:
            raise ImportError("TensorFlow/Keras is required for image preprocessing")
        
        # Configuration from notebook
        self.batch_size = 32
        self.img_rows, self.img_cols = 224, 224
        self.input_shape = (self.img_rows, self.img_cols, 3)
        self.seed_value = 42
        
        # Data generators
        self.train_datagen = None
        self.valid_datagen = None  
        self.test_datagen = None
    
    def setup_data_generators(self, 
                            augmentation: bool = False,
                            rescale: float = 1./255) -> Dict[str, Any]:
        """
        Setup ImageDataGenerators following the notebook structure
        
        Args:
            augmentation: Whether to apply data augmentation
            rescale: Rescaling factor for pixel values
            
        Returns:
            Setup information
        """
        try:
            ImageDataGenerator = self.keras_components['ImageDataGenerator']
            
            if augmentation:
                # Training generator with augmentation
                self.train_datagen = ImageDataGenerator(
                    rescale=rescale,
                    rotation_range=20,
                    width_shift_range=0.2,
                    height_shift_range=0.2,
                    shear_range=0.2,
                    zoom_range=0.2,
                    horizontal_flip=True,
                    fill_mode='nearest'
                )
            else:
                # Simple rescaling as in the notebook
                self.train_datagen = ImageDataGenerator(rescale=rescale)
            
            # Validation and test generators (no augmentation, just rescaling)
            self.valid_datagen = ImageDataGenerator(rescale=rescale)
            self.test_datagen = ImageDataGenerator(rescale=rescale)
            
            return {
                "train_datagen_created": True,
                "valid_datagen_created": True,
                "test_datagen_created": True,
                "augmentation_enabled": augmentation,
                "rescale_factor": rescale
            }
            
        except Exception as e:
            logger.error(f"Error setting up data generators: {e}")
            return {"error": str(e)}
    
    def create_generators_from_directories(self,
                                         train_dir: str,
                                         valid_dir: str,
                                         test_dir: str,
                                         batch_size: int = 32,
                                         target_size: Tuple[int, int] = (224, 224),
                                         class_mode: str = 'binary',
                                         augmentation: bool = False) -> Dict[str, Any]:
        """
        Create all generators from directories in one go
        
        Args:
            train_dir: Training data directory
            valid_dir: Validation data directory
            test_dir: Test data directory
            batch_size: Batch size for all generators
            target_size: Target image size
            class_mode: Class mode ('binary' or 'categorical')
            augmentation: Whether to apply augmentation
            
        Returns:
            All generators and metadata
        """
        try:
            # Setup data generators first
            setup_result = self.setup_data_generators(augmentation=augmentation)
            if "error" in setup_result:
                return setup_result
            
            # Auto-detect class mode if not specified
            if class_mode == 'auto':
                try:
                    train_classes = [d for d in os.listdir(train_dir) 
                                   if os.path.isdir(os.path.join(train_dir, d))]
                    class_mode = 'binary' if len(train_classes) == 2 else 'categorical'
                except:
                    class_mode = 'binary'  # fallback
            
            # Create training generator
            train_generator = self.train_datagen.flow_from_directory(
                train_dir,
                target_size=target_size,
                batch_size=batch_size,
                seed=self.seed_value,
                class_mode=class_mode,
                shuffle=True
            )
            
            # Create validation generator (Task 1 from notebook)
            valid_generator = self.valid_datagen.flow_from_directory(
                directory=valid_dir,
                class_mode=class_mode,
                seed=self.seed_value,
                batch_size=batch_size,
                shuffle=False,
                target_size=target_size
            )
            
            # Create test generator (Task 2 from notebook)
            test_generator = self.test_datagen.flow_from_directory(
                directory=test_dir,
                class_mode=class_mode,
                seed=self.seed_value,
                batch_size=batch_size,
                shuffle=False,
                target_size=target_size
            )
            
            return {
                "generators_created": True,
                "train_generator": train_generator,
                "valid_generator": valid_generator,
                "test_generator": test_generator,
                "train_samples": train_generator.samples,
                "valid_samples": valid_generator.samples,
                "test_samples": test_generator.samples,
                "class_indices": train_generator.class_indices,
                "class_names": list(train_generator.class_indices.keys()),
                "num_classes": train_generator.num_classes,
                "batch_size": batch_size,
                "target_size": target_size,
                "class_mode": class_mode,
                "augmentation": augmentation
            }
            
        except Exception as e:
            logger.error(f"Error creating generators: {e}")
            return {"error": str(e)}
    
    def validate_data_directories(self, 
                                train_dir: str,
                                valid_dir: str,
                                test_dir: Optional[str] = None) -> Dict[str, Any]:
        """
        Validate data directory structure
        
        Args:
            train_dir: Training data directory
            valid_dir: Validation data directory
            test_dir: Test data directory (optional)
            
        Returns:
            Validation results
        """
        try:
            results = {
                "valid_structure": True,
                "directories_checked": [],
                "issues": []
            }
            
            # Check each directory
            for dir_name, dir_path in [("train", train_dir), ("valid", valid_dir), ("test", test_dir)]:
                if dir_path is None:
                    continue
                    
                dir_info = {
                    "name": dir_name,
                    "path": dir_path,
                    "exists": os.path.exists(dir_path),
                    "is_directory": os.path.isdir(dir_path) if os.path.exists(dir_path) else False,
                    "classes": [],
                    "total_images": 0
                }
                
                if dir_info["exists"] and dir_info["is_directory"]:
                    # Get class subdirectories
                    try:
                        subdirs = [d for d in os.listdir(dir_path) 
                                 if os.path.isdir(os.path.join(dir_path, d))]
                        dir_info["classes"] = subdirs
                        
                        # Count images in each class
                        class_counts = {}
                        for class_name in subdirs:
                            class_path = os.path.join(dir_path, class_name)
                            image_files = [f for f in os.listdir(class_path) 
                                         if f.lower().endswith(('.png', '.jpg', '.jpeg', '.gif', '.bmp'))]
                            class_counts[class_name] = len(image_files)
                            dir_info["total_images"] += len(image_files)
                        
                        dir_info["class_counts"] = class_counts
                        
                    except Exception as e:
                        results["issues"].append(f"Error reading {dir_name} directory: {e}")
                        results["valid_structure"] = False
                else:
                    results["issues"].append(f"{dir_name} directory does not exist or is not a directory: {dir_path}")
                    results["valid_structure"] = False
                
                results["directories_checked"].append(dir_info)
            
            # Check class consistency
            if len(results["directories_checked"]) >= 2:
                train_classes = set(results["directories_checked"][0].get("classes", []))
                valid_classes = set(results["directories_checked"][1].get("classes", []))
                
                if train_classes != valid_classes:
                    results["issues"].append(f"Class mismatch between train and valid: {train_classes} vs {valid_classes}")
                    results["valid_structure"] = False
            
            return results
            
        except Exception as e:
            logger.error(f"Error validating directories: {e}")
            return {"error": str(e)}
    
    def get_dataset_statistics(self, generators: Dict[str, Any]) -> Dict[str, Any]:
        """
        Get statistics about the dataset
        
        Args:
            generators: Dictionary containing generators
            
        Returns:
            Dataset statistics
        """
        try:
            stats = {
                "total_samples": 0,
                "split_distribution": {},
                "class_distribution": {},
                "imbalance_ratio": None
            }
            
            # Calculate split distribution
            for split_name in ["train_generator", "valid_generator", "test_generator"]:
                if split_name in generators and generators[split_name] is not None:
                    samples = generators[split_name].samples
                    stats["split_distribution"][split_name.replace("_generator", "")] = samples
                    stats["total_samples"] += samples
            
            # Calculate class distribution (from training set)
            if "train_generator" in generators and generators["train_generator"] is not None:
                train_gen = generators["train_generator"]
                class_indices = train_gen.class_indices
                
                # Count samples per class
                class_counts = {}
                for class_name, class_idx in class_indices.items():
                    class_counts[class_name] = sum(train_gen.labels == class_idx)
                
                stats["class_distribution"] = class_counts
                
                # Calculate imbalance ratio
                if len(class_counts) > 1:
                    max_count = max(class_counts.values())
                    min_count = min(class_counts.values())
                    stats["imbalance_ratio"] = max_count / min_count if min_count > 0 else float('inf')
            
            return stats
            
        except Exception as e:
            logger.error(f"Error calculating dataset statistics: {e}")
            return {"error": str(e)}
    
    def create_balanced_generators(self,
                                 train_dir: str,
                                 valid_dir: str,
                                 test_dir: str,
                                 target_samples_per_class: Optional[int] = None) -> Dict[str, Any]:
        """
        Create balanced generators by limiting samples per class
        
        Args:
            train_dir: Training data directory
            valid_dir: Validation data directory
            test_dir: Test data directory
            target_samples_per_class: Target number of samples per class
            
        Returns:
            Balanced generators and info
        """
        # This would require custom sampling logic
        # For now, return the standard generators with a note
        result = self.create_generators_from_directories(train_dir, valid_dir, test_dir)
        
        if target_samples_per_class:
            result["note"] = f"Balanced sampling with {target_samples_per_class} samples per class not implemented yet"
        
        return result