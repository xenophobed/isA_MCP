"""
LlamaFactory Integration for ISA Training System

This module integrates LlamaFactory capabilities into our intelligent training system,
providing access to advanced training algorithms and scenarios while maintaining
our intelligent optimization and monitoring capabilities.
"""

import os
import json
import logging
import subprocess
import tempfile
from typing import Dict, List, Optional, Any, Union
from pathlib import Path
from dataclasses import dataclass, asdict
import yaml

logger = logging.getLogger(__name__)


@dataclass
class LlamaFactoryConfig:
    """Configuration for LlamaFactory training."""
    
    # Model settings
    model_name: str
    model_revision: str = "main"
    quantization_bit: Optional[int] = None
    
    # Training settings
    stage: str = "sft"  # sft, rm, ppo, dpo, orpo
    do_train: bool = True
    finetuning_type: str = "lora"  # lora, full, freeze
    
    # LoRA settings
    lora_target: str = "all"
    lora_rank: int = 8
    lora_alpha: int = 16
    lora_dropout: float = 0.05
    
    # Dataset settings
    dataset: str = "custom_dataset"
    template: str = "default"
    cutoff_len: int = 1024
    max_samples: Optional[int] = None
    overwrite_cache: bool = True
    preprocessing_num_workers: int = 16
    
    # Training hyperparameters
    output_dir: str = "./output"
    overwrite_output_dir: bool = True
    num_train_epochs: float = 3.0
    max_steps: int = -1
    per_device_train_batch_size: int = 2
    gradient_accumulation_steps: int = 4
    learning_rate: float = 5e-5
    weight_decay: float = 0.1
    lr_scheduler_type: str = "cosine"
    warmup_steps: int = 0
    
    # Optimization
    optim: str = "adamw_torch"
    fp16: bool = True
    ddp_timeout: int = 180000000
    
    # Logging and saving
    logging_steps: int = 10
    save_steps: int = 500
    eval_steps: int = 500
    evaluation_strategy: str = "steps"
    save_total_limit: int = 2
    
    # Additional settings
    plot_loss: bool = True
    include_num_input_tokens_seen: bool = True
    
    def to_yaml(self) -> str:
        """Convert config to YAML format for LlamaFactory."""
        config_dict = asdict(self)
        
        # Remove None values
        config_dict = {k: v for k, v in config_dict.items() if v is not None}
        
        return yaml.dump(config_dict, default_flow_style=False)
    
    def save_to_file(self, filepath: str) -> None:
        """Save config to YAML file."""
        with open(filepath, 'w') as f:
            f.write(self.to_yaml())


class LlamaFactoryTrainer:
    """
    LlamaFactory integration for advanced training scenarios.
    
    Provides access to:
    - Supervised Fine-tuning (SFT)
    - Reward Modeling (RM) 
    - Proximal Policy Optimization (PPO)
    - Direct Preference Optimization (DPO)
    - Odds Ratio Preference Optimization (ORPO)
    """
    
    def __init__(self, 
                 llamafactory_path: Optional[str] = None,
                 conda_env: Optional[str] = None):
        """
        Initialize LlamaFactory trainer.
        
        Args:
            llamafactory_path: Path to LlamaFactory installation
            conda_env: Conda environment name for LlamaFactory
        """
        self.llamafactory_path = llamafactory_path or self._find_llamafactory()
        self.conda_env = conda_env
        
        if not self.llamafactory_path:
            logger.warning("LlamaFactory not found. Install with: pip install llamafactory-cli")
            
    def _find_llamafactory(self) -> Optional[str]:
        """Find LlamaFactory installation."""
        try:
            result = subprocess.run(
                ["which", "llamafactory-cli"], 
                capture_output=True, text=True, check=True
            )
            return result.stdout.strip()
        except subprocess.CalledProcessError:
            # Try Python import
            try:
                import llamafactory
                return str(Path(llamafactory.__file__).parent)
            except ImportError:
                return None
    
    def is_available(self) -> bool:
        """Check if LlamaFactory is available."""
        return self.llamafactory_path is not None
    
    def get_supported_models(self) -> List[str]:
        """Get list of models supported by LlamaFactory."""
        if not self.is_available():
            return []
        
        # Common models supported by LlamaFactory
        return [
            "llama2", "llama3", "llama3.1", "llama3.2",
            "qwen", "qwen1.5", "qwen2", "qwen2.5",
            "baichuan", "baichuan2", "chatglm3", "chatglm4",
            "mistral", "mixtral", "yi", "deepseek",
            "gemma", "gemma2", "phi3", "starcoder2"
        ]
    
    def get_supported_stages(self) -> List[str]:
        """Get supported training stages."""
        return ["sft", "rm", "ppo", "dpo", "orpo"]
    
    def get_supported_templates(self) -> Dict[str, str]:
        """Get supported chat templates."""
        return {
            "llama3": "LLaMA-3 template",
            "qwen": "Qwen template", 
            "baichuan": "Baichuan template",
            "chatglm3": "ChatGLM3 template",
            "mistral": "Mistral template",
            "gemma": "Gemma template",
            "default": "Default template"
        }
    
    def create_dataset_config(self,
                            dataset_name: str,
                            dataset_path: str,
                            dataset_format: str = "alpaca") -> Dict[str, Any]:
        """
        Create dataset configuration for LlamaFactory.
        
        Args:
            dataset_name: Name for the dataset
            dataset_path: Path to dataset file
            dataset_format: Format of dataset (alpaca, sharegpt, etc.)
            
        Returns:
            Dataset configuration dict
        """
        return {
            dataset_name: {
                "file_name": dataset_path,
                "formatting": dataset_format,
                "columns": {
                    "prompt": "instruction" if dataset_format == "alpaca" else "conversations",
                    "query": "input" if dataset_format == "alpaca" else None,
                    "response": "output" if dataset_format == "alpaca" else None,
                    "system": "system" if dataset_format == "alpaca" else None
                }
            }
        }
    
    def train_sft(self,
                  model_name: str,
                  dataset_path: str,
                  output_dir: str,
                  config_overrides: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        Perform Supervised Fine-tuning with LlamaFactory.
        
        Args:
            model_name: Model to fine-tune
            dataset_path: Path to training dataset
            output_dir: Output directory for model
            config_overrides: Override default configuration
            
        Returns:
            Training results
        """
        if not self.is_available():
            raise RuntimeError("LlamaFactory not available")
        
        # Create configuration
        config = LlamaFactoryConfig(
            model_name=model_name,
            dataset="custom_dataset",
            output_dir=output_dir,
            stage="sft",
            **config_overrides or {}
        )
        
        return self._run_training(config, dataset_path)
    
    def train_dpo(self,
                  model_name: str,
                  dataset_path: str,
                  output_dir: str,
                  sft_model_path: str,
                  config_overrides: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        Perform Direct Preference Optimization (DPO) training.
        
        Args:
            model_name: Base model name
            dataset_path: Path to preference dataset
            output_dir: Output directory
            sft_model_path: Path to SFT model for initialization
            config_overrides: Configuration overrides
            
        Returns:
            Training results
        """
        if not self.is_available():
            raise RuntimeError("LlamaFactory not available")
        
        config = LlamaFactoryConfig(
            model_name=model_name,
            dataset="custom_preference_dataset",
            output_dir=output_dir,
            stage="dpo",
            # DPO specific settings
            **config_overrides or {}
        )
        
        return self._run_training(config, dataset_path, sft_model_path)
    
    def train_reward_model(self,
                          model_name: str,
                          dataset_path: str,
                          output_dir: str,
                          config_overrides: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        Train a reward model for RLHF.
        
        Args:
            model_name: Base model for reward model
            dataset_path: Path to preference dataset
            output_dir: Output directory
            config_overrides: Configuration overrides
            
        Returns:
            Training results
        """
        if not self.is_available():
            raise RuntimeError("LlamaFactory not available")
        
        config = LlamaFactoryConfig(
            model_name=model_name,
            dataset="custom_reward_dataset",
            output_dir=output_dir,
            stage="rm",
            **config_overrides or {}
        )
        
        return self._run_training(config, dataset_path)
    
    def train_ppo(self,
                  model_name: str,
                  reward_model_path: str,
                  dataset_path: str,
                  output_dir: str,
                  config_overrides: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        Perform PPO training with reward model.
        
        Args:
            model_name: SFT model to optimize
            reward_model_path: Path to trained reward model
            dataset_path: Path to prompts dataset
            output_dir: Output directory
            config_overrides: Configuration overrides
            
        Returns:
            Training results
        """
        if not self.is_available():
            raise RuntimeError("LlamaFactory not available")
        
        config = LlamaFactoryConfig(
            model_name=model_name,
            dataset="custom_ppo_dataset",
            output_dir=output_dir,
            stage="ppo",
            **config_overrides or {}
        )
        
        return self._run_training(config, dataset_path, reward_model_path)
    
    def _run_training(self,
                     config: LlamaFactoryConfig,
                     dataset_path: str,
                     additional_model_path: Optional[str] = None) -> Dict[str, Any]:
        """
        Run LlamaFactory training with given configuration.
        
        Args:
            config: Training configuration
            dataset_path: Path to dataset
            additional_model_path: Additional model path (for DPO/PPO)
            
        Returns:
            Training results
        """
        try:
            with tempfile.TemporaryDirectory() as temp_dir:
                # Save configuration
                config_path = os.path.join(temp_dir, "train_config.yaml")
                config.save_to_file(config_path)
                
                # Create dataset config
                dataset_config_path = os.path.join(temp_dir, "dataset_info.json")
                dataset_config = self.create_dataset_config(
                    "custom_dataset", dataset_path
                )
                
                with open(dataset_config_path, 'w') as f:
                    json.dump(dataset_config, f, indent=2)
                
                # Build command
                cmd = [
                    "llamafactory-cli", "train",
                    "--config", config_path,
                    "--dataset_info", dataset_config_path
                ]
                
                if additional_model_path:
                    cmd.extend(["--model_name_or_path", additional_model_path])
                
                # Execute training
                logger.info(f"Starting LlamaFactory training with config: {config_path}")
                
                if self.conda_env:
                    cmd = ["conda", "run", "-n", self.conda_env] + cmd
                
                result = subprocess.run(
                    cmd,
                    capture_output=True,
                    text=True,
                    cwd=temp_dir,
                    timeout=86400  # 24 hour timeout
                )
                
                if result.returncode != 0:
                    logger.error(f"LlamaFactory training failed: {result.stderr}")
                    raise RuntimeError(f"Training failed: {result.stderr}")
                
                logger.info("LlamaFactory training completed successfully")
                
                return {
                    "status": "completed",
                    "output_dir": config.output_dir,
                    "config": asdict(config),
                    "stdout": result.stdout,
                    "stderr": result.stderr
                }
                
        except subprocess.TimeoutExpired:
            logger.error("LlamaFactory training timed out")
            raise RuntimeError("Training timed out after 24 hours")
        except Exception as e:
            logger.error(f"LlamaFactory training error: {e}")
            raise
    
    def get_model_info(self, model_name: str) -> Dict[str, Any]:
        """Get information about a supported model."""
        if not self.is_available():
            return {"error": "LlamaFactory not available"}
        
        # This would typically query LlamaFactory's model registry
        return {
            "model_name": model_name,
            "supported": model_name in self.get_supported_models(),
            "templates": list(self.get_supported_templates().keys()),
            "stages": self.get_supported_stages()
        }


class EnhancedLlamaFactoryIntegration:
    """
    Enhanced integration that combines LlamaFactory with ISA's intelligent training.
    """
    
    def __init__(self, intelligent_factory):
        """
        Initialize enhanced integration.
        
        Args:
            intelligent_factory: ISA IntelligentTrainingFactory instance
        """
        self.intelligent_factory = intelligent_factory
        self.llamafactory_trainer = LlamaFactoryTrainer()
        
    def get_enhanced_capabilities(self) -> Dict[str, Any]:
        """Get enhanced capabilities with LlamaFactory integration."""
        base_capabilities = self.intelligent_factory.get_supported_capabilities()
        
        if self.llamafactory_trainer.is_available():
            base_capabilities.update({
                "llamafactory_available": True,
                "llamafactory_models": self.llamafactory_trainer.get_supported_models(),
                "training_stages": self.llamafactory_trainer.get_supported_stages(),
                "chat_templates": list(self.llamafactory_trainer.get_supported_templates().keys())
            })
        else:
            base_capabilities["llamafactory_available"] = False
            
        return base_capabilities
    
    def intelligent_llamafactory_training(self,
                                        description: str,
                                        dataset_path: str,
                                        training_stage: str = "sft",
                                        quality_target: str = "balanced",
                                        **preferences) -> Dict[str, Any]:
        """
        Perform intelligent LlamaFactory training.
        
        Combines ISA's intelligent analysis with LlamaFactory's advanced algorithms.
        
        Args:
            description: Natural language description of training task
            dataset_path: Path to training dataset
            training_stage: LlamaFactory training stage (sft, dpo, ppo, etc.)
            quality_target: Quality target for intelligent optimization
            **preferences: Additional preferences
            
        Returns:
            Training results with intelligent insights
        """
        if not self.llamafactory_trainer.is_available():
            raise RuntimeError("LlamaFactory not available. Install with: pip install llamafactory-cli")
        
        logger.info(f"Starting intelligent LlamaFactory {training_stage.upper()} training")
        
        try:
            # Get intelligent recommendation
            recommendation = self.intelligent_factory.analyze_training_request(
                description=description,
                dataset_source=dataset_path,
                quality_target=quality_target,
                **preferences
            )
            
            # Convert ISA recommendation to LlamaFactory config
            llamafactory_config = self._convert_recommendation_to_llamafactory(
                recommendation, training_stage
            )
            
            # Execute training with LlamaFactory
            if training_stage == "sft":
                result = self.llamafactory_trainer.train_sft(
                    model_name=recommendation.model_name,
                    dataset_path=dataset_path,
                    output_dir=recommendation.training_config.output_dir,
                    config_overrides=llamafactory_config
                )
            elif training_stage == "dpo":
                sft_model = preferences.get("sft_model_path")
                if not sft_model:
                    raise ValueError("sft_model_path required for DPO training")
                
                result = self.llamafactory_trainer.train_dpo(
                    model_name=recommendation.model_name,
                    dataset_path=dataset_path,
                    output_dir=recommendation.training_config.output_dir,
                    sft_model_path=sft_model,
                    config_overrides=llamafactory_config
                )
            else:
                raise ValueError(f"Training stage '{training_stage}' not implemented yet")
            
            # Enhance result with intelligent insights
            result.update({
                "intelligent_recommendation": {
                    "model_name": recommendation.model_name,
                    "estimated_cost": recommendation.estimated_cost,
                    "estimated_time": recommendation.estimated_time,
                    "confidence": recommendation.confidence_score,
                    "decision_reasons": recommendation.decision_reasons
                },
                "llamafactory_stage": training_stage,
                "isa_enhanced": True
            })
            
            return result
            
        except Exception as e:
            logger.error(f"Intelligent LlamaFactory training failed: {e}")
            raise
    
    def _convert_recommendation_to_llamafactory(self,
                                              recommendation,
                                              training_stage: str) -> Dict[str, Any]:
        """Convert ISA recommendation to LlamaFactory configuration."""
        config = recommendation.training_config
        
        llamafactory_config = {
            # Basic settings
            "stage": training_stage,
            "num_train_epochs": config.num_epochs,
            "per_device_train_batch_size": config.batch_size,
            "learning_rate": config.learning_rate,
            "cutoff_len": config.dataset_config.max_length,
            
            # LoRA settings from ISA recommendation
            "finetuning_type": "lora" if config.lora_config and config.lora_config.use_lora else "full",
        }
        
        if config.lora_config and config.lora_config.use_lora:
            llamafactory_config.update({
                "lora_rank": config.lora_config.lora_rank,
                "lora_alpha": config.lora_config.lora_alpha,
                "lora_dropout": getattr(config.lora_config, 'lora_dropout', 0.05)
            })
        
        # GPU optimization based on recommendation
        if hasattr(recommendation, 'recommended_gpu'):
            gpu = recommendation.recommended_gpu.lower()
            if 'a100' in gpu or 'h100' in gpu:
                llamafactory_config["fp16"] = False
                llamafactory_config["bf16"] = True
            else:
                llamafactory_config["fp16"] = True
        
        return llamafactory_config