"""
Unified Training Storage Manager

Consolidates training storage, repository pattern, and core integration
into a single, unified interface that provides:
- Simple, unified API for all training storage operations
- Automatic core system integration
- Intelligent storage backend selection
- Built-in caching and performance optimization
- Comprehensive error handling and recovery
"""

import logging
import asyncio
from typing import Dict, List, Optional, Any, Union
from datetime import datetime, timedelta
from pathlib import Path
from dataclasses import dataclass, asdict
import uuid

# Import existing components
from .training_storage import TrainingStorage, TrainingJobRecord, TrainingMetrics
from .core_integration import CoreModelIntegration
from .training_repository import TrainingRepository

logger = logging.getLogger(__name__)


@dataclass
class UnifiedTrainingConfig:
    """Configuration for unified training manager"""
    
    # Storage configuration
    use_database: bool = True
    storage_dir: Optional[str] = None
    cache_size: int = 100
    cache_ttl_minutes: int = 30
    
    # Core integration configuration
    enable_core_integration: bool = True
    auto_register_models: bool = True
    sync_costs: bool = True
    sync_statistics: bool = True
    
    # Performance configuration
    async_operations: bool = True
    batch_operations: bool = True
    max_concurrent_operations: int = 10
    
    # Backup and recovery
    enable_backup: bool = True
    backup_interval_hours: int = 24
    max_backup_files: int = 7


class UnifiedTrainingManager:
    """
    Unified Training Storage Manager
    
    Provides a single, comprehensive interface for all training-related
    storage operations with automatic optimization and integration.
    
    Features:
    - Unified API combining storage, repository, and core integration
    - Intelligent backend selection (database vs file-based)
    - Built-in caching for frequently accessed data
    - Automatic core system synchronization
    - Comprehensive error handling and recovery
    - Performance optimization with async operations
    - Built-in backup and disaster recovery
    
    Example:
        ```python
        # Simple setup
        manager = UnifiedTrainingManager()
        
        # Create and start training job
        job_id = await manager.create_training_job(
            job_name="medical_chatbot_v2",
            base_model="llama2-7b",
            task_type="chat",
            domain="medical",
            dataset_source="medical_qa_v2.json",
            training_config={"epochs": 3, "learning_rate": 2e-5}
        )
        
        # Update progress
        await manager.update_progress(job_id, {
            "epoch": 1,
            "step": 100,
            "training_loss": 0.5
        })
        
        # Complete training with automatic model registration
        model_id = await manager.complete_training(
            job_id=job_id,
            model_path="/path/to/trained/model",
            final_metrics={"accuracy": 0.95, "f1_score": 0.93}
        )
        
        # model_id is automatically registered in core system
        ```
    """
    
    def __init__(self, config: Optional[UnifiedTrainingConfig] = None):
        """Initialize unified training manager"""
        
        self.config = config or UnifiedTrainingConfig()
        
        # Initialize components
        self.storage = TrainingStorage(
            storage_dir=self.config.storage_dir,
            use_database=self.config.use_database
        )
        
        self.repository = TrainingRepository(storage=self.storage)
        
        if self.config.enable_core_integration:
            self.core_integration = CoreModelIntegration(training_storage=self.storage)
        else:
            self.core_integration = None
        
        # Performance optimizations
        self._cache = {}
        self._cache_timestamps = {}
        self._operation_queue = asyncio.Queue() if self.config.async_operations else None
        self._semaphore = asyncio.Semaphore(self.config.max_concurrent_operations)
        
        # Statistics
        self._stats = {
            "operations_count": 0,
            "cache_hits": 0,
            "cache_misses": 0,
            "errors_count": 0,
            "last_backup": None
        }
        
        logger.info("Unified Training Manager initialized")
    
    async def initialize(self) -> bool:
        """Initialize all components and connections"""
        try:
            # Sync with core system if enabled
            if self.core_integration:
                sync_success = self.core_integration.sync_training_knowledge_to_core()
                if sync_success:
                    logger.info("Successfully synced training knowledge to core")
                else:
                    logger.warning("Failed to sync training knowledge to core")
            
            # Start background tasks
            if self.config.async_operations:
                asyncio.create_task(self._process_operation_queue())
            
            if self.config.enable_backup:
                asyncio.create_task(self._periodic_backup())
            
            logger.info("Unified Training Manager fully initialized")
            return True
            
        except Exception as e:
            logger.error(f"Failed to initialize Unified Training Manager: {e}")
            return False
    
    # ====================== Core Training Operations ======================
    
    async def create_training_job(
        self,
        job_name: str,
        base_model: str,
        task_type: str,
        domain: str,
        dataset_source: str,
        training_config: Dict[str, Any],
        **kwargs
    ) -> str:
        """Create a new training job with unified management"""
        
        async with self._semaphore:
            try:
                # Use repository for business logic
                job_id = self.repository.create_training_job(
                    job_name=job_name,
                    base_model=base_model,
                    task_type=task_type,
                    domain=domain,
                    dataset_source=dataset_source,
                    training_config=training_config,
                    **kwargs
                )
                
                # Cache the job for quick access
                job_record = self.storage.get_training_job(job_id)
                if job_record:
                    self._update_cache(f"job:{job_id}", job_record)
                
                self._stats["operations_count"] += 1
                
                logger.info(f"Created training job: {job_id}")
                return job_id
                
            except Exception as e:
                self._stats["errors_count"] += 1
                logger.error(f"Failed to create training job: {e}")
                raise
    
    async def update_progress(
        self,
        job_id: str,
        metrics_data: Dict[str, Any],
        status: Optional[str] = None
    ) -> bool:
        """Update training progress with optimized caching"""
        
        async with self._semaphore:
            try:
                # Record metrics
                success = self.repository.record_metrics(job_id, metrics_data)
                
                # Update status if provided
                if status:
                    self.repository.update_job_status(job_id, status)
                
                # Invalidate cache for this job
                self._invalidate_cache(f"job:{job_id}")
                self._invalidate_cache(f"progress:{job_id}")
                
                self._stats["operations_count"] += 1
                
                if success:
                    logger.debug(f"Updated progress for job {job_id}")
                
                return success
                
            except Exception as e:
                self._stats["errors_count"] += 1
                logger.error(f"Failed to update progress for job {job_id}: {e}")
                return False
    
    async def complete_training(
        self,
        job_id: str,
        model_path: str,
        final_metrics: Optional[Dict[str, Any]] = None,
        cost_breakdown: Optional[Dict[str, float]] = None
    ) -> Optional[str]:
        """Complete training with automatic core integration"""
        
        async with self._semaphore:
            try:
                # Complete training via repository
                core_model_id = self.repository.complete_training(
                    job_id=job_id,
                    model_path=model_path,
                    final_metrics=final_metrics,
                    cost_breakdown=cost_breakdown
                )
                
                # Clear cache for this job
                self._invalidate_cache(f"job:{job_id}")
                
                self._stats["operations_count"] += 1
                
                if core_model_id:
                    logger.info(f"Training completed and model registered: {core_model_id}")
                
                return core_model_id
                
            except Exception as e:
                self._stats["errors_count"] += 1
                logger.error(f"Failed to complete training for job {job_id}: {e}")
                return None
    
    # ====================== Query Operations ======================
    
    async def get_job(self, job_id: str, use_cache: bool = True) -> Optional[TrainingJobRecord]:
        """Get training job with intelligent caching"""
        
        # Check cache first
        if use_cache:
            cached_job = self._get_from_cache(f"job:{job_id}")
            if cached_job:
                self._stats["cache_hits"] += 1
                return cached_job
        
        self._stats["cache_misses"] += 1
        
        try:
            job = self.repository.get_job(job_id)
            
            if job and use_cache:
                self._update_cache(f"job:{job_id}", job)
            
            return job
            
        except Exception as e:
            self._stats["errors_count"] += 1
            logger.error(f"Failed to get job {job_id}: {e}")
            return None
    
    async def get_job_progress(self, job_id: str) -> Optional[Dict[str, Any]]:
        """Get comprehensive job progress with caching"""
        
        # Check cache first
        cached_progress = self._get_from_cache(f"progress:{job_id}")
        if cached_progress:
            self._stats["cache_hits"] += 1
            return cached_progress
        
        self._stats["cache_misses"] += 1
        
        try:
            progress = self.repository.get_job_progress(job_id)
            
            if progress:
                self._update_cache(f"progress:{job_id}", progress)
            
            return progress
            
        except Exception as e:
            self._stats["errors_count"] += 1
            logger.error(f"Failed to get job progress for {job_id}: {e}")
            return None
    
    async def list_jobs(
        self,
        status: Optional[str] = None,
        user_id: Optional[str] = None,
        project_name: Optional[str] = None,
        limit: int = 100
    ) -> List[TrainingJobRecord]:
        """List jobs with intelligent filtering"""
        
        try:
            jobs = self.repository.list_jobs(
                status=status,
                user_id=user_id,
                project_name=project_name,
                limit=limit
            )
            
            # Cache individual jobs for future access
            for job in jobs:
                self._update_cache(f"job:{job.job_id}", job)
            
            return jobs
            
        except Exception as e:
            self._stats["errors_count"] += 1
            logger.error(f"Failed to list jobs: {e}")
            return []
    
    # ====================== Analytics and Monitoring ======================
    
    async def get_training_analytics(
        self,
        user_id: Optional[str] = None,
        time_range_days: int = 30
    ) -> Dict[str, Any]:
        """Get comprehensive training analytics"""
        
        try:
            cutoff_date = datetime.now() - timedelta(days=time_range_days)
            
            all_jobs = await self.list_jobs(user_id=user_id, limit=1000)
            recent_jobs = [job for job in all_jobs if job.created_at >= cutoff_date]
            
            # Basic statistics
            total_jobs = len(recent_jobs)
            completed_jobs = len([job for job in recent_jobs if job.status == "completed"])
            failed_jobs = len([job for job in recent_jobs if job.status == "failed"])
            
            # Cost analysis
            total_cost = 0.0
            for job in recent_jobs:
                if job.cost_breakdown:
                    total_cost += sum(job.cost_breakdown.values())
            
            # Performance analysis
            avg_duration = None
            successful_durations = []
            for job in recent_jobs:
                if job.status == "completed" and job.started_at and job.completed_at:
                    duration = (job.completed_at - job.started_at).total_seconds()
                    successful_durations.append(duration)
            
            if successful_durations:
                avg_duration = sum(successful_durations) / len(successful_durations)
            
            # Domain and task analysis
            domain_counts = {}
            task_counts = {}
            for job in recent_jobs:
                domain_counts[job.domain] = domain_counts.get(job.domain, 0) + 1
                task_counts[job.task_type] = task_counts.get(job.task_type, 0) + 1
            
            return {
                "summary": {
                    "total_jobs": total_jobs,
                    "completed_jobs": completed_jobs,
                    "failed_jobs": failed_jobs,
                    "success_rate": completed_jobs / total_jobs if total_jobs > 0 else 0,
                    "total_cost_usd": total_cost,
                    "average_cost_per_job": total_cost / total_jobs if total_jobs > 0 else 0,
                    "average_duration_seconds": avg_duration
                },
                "breakdown": {
                    "domains": domain_counts,
                    "tasks": task_counts
                },
                "time_range_days": time_range_days,
                "manager_stats": self._stats
            }
            
        except Exception as e:
            logger.error(f"Failed to get training analytics: {e}")
            return {"error": str(e)}
    
    async def get_system_health(self) -> Dict[str, Any]:
        """Get comprehensive system health status"""
        
        try:
            # Storage health
            storage_stats = self.storage.get_statistics()
            
            # Core integration health
            integration_status = {}
            if self.core_integration:
                integration_status = self.core_integration.get_integration_status()
            
            # Cache performance
            cache_performance = {
                "cache_size": len(self._cache),
                "cache_hit_rate": self._stats["cache_hits"] / (self._stats["cache_hits"] + self._stats["cache_misses"]) if (self._stats["cache_hits"] + self._stats["cache_misses"]) > 0 else 0,
                "cache_hits": self._stats["cache_hits"],
                "cache_misses": self._stats["cache_misses"]
            }
            
            # Error rate
            error_rate = self._stats["errors_count"] / self._stats["operations_count"] if self._stats["operations_count"] > 0 else 0
            
            return {
                "status": "healthy" if error_rate < 0.05 else "degraded" if error_rate < 0.2 else "unhealthy",
                "storage": storage_stats,
                "core_integration": integration_status,
                "cache_performance": cache_performance,
                "error_rate": error_rate,
                "operations_count": self._stats["operations_count"],
                "last_backup": self._stats["last_backup"]
            }
            
        except Exception as e:
            logger.error(f"Failed to get system health: {e}")
            return {"status": "unhealthy", "error": str(e)}
    
    # ====================== Management Operations ======================
    
    async def cleanup_old_data(
        self,
        days: int = 90,
        dry_run: bool = True,
        keep_successful: bool = True
    ) -> Dict[str, Any]:
        """Intelligent cleanup of old training data"""
        
        try:
            cleanup_result = self.repository.cleanup_old_jobs(days=days, dry_run=dry_run)
            
            # Clear cache for deleted jobs
            if not dry_run and "deleted_jobs" in cleanup_result:
                for job_info in cleanup_result["deleted_jobs"]:
                    job_id = job_info["job_id"]
                    self._invalidate_cache(f"job:{job_id}")
                    self._invalidate_cache(f"progress:{job_id}")
            
            return cleanup_result
            
        except Exception as e:
            logger.error(f"Failed to cleanup old data: {e}")
            return {"error": str(e)}
    
    async def backup_data(self, backup_path: Optional[str] = None) -> bool:
        """Create backup of all training data"""
        
        try:
            if not backup_path:
                backup_path = f"./training_backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
            
            backup_dir = Path(backup_path)
            backup_dir.mkdir(exist_ok=True)
            
            # Get all jobs and metrics
            all_jobs = await self.list_jobs(limit=10000)
            
            backup_data = {
                "timestamp": datetime.now().isoformat(),
                "job_count": len(all_jobs),
                "jobs": [job.to_dict() for job in all_jobs],
                "manager_stats": self._stats,
                "config": asdict(self.config)
            }
            
            # Write backup
            import json
            with open(backup_dir / "training_backup.json", "w") as f:
                json.dump(backup_data, f, indent=2, default=str)
            
            self._stats["last_backup"] = datetime.now().isoformat()
            
            logger.info(f"Successfully backed up {len(all_jobs)} training jobs to {backup_path}")
            return True
            
        except Exception as e:
            logger.error(f"Failed to backup data: {e}")
            return False
    
    # ====================== Internal Methods ======================
    
    def _get_from_cache(self, key: str) -> Any:
        """Get item from cache with TTL check"""
        if key not in self._cache:
            return None
        
        # Check TTL
        if key in self._cache_timestamps:
            age_minutes = (datetime.now() - self._cache_timestamps[key]).total_seconds() / 60
            if age_minutes > self.config.cache_ttl_minutes:
                self._invalidate_cache(key)
                return None
        
        return self._cache[key]
    
    def _update_cache(self, key: str, value: Any) -> None:
        """Update cache with size management"""
        # Manage cache size
        if len(self._cache) >= self.config.cache_size:
            # Remove oldest entries
            oldest_key = min(self._cache_timestamps.keys(), 
                           key=lambda k: self._cache_timestamps[k])
            self._invalidate_cache(oldest_key)
        
        self._cache[key] = value
        self._cache_timestamps[key] = datetime.now()
    
    def _invalidate_cache(self, key: str) -> None:
        """Remove item from cache"""
        self._cache.pop(key, None)
        self._cache_timestamps.pop(key, None)
    
    async def _process_operation_queue(self):
        """Process background operations"""
        while True:
            try:
                if self._operation_queue and not self._operation_queue.empty():
                    operation = await self._operation_queue.get()
                    await operation()
                else:
                    await asyncio.sleep(1)  # Wait if queue is empty
            except Exception as e:
                logger.error(f"Error processing operation queue: {e}")
                await asyncio.sleep(5)  # Wait longer on error
    
    async def _periodic_backup(self):
        """Periodic backup task"""
        while True:
            try:
                await asyncio.sleep(self.config.backup_interval_hours * 3600)
                await self.backup_data()
            except Exception as e:
                logger.error(f"Error in periodic backup: {e}")
    
    def __del__(self):
        """Cleanup on destruction"""
        logger.info("Unified Training Manager shutting down")


# Factory function for easy setup
async def create_training_manager(
    config: Optional[UnifiedTrainingConfig] = None,
    initialize: bool = True
) -> UnifiedTrainingManager:
    """Factory function to create and initialize training manager"""
    
    manager = UnifiedTrainingManager(config)
    
    if initialize:
        success = await manager.initialize()
        if not success:
            logger.warning("Training manager initialization had issues")
    
    return manager


# Convenience functions for common operations
async def quick_start_training(
    job_name: str,
    base_model: str,
    task_type: str,
    dataset_path: str,
    **kwargs
) -> str:
    """Quick start a training job with minimal configuration"""
    
    manager = await create_training_manager()
    
    return await manager.create_training_job(
        job_name=job_name,
        base_model=base_model,
        task_type=task_type,
        domain=kwargs.get("domain", "general"),
        dataset_source=dataset_path,
        training_config=kwargs.get("training_config", {"epochs": 3}),
        **kwargs
    )


async def get_training_dashboard() -> Dict[str, Any]:
    """Get comprehensive training dashboard data"""
    
    manager = await create_training_manager()
    
    # Get analytics and health data
    analytics = await manager.get_training_analytics()
    health = await manager.get_system_health()
    recent_jobs = await manager.list_jobs(limit=20)
    
    return {
        "analytics": analytics,
        "health": health,
        "recent_jobs": [
            {
                "job_id": job.job_id,
                "job_name": job.job_name,
                "status": job.status,
                "task_type": job.task_type,
                "domain": job.domain,
                "created_at": job.created_at.isoformat(),
                "progress": await manager.get_job_progress(job.job_id)
            }
            for job in recent_jobs
        ]
    }