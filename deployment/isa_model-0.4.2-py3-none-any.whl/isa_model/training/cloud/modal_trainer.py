"""
ISA Model Training Service on Modal

Modal-based training service for ISA Model SDK that provides:
- GPU-accelerated training on Modal cloud infrastructure
- Support for basic training, LlamaFactory integration, and custom scenarios
- Automatic resource scaling and cost optimization
"""

import modal
import os
import json
import logging
import tempfile
import subprocess
from typing import Dict, List, Optional, Any, Union
from pathlib import Path
from datetime import datetime

# Define Modal application
app = modal.App("isa-training-service")

# Define lightweight Modal container image for fast startup
training_image = (
    modal.Image.debian_slim(python_version="3.10")
    .pip_install([
        "torch>=2.0.0",
        "transformers>=4.36.0", 
        "datasets>=2.14.0",
        "accelerate>=0.24.0",
        "peft>=0.7.0",
        "bitsandbytes>=0.41.0",
        "numpy",
        "pandas",
        "tqdm"
    ])
    .apt_install(["git"])
)

# Modal volumes for persistent storage
training_volume = modal.Volume.from_name("isa-training-data", create_if_missing=True)
model_volume = modal.Volume.from_name("isa-models", create_if_missing=True)

@app.function(
    image=training_image,
    gpu="A10G",  # 使用A10G更经济
    volumes={
        "/training_data": training_volume,
        "/models": model_volume
    },
    timeout=3600,  # 1 hour timeout for quick tests
    retries=1
)
def train_basic_model(
    model_name: str,
    dataset_path: str,
    training_config: Dict[str, Any],
    output_path: str = "/models/output"
) -> Dict[str, Any]:
    """
    Train a model using basic ISA training (HuggingFace + LoRA).
    
    Args:
        model_name: Model identifier
        dataset_path: Path to training dataset
        training_config: Training configuration
        output_path: Output path for trained model
        
    Returns:
        Training results
    """
    import sys
    import os
    sys.path.append('/training_data')
    
    try:
        # Setup logging
        logging.basicConfig(level=logging.INFO)
        logger = logging.getLogger(__name__)
        
        logger.info(f"Starting basic training: {model_name}")
        logger.info(f"Dataset: {dataset_path}")
        logger.info(f"Config: {training_config}")
        
        # Import ISA training components
        from isa_model.training.core.trainer import LLMTrainer
        from isa_model.training.core.config import TrainingConfig, LoRAConfig, DatasetConfig
        
        # Create training configuration
        lora_config = LoRAConfig(
            use_lora=training_config.get("use_lora", True),
            lora_rank=training_config.get("lora_rank", 8),
            lora_alpha=training_config.get("lora_alpha", 16)
        )
        
        dataset_config = DatasetConfig(
            dataset_path=dataset_path,
            dataset_format=training_config.get("dataset_format", "alpaca"),
            max_length=training_config.get("max_length", 1024),
            validation_split=training_config.get("validation_split", 0.1)
        )
        
        config = TrainingConfig(
            model_name=model_name,
            output_dir=output_path,
            training_type=training_config.get("training_type", "sft"),
            num_epochs=training_config.get("num_epochs", 3),
            batch_size=training_config.get("batch_size", 4),
            learning_rate=training_config.get("learning_rate", 2e-5),
            lora_config=lora_config,
            dataset_config=dataset_config
        )
        
        # Initialize and run trainer
        trainer = LLMTrainer(config)
        result_path = trainer.train()
        
        # Save training artifacts to volume
        training_volume.commit()
        model_volume.commit()
        
        # Track billing for training
        try:
            from isa_model.core.models.deployment_billing_tracker import track_deployment_usage
            
            # Calculate training duration
            training_hours = training_config.get("num_epochs", 3) * 0.1  # Estimate 0.1 hours per epoch for small models
            gpu_type = "a10g"  # Using A10G as specified in function decorator
            
            track_deployment_usage(
                model_id=model_name,
                provider="modal",
                operation_type="training",
                service_type="llm",
                operation="basic_training",
                gpu_type=gpu_type,
                gpu_count=1,
                runtime_hours=training_hours,
                training_epochs=training_config.get("num_epochs", 3),
                training_steps=training_config.get("max_steps", 1000),
                dataset_size=training_config.get("dataset_size", 10000),
                metadata={
                    "learning_rate": training_config.get("learning_rate", 2e-5),
                    "batch_size": training_config.get("batch_size", 4),
                    "use_lora": training_config.get("use_lora", True),
                    "framework": "transformers",
                    "training_type": "basic"
                }
            )
            logger.info(f"Training billing tracked: {gpu_type} for {training_hours} hours")
        except Exception as e:
            logger.warning(f"Failed to track training billing: {e}")
        
        logger.info(f"Training completed successfully: {result_path}")
        
        return {
            "status": "completed",
            "result_path": result_path,
            "model_name": model_name,
            "training_type": "basic",
            "config": training_config,
            "billing_tracked": True
        }
        
    except Exception as e:
        logger.error(f"Training failed: {e}")
        return {
            "status": "failed",
            "error": str(e),
            "model_name": model_name
        }

@app.function(
    image=training_image,
    gpu="A100-40GB",
    volumes={
        "/training_data": training_volume,
        "/models": model_volume
    },
    timeout=86400,
    retries=1
)
def train_with_llamafactory(
    model_name: str,
    dataset_path: str,
    training_stage: str,
    training_config: Dict[str, Any],
    output_path: str = "/models/llamafactory_output"
) -> Dict[str, Any]:
    """
    Train a model using LlamaFactory algorithms.
    
    Args:
        model_name: Model identifier
        dataset_path: Path to training dataset
        training_stage: LlamaFactory training stage (sft, dpo, ppo, etc.)
        training_config: Training configuration
        output_path: Output path for trained model
        
    Returns:
        Training results
    """
    import subprocess
    import tempfile
    import yaml
    
    try:
        logging.basicConfig(level=logging.INFO)
        logger = logging.getLogger(__name__)
        
        logger.info(f"Starting LlamaFactory {training_stage} training: {model_name}")
        
        # Create LlamaFactory configuration
        llamafactory_config = {
            "model_name": model_name,
            "stage": training_stage,
            "dataset": "custom_dataset",
            "output_dir": output_path,
            "num_train_epochs": training_config.get("num_epochs", 3),
            "per_device_train_batch_size": training_config.get("batch_size", 2),
            "learning_rate": training_config.get("learning_rate", 5e-5),
            "finetuning_type": "lora",
            "lora_rank": training_config.get("lora_rank", 8),
            "lora_alpha": training_config.get("lora_alpha", 16),
            "fp16": True,
            "logging_steps": 10,
            "save_steps": 500,
            "eval_steps": 500
        }
        
        # Create dataset configuration
        dataset_config = {
            "custom_dataset": {
                "file_name": dataset_path,
                "formatting": training_config.get("dataset_format", "alpaca")
            }
        }
        
        # Save configurations to temporary files
        with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as f:
            yaml.dump(llamafactory_config, f)
            config_path = f.name
        
        with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
            json.dump(dataset_config, f, indent=2)
            dataset_config_path = f.name
        
        # Execute LlamaFactory training
        cmd = [
            "llamafactory-cli", "train",
            "--config", config_path,
            "--dataset_info", dataset_config_path
        ]
        
        logger.info(f"Running command: {' '.join(cmd)}")
        result = subprocess.run(cmd, capture_output=True, text=True, check=True)
        
        # Clean up temporary files
        os.unlink(config_path)
        os.unlink(dataset_config_path)
        
        # Save training artifacts
        training_volume.commit()
        model_volume.commit()
        
        # Track billing for LlamaFactory training
        try:
            from isa_model.core.models.deployment_billing_tracker import track_deployment_usage
            
            # Calculate training duration based on epochs and complexity
            base_hours_per_epoch = 0.3 if training_stage in ["dpo", "ppo"] else 0.2  # More complex stages take longer
            training_hours = training_config.get("num_epochs", 3) * base_hours_per_epoch
            gpu_type = "a100_40gb"  # Using A100-40GB as specified in function decorator
            
            track_deployment_usage(
                model_id=model_name,
                provider="modal",
                operation_type="training",
                service_type="llm",
                operation="llamafactory_training",
                gpu_type=gpu_type,
                gpu_count=1,
                runtime_hours=training_hours,
                training_epochs=training_config.get("num_epochs", 3),
                training_steps=training_config.get("max_steps", 2000),
                dataset_size=training_config.get("dataset_size", 50000),
                metadata={
                    "learning_rate": training_config.get("learning_rate", 5e-5),
                    "batch_size": training_config.get("batch_size", 2),
                    "training_stage": training_stage,
                    "framework": "llamafactory",
                    "finetuning_type": "lora",
                    "lora_rank": training_config.get("lora_rank", 8)
                }
            )
            logger.info(f"LlamaFactory training billing tracked: {gpu_type} for {training_hours} hours")
        except Exception as e:
            logger.warning(f"Failed to track LlamaFactory training billing: {e}")
        
        logger.info("LlamaFactory training completed successfully")
        
        return {
            "status": "completed",
            "result_path": output_path,
            "model_name": model_name,
            "training_type": "llamafactory",
            "training_stage": training_stage,
            "config": training_config,
            "stdout": result.stdout,
            "stderr": result.stderr,
            "billing_tracked": True
        }
        
    except subprocess.CalledProcessError as e:
        logger.error(f"LlamaFactory training failed: {e}")
        return {
            "status": "failed",
            "error": f"LlamaFactory training failed: {e.stderr}",
            "model_name": model_name,
            "training_stage": training_stage
        }
    except Exception as e:
        logger.error(f"Training failed: {e}")
        return {
            "status": "failed",
            "error": str(e),
            "model_name": model_name
        }

@app.function(
    image=training_image,
    gpu="A100-40GB",
    volumes={
        "/training_data": training_volume,
        "/models": model_volume
    },
    timeout=86400,
    retries=1
)
def train_custom_scenario(
    scenario_type: str,
    base_model: str,
    data_sources: List[str],
    scenario_config: Dict[str, Any],
    output_path: str = "/models/custom_scenario_output"
) -> Dict[str, Any]:
    """
    Train using custom scenarios (multimodal, domain adaptation, etc.).
    
    Args:
        scenario_type: Type of custom scenario
        base_model: Base model to use
        data_sources: List of data source paths
        scenario_config: Scenario-specific configuration
        output_path: Output path for results
        
    Returns:
        Training results
    """
    import sys
    sys.path.append('/training_data')
    
    try:
        logging.basicConfig(level=logging.INFO)
        logger = logging.getLogger(__name__)
        
        logger.info(f"Starting custom scenario training: {scenario_type}")
        logger.info(f"Base model: {base_model}")
        logger.info(f"Data sources: {data_sources}")
        
        # Import custom scenario components
        from isa_model.training.enhanced.custom_scenarios import (
            CustomScenarioManager, 
            CustomTrainingConfig
        )
        
        # Create custom training configuration
        config = CustomTrainingConfig(
            scenario_type=scenario_type,
            base_model=base_model,
            output_dir=output_path,
            scenario_params=scenario_config
        )
        
        # Initialize scenario manager and run training
        manager = CustomScenarioManager()
        result = manager.run_scenario(scenario_type, config, data_sources)
        
        # Save training artifacts
        training_volume.commit()
        model_volume.commit()
        
        # Track billing for custom scenario training
        try:
            from isa_model.core.models.deployment_billing_tracker import track_deployment_usage
            
            # Calculate training duration based on scenario complexity
            scenario_multiplier = {
                "multimodal": 1.5,      # More complex, needs more time
                "domain_adaptation": 1.2,
                "few_shot": 0.8,
                "reinforcement": 2.0,   # Most complex
                "default": 1.0
            }
            
            multiplier = scenario_multiplier.get(scenario_type, scenario_multiplier["default"])
            base_hours = scenario_config.get("num_epochs", 5) * 0.25  # 0.25 hours per epoch base
            training_hours = base_hours * multiplier
            gpu_type = "a100_40gb"  # Using A100-40GB as specified in function decorator
            
            track_deployment_usage(
                model_id=f"{base_model}-{scenario_type}",
                provider="modal",
                operation_type="training",
                service_type="llm",
                operation="custom_scenario_training",
                gpu_type=gpu_type,
                gpu_count=1,
                runtime_hours=training_hours,
                training_epochs=scenario_config.get("num_epochs", 5),
                training_steps=scenario_config.get("max_steps", 3000),
                dataset_size=len(data_sources) * 10000,  # Estimate based on data sources
                metadata={
                    "scenario_type": scenario_type,
                    "base_model": base_model,
                    "data_sources_count": len(data_sources),
                    "modalities": scenario_config.get("modalities", ["text"]),
                    "fusion_strategy": scenario_config.get("fusion_strategy", "late_fusion"),
                    "framework": "custom_scenarios",
                    "complexity_multiplier": multiplier
                }
            )
            logger.info(f"Custom scenario training billing tracked: {gpu_type} for {training_hours} hours")
        except Exception as e:
            logger.warning(f"Failed to track custom scenario training billing: {e}")
        
        logger.info(f"Custom scenario training completed: {scenario_type}")
        
        return {
            "status": "completed",
            "result": result,
            "scenario_type": scenario_type,
            "base_model": base_model,
            "training_type": "custom_scenario",
            "output_path": output_path,
            "billing_tracked": True
        }
        
    except Exception as e:
        logger.error(f"Custom scenario training failed: {e}")
        return {
            "status": "failed",
            "error": str(e),
            "scenario_type": scenario_type,
            "base_model": base_model
        }

@app.function(
    image=training_image,
    volumes={
        "/training_data": training_volume,
        "/models": model_volume
    }
)
def list_available_models() -> List[str]:
    """List available models in the model volume."""
    models = []
    model_dir = Path("/models")
    if model_dir.exists():
        for item in model_dir.iterdir():
            if item.is_dir():
                models.append(str(item.name))
    return models

@app.function(
    image=training_image,
    volumes={
        "/training_data": training_volume,
        "/models": model_volume
    }
)
def get_training_status(job_id: str) -> Dict[str, Any]:
    """Get status of a training job."""
    # This would integrate with actual job tracking
    return {
        "job_id": job_id,
        "status": "running",
        "progress": 75.5,
        "estimated_completion": "2024-01-01T12:00:00Z"
    }

# Local client class for easy interaction
class ModalTrainingClient:
    """Client for interacting with Modal training services."""
    
    def __init__(self):
        self.app = app
        
    def estimate_training_cost(
        self,
        training_type: str = "basic",
        gpu_type: str = "a10g",
        num_epochs: int = 3,
        training_stage: str = "sft",
        scenario_type: str = "default"
    ) -> Dict[str, Any]:
        """Estimate training costs before starting training."""
        try:
            from isa_model.core.models.deployment_billing_tracker import get_deployment_billing_tracker
            
            # Calculate estimated hours based on training type
            if training_type == "basic":
                estimated_hours = num_epochs * 0.1  # 0.1 hours per epoch for basic
                gpu_type = "a10g"  # Basic training uses A10G
            elif training_type == "llamafactory":
                estimated_hours = num_epochs * 0.2  # More complex
                gpu_type = "a100_40gb"  # LlamaFactory uses A100
            else:  # custom_scenario
                scenario_multiplier = {
                    "multimodal": 1.5,
                    "domain_adaptation": 1.2,
                    "few_shot": 0.8,
                    "reinforcement": 2.0,
                    "default": 1.0
                }
                multiplier = scenario_multiplier.get(scenario_type, 1.0)
                estimated_hours = num_epochs * 0.25 * multiplier
                gpu_type = "a100_40gb"  # Custom scenarios use A100
            
            billing_tracker = get_deployment_billing_tracker()
            cost_estimate = billing_tracker.estimate_deployment_cost(
                provider="modal",
                gpu_type=gpu_type,
                gpu_count=1,
                estimated_hours=estimated_hours,
                operation_type="training"
            )
            
            return {
                "success": True,
                "training_type": training_type,
                "gpu_type": gpu_type,
                "estimated_hours": estimated_hours,
                "num_epochs": num_epochs,
                "cost_estimate": cost_estimate,
                "hourly_rate": cost_estimate["compute_cost"] / estimated_hours if estimated_hours > 0 else 0
            }
            
        except Exception as e:
            return {
                "success": False,
                "error": str(e)
            }
    
    def train_basic_model(
        self,
        model_name: str,
        dataset_path: str,
        **training_params
    ) -> Dict[str, Any]:
        """Train a model using basic ISA training."""
        # Add cost estimation info to training params
        cost_estimate = self.estimate_training_cost(
            training_type="basic",
            num_epochs=training_params.get("num_epochs", 3)
        )
        training_params["cost_estimate"] = cost_estimate
        
        return train_basic_model.remote(
            model_name=model_name,
            dataset_path=dataset_path,
            training_config=training_params
        )
    
    def train_with_llamafactory(
        self,
        model_name: str,
        dataset_path: str,
        training_stage: str = "sft",
        **training_params
    ) -> Dict[str, Any]:
        """Train a model using LlamaFactory."""
        # Add cost estimation info to training params
        cost_estimate = self.estimate_training_cost(
            training_type="llamafactory",
            num_epochs=training_params.get("num_epochs", 3),
            training_stage=training_stage
        )
        training_params["cost_estimate"] = cost_estimate
        
        return train_with_llamafactory.remote(
            model_name=model_name,
            dataset_path=dataset_path,
            training_stage=training_stage,
            training_config=training_params
        )
    
    def train_custom_scenario(
        self,
        scenario_type: str,
        base_model: str,
        data_sources: List[str],
        **scenario_params
    ) -> Dict[str, Any]:
        """Train using custom scenarios."""
        # Add cost estimation info to scenario params
        cost_estimate = self.estimate_training_cost(
            training_type="custom_scenario",
            num_epochs=scenario_params.get("num_epochs", 5),
            scenario_type=scenario_type
        )
        scenario_params["cost_estimate"] = cost_estimate
        
        return train_custom_scenario.remote(
            scenario_type=scenario_type,
            base_model=base_model,
            data_sources=data_sources,
            scenario_config=scenario_params
        )
    
    def list_models(self) -> List[str]:
        """List available trained models."""
        return list_available_models.remote()
    
    def get_status(self, job_id: str) -> Dict[str, Any]:
        """Get training job status."""
        return get_training_status.remote(job_id)

if __name__ == "__main__":
    # Example usage
    client = ModalTrainingClient()
    
    # Test basic training
    result = client.train_basic_model(
        model_name="TinyLlama/TinyLlama-1.1B-Chat-v1.0",
        dataset_path="tatsu-lab/alpaca",
        num_epochs=1,
        batch_size=2,
        use_lora=True
    )
    print(f"Basic training result: {result}")