from typing import Dict, Any, List, Optional
from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel
import logging
from isa_model.training.annotation.views.annotation_controller import AnnotationController
from isa_model.training.annotation.processors.annotation_processor import AnnotationProcessor
from isa_model.training.annotation.annotation_schema import AnnotationFeedback, RatingScale, AnnotationAspects, BetterResponse
from isa_model.training.annotation.storage.dataset_manager import DatasetManager

router = APIRouter()
logger = logging.getLogger(__name__)

annotation_controller = AnnotationController()
annotation_processor = AnnotationProcessor()
dataset_manager = DatasetManager()


class AnnotationSubmitRequest(BaseModel):
    annotation_id: str
    item_id: str
    feedback: AnnotationFeedback
    annotator_id: str


class AnnotationFilterParams(BaseModel):
    project_name: str
    category: Optional[str] = None
    min_rating: Optional[int] = None
    page: int = 1
    limit: int = 10


@router.get("/pending")
async def get_pending_annotations(
    project_name: str = Query(..., description="Project name"),
    category: Optional[str] = Query(None, description="Filter by category"),
    min_rating: Optional[int] = Query(None, description="Minimum rating filter"),
    page: int = Query(1, ge=1, description="Page number"),
    limit: int = Query(10, ge=1, le=100, description="Items per page")
) -> Dict[str, Any]:
    """Get filtered list of pending annotations"""
    try:
        result = await annotation_controller.get_pending_annotations(
            project_name=project_name,
            category=category,
            min_rating=min_rating,
            page=page,
            limit=limit
        )
        return result
    except Exception as e:
        logger.error(f"Error fetching pending annotations: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/submit")
async def submit_annotation(request: AnnotationSubmitRequest) -> Dict[str, Any]:
    """Submit annotation feedback"""
    try:
        result = await annotation_controller.submit_annotation(
            annotation_id=request.annotation_id,
            item_id=request.item_id,
            feedback=request.feedback,
            annotator_id=request.annotator_id
        )
        return result
    except Exception as e:
        logger.error(f"Error submitting annotation: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/process-queue")
async def process_annotation_queue() -> Dict[str, Any]:
    """Process pending annotations to create training datasets"""
    try:
        results = await annotation_processor.process_queue()
        return {
            "status": "success", 
            "message": "Annotation queue processed successfully",
            "sft_processed": results.get("sft_processed", 0),
            "rlhf_processed": results.get("rlhf_processed", 0),
            "errors": results.get("errors", [])
        }
    except Exception as e:
        logger.error(f"Error processing annotation queue: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/training-data/{data_type}")
async def get_training_data(
    data_type: str,
    limit: int = Query(1000, ge=1, le=10000, description="Number of items to retrieve")
) -> List[Dict[str, Any]]:
    """Retrieve formatted training data"""
    try:
        if data_type not in ["sft", "rlhf"]:
            raise HTTPException(status_code=400, detail="Invalid data type. Must be 'sft' or 'rlhf'")
        
        data = await annotation_processor.get_training_data(
            data_type=data_type,
            limit=limit
        )
        return data
    except Exception as e:
        logger.error(f"Error retrieving training data: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/datasets/{dataset_id}")
async def get_dataset_info(dataset_id: str) -> Dict[str, Any]:
    """Get information about a specific dataset"""
    try:
        info = await dataset_manager.get_dataset_info(dataset_id)
        if not info:
            raise HTTPException(status_code=404, detail="Dataset not found")
        return info
    except Exception as e:
        logger.error(f"Error retrieving dataset info: {e}")
        raise HTTPException(status_code=500, detail=str(e))


class CreateDatasetRequest(BaseModel):
    name: str
    dataset_type: str
    version: str
    source_annotations: List[str]

@router.post("/datasets/create")
async def create_dataset(request: CreateDatasetRequest) -> Dict[str, Any]:
    """Create a new dataset"""
    try:
        if request.dataset_type not in ["sft", "rlhf"]:
            raise HTTPException(status_code=400, detail="Invalid dataset type. Must be 'sft' or 'rlhf'")
        
        dataset = await dataset_manager.create_dataset(
            name=request.name,
            type=request.dataset_type,
            version=request.version,
            source_annotations=request.source_annotations
        )
        
        return {
            "status": "success",
            "dataset_id": str(dataset.id),
            "message": "Dataset created successfully"
        }
    except Exception as e:
        logger.error(f"Error creating dataset: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/health")
async def annotation_health_check() -> Dict[str, str]:
    """Health check for annotation service"""
    return {"status": "healthy", "service": "annotation"}