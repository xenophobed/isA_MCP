"""
Training Billing API Routes

API endpoints for training cost estimation, tracking, and billing information.
"""

from fastapi import APIRouter, HTTPException, Query, Depends
from typing import Dict, Any, Optional, List
from datetime import datetime, timedelta
import logging
from pydantic import BaseModel

from ..auth import optional_auth

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/training", tags=["training-billing"])


class TrainingCostEstimationRequest(BaseModel):
    """Request model for training cost estimation"""
    training_type: str = "basic"  # basic, llamafactory, custom_scenario
    model_name: str
    num_epochs: int = 3
    batch_size: int = 4
    gpu_type: Optional[str] = None  # Auto-select if not specified
    training_stage: Optional[str] = "sft"  # For llamafactory
    scenario_type: Optional[str] = "default"  # For custom scenarios
    dataset_size: Optional[int] = 10000


class TrainingJobRequest(BaseModel):
    """Request model for training job submission with billing tracking"""
    training_type: str
    model_name: str
    dataset_path: str
    config: Dict[str, Any]
    estimate_only: bool = False


@router.post("/estimate-cost")
async def estimate_training_cost(
    request: TrainingCostEstimationRequest,
    user = Depends(optional_auth)
):
    """
    Estimate training costs before starting training job
    
    Returns detailed cost breakdown for different training types.
    """
    try:
        from isa_model.training.cloud.modal_trainer import ModalTrainingClient
        
        client = ModalTrainingClient()
        cost_estimate = client.estimate_training_cost(
            training_type=request.training_type,
            num_epochs=request.num_epochs,
            training_stage=request.training_stage,
            scenario_type=request.scenario_type
        )
        
        if not cost_estimate["success"]:
            raise HTTPException(status_code=500, detail=cost_estimate["error"])
        
        # Add additional context
        recommendations = _get_training_recommendations(
            request.training_type, 
            cost_estimate["gpu_type"],
            cost_estimate["estimated_hours"],
            cost_estimate["cost_estimate"]["total_cost"]
        )
        
        return {
            "success": True,
            "estimation": {
                "training_type": request.training_type,
                "model_name": request.model_name,
                "gpu_type": cost_estimate["gpu_type"],
                "estimated_hours": cost_estimate["estimated_hours"],
                "num_epochs": request.num_epochs,
                "cost_breakdown": cost_estimate["cost_estimate"],
                "hourly_rate": cost_estimate["hourly_rate"],
                "recommendations": recommendations,
                "dataset_context": {
                    "estimated_size": request.dataset_size,
                    "batch_size": request.batch_size,
                    "estimated_steps": (request.dataset_size // request.batch_size) * request.num_epochs if request.dataset_size else None
                }
            }
        }
        
    except Exception as e:
        logger.error(f"Failed to estimate training cost: {e}")
        raise HTTPException(status_code=500, detail=f"Training cost estimation failed: {str(e)}")


@router.get("/billing/summary")
async def get_training_billing_summary(
    start_date: Optional[str] = Query(None, description="Start date (ISO format)"),
    end_date: Optional[str] = Query(None, description="End date (ISO format)"),
    training_type: Optional[str] = Query(None, description="Filter by training type"),
    model_id: Optional[str] = Query(None, description="Filter by model ID"),
    user = Depends(optional_auth)
):
    """
    Get training billing summary with optional filters
    
    Returns comprehensive billing information for training jobs.
    """
    try:
        from isa_model.core.models.deployment_billing_tracker import get_deployment_billing_tracker
        
        # Parse dates
        start_dt = None
        end_dt = None
        if start_date:
            start_dt = datetime.fromisoformat(start_date.replace('Z', '+00:00'))
        if end_date:
            end_dt = datetime.fromisoformat(end_date.replace('Z', '+00:00'))
        
        billing_tracker = get_deployment_billing_tracker()
        
        # Filter for training operations only
        all_records = billing_tracker.usage_records
        training_records = [
            record for record in all_records 
            if record.operation_type == "training"
        ]
        
        # Apply filters
        if start_dt:
            training_records = [r for r in training_records if r.timestamp >= start_dt]
        if end_dt:
            training_records = [r for r in training_records if r.timestamp <= end_dt]
        if training_type and hasattr(training_records[0], 'metadata'):
            training_records = [
                r for r in training_records 
                if r.metadata and r.metadata.get('training_type') == training_type
            ]
        if model_id:
            training_records = [r for r in training_records if r.model_id == model_id]
        
        # Calculate summary
        total_cost = sum(record.cost_usd for record in training_records)
        total_gpu_hours = sum(getattr(record, 'runtime_hours', 0) for record in training_records)
        total_epochs = sum(getattr(record, 'training_epochs', 0) for record in training_records)
        total_steps = sum(getattr(record, 'training_steps', 0) for record in training_records)
        
        # Group by training type
        by_training_type = {}
        for record in training_records:
            training_type_key = record.metadata.get('training_type', 'unknown') if record.metadata else 'unknown'
            if training_type_key not in by_training_type:
                by_training_type[training_type_key] = {
                    "cost": 0.0,
                    "gpu_hours": 0.0,
                    "epochs": 0,
                    "steps": 0,
                    "count": 0
                }
            by_training_type[training_type_key]["cost"] += record.cost_usd
            by_training_type[training_type_key]["gpu_hours"] += getattr(record, 'runtime_hours', 0)
            by_training_type[training_type_key]["epochs"] += getattr(record, 'training_epochs', 0)
            by_training_type[training_type_key]["steps"] += getattr(record, 'training_steps', 0)
            by_training_type[training_type_key]["count"] += 1
        
        # Group by GPU type
        by_gpu_type = {}
        for record in training_records:
            gpu_type = getattr(record, 'gpu_type', 'unknown')
            if gpu_type not in by_gpu_type:
                by_gpu_type[gpu_type] = {
                    "cost": 0.0,
                    "gpu_hours": 0.0,
                    "count": 0
                }
            by_gpu_type[gpu_type]["cost"] += record.cost_usd
            by_gpu_type[gpu_type]["gpu_hours"] += getattr(record, 'runtime_hours', 0)
            by_gpu_type[gpu_type]["count"] += 1
        
        return {
            "success": True,
            "filters": {
                "start_date": start_date,
                "end_date": end_date,
                "training_type": training_type,
                "model_id": model_id
            },
            "training_summary": {
                "total_cost": round(total_cost, 6),
                "total_gpu_hours": round(total_gpu_hours, 4),
                "total_epochs": total_epochs,
                "total_steps": total_steps,
                "training_jobs": len(training_records),
                "avg_cost_per_job": round(total_cost / len(training_records), 6) if training_records else 0,
                "avg_cost_per_gpu_hour": round(total_cost / total_gpu_hours, 4) if total_gpu_hours > 0 else 0,
                "by_training_type": by_training_type,
                "by_gpu_type": by_gpu_type
            },
            "recommendations": _get_training_billing_recommendations(by_training_type, by_gpu_type, total_cost)
        }
        
    except Exception as e:
        logger.error(f"Failed to get training billing summary: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to get training billing summary: {str(e)}")


@router.post("/submit")
async def submit_training_job(
    request: TrainingJobRequest,
    user = Depends(optional_auth)
):
    """
    Submit a training job with automatic cost tracking
    
    Returns job ID and cost information.
    """
    try:
        from isa_model.training.cloud.modal_trainer import ModalTrainingClient
        
        client = ModalTrainingClient()
        
        # If estimate_only, just return cost estimate
        if request.estimate_only:
            cost_estimate = client.estimate_training_cost(
                training_type=request.training_type,
                num_epochs=request.config.get("num_epochs", 3)
            )
            return {
                "success": True,
                "estimate_only": True,
                "cost_estimate": cost_estimate
            }
        
        # Submit actual training job
        if request.training_type == "basic":
            result = client.train_basic_model(
                model_name=request.model_name,
                dataset_path=request.dataset_path,
                **request.config
            )
        elif request.training_type == "llamafactory":
            result = client.train_with_llamafactory(
                model_name=request.model_name,
                dataset_path=request.dataset_path,
                training_stage=request.config.get("training_stage", "sft"),
                **{k: v for k, v in request.config.items() if k != "training_stage"}
            )
        elif request.training_type == "custom_scenario":
            result = client.train_custom_scenario(
                scenario_type=request.config.get("scenario_type", "default"),
                base_model=request.model_name,
                data_sources=request.config.get("data_sources", [request.dataset_path]),
                **{k: v for k, v in request.config.items() if k not in ["scenario_type", "data_sources"]}
            )
        else:
            raise ValueError(f"Unsupported training type: {request.training_type}")
        
        return {
            "success": True,
            "training_result": result,
            "billing_tracked": result.get("billing_tracked", False)
        }
        
    except Exception as e:
        logger.error(f"Failed to submit training job: {e}")
        raise HTTPException(status_code=500, detail=f"Training job submission failed: {str(e)}")


@router.get("/gpu-pricing")
async def get_training_gpu_pricing(
    user = Depends(optional_auth)
):
    """
    Get GPU pricing specifically for training workloads
    
    Returns optimized GPU recommendations for different training scenarios.
    """
    try:
        from isa_model.core.models.deployment_billing_tracker import get_deployment_billing_tracker
        
        billing_tracker = get_deployment_billing_tracker()
        pricing_data = billing_tracker.pricing_data.get("modal", {})
        
        # Add training-specific context
        training_recommendations = {
            "basic_training": {
                "recommended_gpu": "a10g",
                "hourly_rate": pricing_data.get("a10g", 1.0),
                "description": "Cost-effective for small models and LoRA fine-tuning",
                "max_model_size": "7B parameters",
                "typical_epochs": "3-5"
            },
            "llamafactory_training": {
                "recommended_gpu": "a100_40gb", 
                "hourly_rate": pricing_data.get("a100_40gb", 2.5),
                "description": "Balanced performance for advanced training algorithms",
                "max_model_size": "13B parameters",
                "typical_epochs": "3-10"
            },
            "custom_scenario_training": {
                "recommended_gpu": "a100_40gb",
                "hourly_rate": pricing_data.get("a100_40gb", 2.5),
                "description": "Flexible GPU for complex custom training scenarios",
                "max_model_size": "30B parameters", 
                "typical_epochs": "5-20"
            },
            "large_model_training": {
                "recommended_gpu": "a100_80gb",
                "hourly_rate": pricing_data.get("a100_80gb", 4.0),
                "description": "High-memory GPU for large model training",
                "max_model_size": "70B+ parameters",
                "typical_epochs": "1-5"
            }
        }
        
        return {
            "success": True,
            "training_gpu_pricing": training_recommendations,
            "currency": "USD",
            "unit": "per hour",
            "provider": "modal",
            "last_updated": datetime.now().isoformat()
        }
        
    except Exception as e:
        logger.error(f"Failed to get training GPU pricing: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to get training GPU pricing: {str(e)}")


def _get_training_recommendations(training_type: str, gpu_type: str, estimated_hours: float, total_cost: float) -> List[str]:
    """Generate training-specific cost optimization recommendations"""
    recommendations = []
    
    if total_cost > 5.0:
        recommendations.append("Consider using smaller models or fewer epochs for development/testing")
    
    if training_type == "basic" and gpu_type != "a10g":
        recommendations.append("Basic training can typically run on A10G for significant cost savings")
    
    if estimated_hours > 2.0 and training_type == "basic":
        recommendations.append("Long basic training - consider using LoRA for faster convergence")
    
    if training_type == "llamafactory" and estimated_hours > 8.0:
        recommendations.append("Extended LlamaFactory training - monitor progress and consider early stopping")
    
    if gpu_type in ["a100_80gb", "h100"] and training_type == "basic":
        recommendations.append("High-end GPU for basic training - consider downgrading to A100-40GB or A10G")
    
    return recommendations


def _get_training_billing_recommendations(by_training_type: Dict, by_gpu_type: Dict, total_cost: float) -> List[str]:
    """Generate billing optimization recommendations based on training usage patterns"""
    recommendations = []
    
    if total_cost > 50.0:
        recommendations.append("High training costs detected - consider implementing cost alerts and budgets")
    
    # Analyze training type distribution
    if "basic" in by_training_type and by_training_type["basic"]["cost"] > 20.0:
        recommendations.append("High basic training costs - consider batch processing multiple models")
    
    # Analyze GPU usage efficiency
    gpu_costs = [(gpu, data["cost"]) for gpu, data in by_gpu_type.items()]
    gpu_costs.sort(key=lambda x: x[1], reverse=True)
    
    if len(gpu_costs) > 1 and gpu_costs[0][1] > gpu_costs[1][1] * 3:
        recommendations.append(f"Heavy usage of {gpu_costs[0][0]} - evaluate if cheaper GPUs could handle some workloads")
    
    # Check for training efficiency
    for training_type, data in by_training_type.items():
        if data["count"] > 5 and data["cost"] / data["count"] > 2.0:
            recommendations.append(f"High average cost per {training_type} job - optimize training parameters")
    
    return recommendations