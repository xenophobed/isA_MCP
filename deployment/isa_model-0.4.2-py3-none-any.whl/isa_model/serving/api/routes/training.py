"""
Training API Routes

Provides comprehensive training management capabilities including:
- Training job lifecycle management
- Intelligent training optimization
- Dataset management
- Cloud training orchestration
- Training metrics and monitoring
"""

from fastapi import APIRouter, HTTPException, Query, Depends, BackgroundTasks
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, Field
from typing import Optional, List, Dict, Any, Union
import logging
from datetime import datetime
import asyncio
import json
import uuid

try:
    from ..middleware.auth import optional_auth, require_read_access, require_write_access
    from ..dependencies.auth import get_current_user, get_current_organization
    from ..middleware.tenant_context import get_tenant_context
except ImportError:
    # For development/testing when auth is not required
    def optional_auth():
        return {"user_id": "test_user"}
    
    def require_read_access():
        return {"user_id": "test_user"}
    
    def require_write_access():
        return {"user_id": "test_user"}
        
    def get_current_user():
        return None
        
    def get_current_organization():
        return None

# Import training modules
from isa_model.training.factory import TrainingFactory
from isa_model.training.storage.training_repository import TrainingRepository
from isa_model.training.intelligent.intelligent_factory import IntelligentTrainingFactory
from isa_model.training.cloud.job_orchestrator import TrainingJobOrchestrator

logger = logging.getLogger(__name__)
router = APIRouter()

# Request/Response Models
class TrainingJobRequest(BaseModel):
    """Request model for creating a training job"""
    job_name: str = Field(..., description="Human-readable job name")
    base_model: str = Field(..., description="Base model identifier (e.g., 'google/gemma-2-4b-it')")
    task_type: str = Field(..., description="Type of training task (e.g., 'sft', 'rlhf')")
    domain: str = Field(..., description="Application domain (e.g., 'medical', 'finance')")
    dataset_source: str = Field(..., description="Dataset source path or identifier")
    training_config: Dict[str, Any] = Field(default_factory=dict, description="Training configuration parameters")
    resource_config: Optional[Dict[str, Any]] = Field(None, description="Resource configuration (GPU, cloud provider, etc.)")
    project_name: Optional[str] = Field(None, description="Project name")
    tags: Optional[Dict[str, str]] = Field(None, description="Additional tags")
    use_intelligent_optimization: bool = Field(False, description="Whether to use intelligent training optimization")

class LocalTrainingRequest(BaseModel):
    """Request model for local training"""
    model_name: str = Field(..., description="Model identifier")
    dataset_path: str = Field(..., description="Path to dataset or HuggingFace dataset name")
    output_dir: Optional[str] = Field(None, description="Custom output directory")
    training_type: str = Field("sft", description="Type of training")
    dataset_format: str = Field("alpaca", description="Dataset format")
    use_lora: bool = Field(True, description="Whether to use LoRA for efficient training")
    batch_size: int = Field(4, description="Training batch size")
    num_epochs: int = Field(3, description="Number of training epochs")
    learning_rate: float = Field(2e-5, description="Learning rate")
    max_length: int = Field(1024, description="Maximum sequence length")
    lora_rank: int = Field(8, description="LoRA rank parameter")
    lora_alpha: int = Field(16, description="LoRA alpha parameter")
    validation_split: float = Field(0.1, description="Fraction of data for validation")

class CloudTrainingRequest(BaseModel):
    """Request model for cloud training"""
    model_name: str = Field(..., description="Model identifier")
    dataset_path: str = Field(..., description="Dataset path or HuggingFace dataset name")
    runpod_api_key: str = Field(..., description="RunPod API key")
    template_id: str = Field(..., description="RunPod template ID")
    gpu_type: str = Field("NVIDIA RTX A6000", description="GPU type to use")
    storage_config: Optional[Dict[str, Any]] = Field(None, description="Cloud storage configuration")
    job_name: Optional[str] = Field(None, description="Optional job name")
    training_params: Dict[str, Any] = Field(default_factory=dict, description="Additional training parameters")

class JobStatusUpdate(BaseModel):
    """Request model for updating job status"""
    status: str = Field(..., description="New status ('pending', 'running', 'completed', 'failed', 'cancelled')")
    error_message: Optional[str] = Field(None, description="Error message if failed")
    additional_updates: Optional[Dict[str, Any]] = Field(None, description="Additional fields to update")

class TrainingMetricsRequest(BaseModel):
    """Request model for recording training metrics"""
    metrics_data: Dict[str, Any] = Field(..., description="Metrics data dictionary")

class IntelligentOptimizationRequest(BaseModel):
    """Request model for intelligent training optimization"""
    task_type: str = Field(..., description="Type of training task")
    domain: str = Field(..., description="Application domain")
    dataset_info: Dict[str, Any] = Field(..., description="Dataset information")
    resource_constraints: Optional[Dict[str, Any]] = Field(None, description="Resource constraints")
    performance_targets: Optional[Dict[str, Any]] = Field(None, description="Performance targets")

class TrainingResponse(BaseModel):
    """Response model for training operations"""
    success: bool
    job_id: Optional[str] = None
    message: str
    data: Optional[Dict[str, Any]] = None
    error: Optional[str] = None

# Global instances
training_factory = TrainingFactory()
training_repo = TrainingRepository()
intelligent_factory = IntelligentTrainingFactory()

@router.get("/health")
async def training_health():
    """Health check for training service"""
    return {
        "status": "healthy",
        "service": "training",
        "components": {
            "training_factory": "available",
            "training_repository": "available",
            "intelligent_factory": "available"
        }
    }

@router.post("/jobs", response_model=TrainingResponse)
async def create_training_job(
    request: TrainingJobRequest,
    background_tasks: BackgroundTasks,
    user = Depends(require_write_access)
):
    """
    Create a new training job
    
    Creates a training job record and optionally applies intelligent optimization
    """
    try:
        user_id = user.get("user_id") if user else None
        
        # Apply intelligent optimization if requested
        config = request.training_config
        if request.use_intelligent_optimization:
            try:
                optimization_result = intelligent_factory.optimize_training_configuration(
                    task_type=request.task_type,
                    domain=request.domain,
                    base_model=request.base_model,
                    dataset_info={"source": request.dataset_source},
                    resource_constraints=request.resource_config or {},
                    performance_targets={}
                )
                
                if optimization_result["success"]:
                    config.update(optimization_result["optimized_config"])
                    logger.info(f"Applied intelligent optimization for job: {request.job_name}")
                
            except Exception as e:
                logger.warning(f"Intelligent optimization failed, using original config: {e}")
        
        # Create training job
        job_id = training_repo.create_training_job(
            job_name=request.job_name,
            base_model=request.base_model,
            task_type=request.task_type,
            domain=request.domain,
            dataset_source=request.dataset_source,
            training_config=config,
            resource_config=request.resource_config,
            user_id=user_id,
            project_name=request.project_name,
            tags=request.tags
        )
        
        return TrainingResponse(
            success=True,
            job_id=job_id,
            message=f"Training job created successfully: {job_id}",
            data={
                "job_name": request.job_name,
                "base_model": request.base_model,
                "task_type": request.task_type,
                "domain": request.domain,
                "intelligent_optimization_applied": request.use_intelligent_optimization
            }
        )
        
    except Exception as e:
        logger.error(f"Failed to create training job: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to create training job: {str(e)}")

@router.post("/jobs/local", response_model=TrainingResponse)
async def start_local_training(
    request: LocalTrainingRequest,
    background_tasks: BackgroundTasks,
    user = Depends(require_write_access)
):
    """
    Start local training using TrainingFactory
    
    Executes training locally with the specified configuration
    """
    try:
        def run_training():
            """Background task for local training"""
            try:
                model_path = training_factory.train_model(
                    model_name=request.model_name,
                    dataset_path=request.dataset_path,
                    output_dir=request.output_dir,
                    training_type=request.training_type,
                    dataset_format=request.dataset_format,
                    use_lora=request.use_lora,
                    batch_size=request.batch_size,
                    num_epochs=request.num_epochs,
                    learning_rate=request.learning_rate,
                    max_length=request.max_length,
                    lora_rank=request.lora_rank,
                    lora_alpha=request.lora_alpha,
                    validation_split=request.validation_split
                )
                logger.info(f"Local training completed: {model_path}")
            except Exception as e:
                logger.error(f"Local training failed: {e}")
        
        # Start training in background
        background_tasks.add_task(run_training)
        
        return TrainingResponse(
            success=True,
            message="Local training started in background",
            data={
                "model_name": request.model_name,
                "dataset_path": request.dataset_path,
                "training_type": request.training_type
            }
        )
        
    except Exception as e:
        logger.error(f"Failed to start local training: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to start local training: {str(e)}")

@router.post("/jobs/cloud", response_model=TrainingResponse)
async def start_cloud_training(
    request: CloudTrainingRequest,
    background_tasks: BackgroundTasks,
    user = Depends(require_write_access)
):
    """
    Start cloud training on RunPod
    
    Executes training on RunPod cloud infrastructure
    """
    try:
        def run_cloud_training():
            """Background task for cloud training"""
            try:
                result = training_factory.train_on_runpod(
                    model_name=request.model_name,
                    dataset_path=request.dataset_path,
                    runpod_api_key=request.runpod_api_key,
                    template_id=request.template_id,
                    gpu_type=request.gpu_type,
                    storage_config=request.storage_config,
                    job_name=request.job_name,
                    **request.training_params
                )
                logger.info(f"Cloud training completed: {result}")
            except Exception as e:
                logger.error(f"Cloud training failed: {e}")
        
        # Start training in background
        background_tasks.add_task(run_cloud_training)
        
        return TrainingResponse(
            success=True,
            message="Cloud training started on RunPod",
            data={
                "model_name": request.model_name,
                "dataset_path": request.dataset_path,
                "gpu_type": request.gpu_type,
                "job_name": request.job_name
            }
        )
        
    except Exception as e:
        logger.error(f"Failed to start cloud training: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to start cloud training: {str(e)}")

@router.get("/jobs")
async def list_training_jobs(
    status: Optional[str] = Query(None, description="Filter by status"),
    user_id: Optional[str] = Query(None, description="Filter by user ID"),
    project_name: Optional[str] = Query(None, description="Filter by project name"),
    limit: int = Query(100, ge=1, le=1000, description="Maximum number of jobs"),
    user = Depends(optional_auth)
):
    """
    List training jobs with optional filtering
    """
    try:
        # If not admin, filter by current user
        filter_user_id = user_id
        if user and not user.get("is_admin", False):
            filter_user_id = user.get("user_id")
        
        jobs = training_repo.list_jobs(
            status=status,
            user_id=filter_user_id,
            project_name=project_name,
            limit=limit
        )
        
        # Convert to dict format
        jobs_data = []
        for job in jobs:
            job_dict = {
                "job_id": job.job_id,
                "job_name": job.job_name,
                "status": job.status,
                "base_model": job.base_model,
                "task_type": job.task_type,
                "domain": job.domain,
                "created_at": job.created_at.isoformat(),
                "started_at": job.started_at.isoformat() if job.started_at else None,
                "completed_at": job.completed_at.isoformat() if job.completed_at else None,
                "user_id": job.user_id,
                "project_name": job.project_name
            }
            jobs_data.append(job_dict)
        
        return {
            "success": True,
            "jobs": jobs_data,
            "total_count": len(jobs_data),
            "filters": {
                "status": status,
                "user_id": filter_user_id,
                "project_name": project_name,
                "limit": limit
            }
        }
        
    except Exception as e:
        logger.error(f"Failed to list training jobs: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to list training jobs: {str(e)}")

@router.get("/jobs/{job_id}")
async def get_training_job(
    job_id: str,
    user = Depends(optional_auth)
):
    """
    Get detailed information about a specific training job
    """
    try:
        job = training_repo.get_job(job_id)
        if not job:
            raise HTTPException(status_code=404, detail=f"Training job not found: {job_id}")
        
        # Check permissions
        if user and not user.get("is_admin", False):
            if job.user_id != user.get("user_id"):
                raise HTTPException(status_code=403, detail="Access denied")
        
        # Get job progress
        progress = training_repo.get_job_progress(job_id)
        
        # Get metrics
        metrics = training_repo.get_job_metrics(job_id)
        
        job_data = {
            "job_id": job.job_id,
            "job_name": job.job_name,
            "status": job.status,
            "base_model": job.base_model,
            "task_type": job.task_type,
            "domain": job.domain,
            "dataset_source": job.dataset_source,
            "training_config": job.training_config,
            "resource_config": job.resource_config,
            "created_at": job.created_at.isoformat(),
            "started_at": job.started_at.isoformat() if job.started_at else None,
            "completed_at": job.completed_at.isoformat() if job.completed_at else None,
            "user_id": job.user_id,
            "project_name": job.project_name,
            "tags": job.tags,
            "error_message": job.error_message,
            "output_model_path": job.output_model_path,
            "progress": progress,
            "metrics_count": len(metrics)
        }
        
        return {
            "success": True,
            "job": job_data
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to get training job {job_id}: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to get training job: {str(e)}")

@router.put("/jobs/{job_id}/status")
async def update_job_status(
    job_id: str,
    request: JobStatusUpdate,
    user = Depends(require_write_access)
):
    """
    Update training job status
    """
    try:
        success = training_repo.update_job_status(
            job_id=job_id,
            status=request.status,
            error_message=request.error_message,
            additional_updates=request.additional_updates
        )
        
        if not success:
            raise HTTPException(status_code=404, detail=f"Training job not found: {job_id}")
        
        return {
            "success": True,
            "message": f"Job {job_id} status updated to: {request.status}"
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to update job status for {job_id}: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to update job status: {str(e)}")

@router.post("/jobs/{job_id}/stop")
async def stop_training_job(
    job_id: str,
    user = Depends(require_write_access)
):
    """
    Stop a running training job
    """
    try:
        # Update status to cancelled
        success = training_repo.update_job_status(
            job_id=job_id,
            status="cancelled"
        )
        
        if not success:
            raise HTTPException(status_code=404, detail=f"Training job not found: {job_id}")
        
        # TODO: Implement actual job cancellation logic for RunPod/local training
        
        return {
            "success": True,
            "message": f"Training job {job_id} has been stopped"
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to stop training job {job_id}: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to stop training job: {str(e)}")

@router.post("/jobs/{job_id}/metrics")
async def record_training_metrics(
    job_id: str,
    request: TrainingMetricsRequest,
    user = Depends(require_write_access)
):
    """
    Record training metrics for a job
    """
    try:
        success = training_repo.record_metrics(
            job_id=job_id,
            metrics_data=request.metrics_data
        )
        
        if not success:
            raise HTTPException(status_code=404, detail=f"Training job not found: {job_id}")
        
        return {
            "success": True,
            "message": f"Metrics recorded for job {job_id}"
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to record metrics for job {job_id}: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to record metrics: {str(e)}")

@router.get("/jobs/{job_id}/metrics")
async def get_training_metrics(
    job_id: str,
    user = Depends(optional_auth)
):
    """
    Get training metrics for a job
    """
    try:
        metrics = training_repo.get_job_metrics(job_id)
        
        # Convert metrics to dict format
        metrics_data = []
        for metric in metrics:
            metric_dict = {
                "job_id": metric.job_id,
                "epoch": metric.epoch,
                "step": metric.step,
                "total_steps": metric.total_steps,
                "training_loss": metric.training_loss,
                "validation_loss": metric.validation_loss,
                "perplexity": metric.perplexity,
                "accuracy": metric.accuracy,
                "f1_score": metric.f1_score,
                "bleu_score": metric.bleu_score,
                "rouge_score": metric.rouge_score,
                "gpu_utilization": metric.gpu_utilization,
                "memory_usage": metric.memory_usage,
                "epoch_time": metric.epoch_time,
                "samples_per_second": metric.samples_per_second,
                "timestamp": metric.timestamp.isoformat(),
                "custom_metrics": metric.custom_metrics
            }
            metrics_data.append(metric_dict)
        
        return {
            "success": True,
            "metrics": metrics_data,
            "total_count": len(metrics_data)
        }
        
    except Exception as e:
        logger.error(f"Failed to get metrics for job {job_id}: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to get training metrics: {str(e)}")

@router.post("/optimize", response_model=TrainingResponse)
async def intelligent_training_optimization(
    request: IntelligentOptimizationRequest,
    user = Depends(optional_auth)
):
    """
    Get intelligent training optimization recommendations
    """
    try:
        result = intelligent_factory.optimize_training_configuration(
            task_type=request.task_type,
            domain=request.domain,
            dataset_info=request.dataset_info,
            resource_constraints=request.resource_constraints or {},
            performance_targets=request.performance_targets or {}
        )
        
        return TrainingResponse(
            success=result["success"],
            message=result.get("message", "Optimization completed"),
            data=result
        )
        
    except Exception as e:
        logger.error(f"Failed to perform intelligent optimization: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to perform optimization: {str(e)}")

@router.get("/datasets")
async def list_datasets(
    user = Depends(optional_auth)
):
    """
    List available datasets for training
    """
    try:
        # This would typically query a dataset registry
        # For now, return some example datasets
        datasets = [
            {
                "name": "tatsu-lab/alpaca",
                "type": "instruction_following",
                "format": "alpaca",
                "size": "52K samples",
                "description": "Stanford Alpaca instruction-following dataset"
            },
            {
                "name": "HuggingFaceH4/ultrachat_200k", 
                "type": "conversational",
                "format": "sharegpt",
                "size": "200K samples",
                "description": "High-quality conversational dataset"
            },
            {
                "name": "garage-bAInd/Open-Platypus",
                "type": "reasoning",
                "format": "alpaca",
                "size": "25K samples", 
                "description": "STEM and logic reasoning dataset"
            }
        ]
        
        return {
            "success": True,
            "datasets": datasets,
            "total_count": len(datasets)
        }
        
    except Exception as e:
        logger.error(f"Failed to list datasets: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to list datasets: {str(e)}")

@router.get("/models")
async def list_trained_models(
    user = Depends(optional_auth)
):
    """
    List locally trained models
    """
    try:
        models = training_factory.list_trained_models()
        
        return {
            "success": True,
            "models": models,
            "total_count": len(models)
        }
        
    except Exception as e:
        logger.error(f"Failed to list trained models: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to list trained models: {str(e)}")

@router.get("/statistics")
async def get_training_statistics(
    user_id: Optional[str] = Query(None, description="Get statistics for specific user"),
    user = Depends(optional_auth)
):
    """
    Get training statistics
    """
    try:
        # If not admin, only show current user's stats
        target_user_id = user_id
        if user and not user.get("is_admin", False):
            target_user_id = user.get("user_id")
        
        if target_user_id:
            stats = training_repo.get_user_statistics(target_user_id)
        else:
            # Get overall repository statistics
            stats = training_repo.get_repository_statistics()
        
        return {
            "success": True,
            "statistics": stats
        }
        
    except Exception as e:
        logger.error(f"Failed to get training statistics: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to get training statistics: {str(e)}")

@router.delete("/jobs/{job_id}")
async def delete_training_job(
    job_id: str,
    user = Depends(require_write_access)
):
    """
    Delete a training job and all associated data
    """
    try:
        success = training_repo.delete_job(job_id)
        
        if not success:
            raise HTTPException(status_code=404, detail=f"Training job not found: {job_id}")
        
        return {
            "success": True,
            "message": f"Training job {job_id} has been deleted"
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to delete training job {job_id}: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to delete training job: {str(e)}")